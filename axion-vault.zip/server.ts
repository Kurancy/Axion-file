import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { INITIAL_PROJECTS, INITIAL_DOCUMENTS, INITIAL_TASKS, INITIAL_TEAM, INITIAL_VAULT_RECORDS, INITIAL_ACTIVITY_LOGS } from "./src/data/mockData";
import { Project, DocumentItem, TaskItem, VaultRecord, ActivityLog } from "./src/types";

// Initialize state in memory for live mutations
let projectsStore: Project[] = [...INITIAL_PROJECTS];
let documentsStore: DocumentItem[] = [...INITIAL_DOCUMENTS];
let tasksStore: TaskItem[] = [...INITIAL_TASKS];
let vaultStore: VaultRecord[] = [...INITIAL_VAULT_RECORDS];
let activityStore: ActivityLog[] = [...INITIAL_ACTIVITY_LOGS];

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "20mb" }));

  // Shared Gemini client
  const apiKey = process.env.GEMINI_API_KEY;
  let aiClient: GoogleGenAI | null = null;
  if (apiKey) {
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  }

  // --- API ROUTES ---

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      systemHealth: "99.98%",
      nodesActive: 16,
      region: "us-central1-a (Cloud Run)",
      geminiConnected: !!apiKey,
      timestamp: new Date().toISOString()
    });
  });

  // Projects API
  app.get("/api/projects", (req, res) => {
    res.json(projectsStore);
  });

  app.post("/api/projects", (req, res) => {
    const newProj: Project = {
      id: `proj-${Date.now()}`,
      name: req.body.name || "Untitled Enterprise Project",
      client: req.body.client || "Axion Internal",
      description: req.body.description || "Project created in Axion Vault.",
      status: req.body.status || "Planning",
      priority: req.body.priority || "Medium",
      progress: req.body.progress || 0,
      budget: req.body.budget || "$1,000,000",
      spent: "$0",
      startDate: new Date().toISOString().split("T")[0],
      deadline: req.body.deadline || "2026-12-31",
      manager: req.body.manager || "Adam Vance",
      team: req.body.team || ["Adam Vance"],
      lastActivity: "Just now",
      category: req.body.category || "General Enterprise",
      tags: req.body.tags || ["New", "Enterprise"],
      riskScore: 15
    };
    projectsStore.unshift(newProj);
    
    // Log activity
    activityStore.unshift({
      id: `act-${Date.now()}`,
      user: newProj.manager,
      userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150',
      action: 'created new project:',
      target: newProj.name,
      timestamp: 'Just now',
      type: 'status'
    });

    res.status(201).json(newProj);
  });

  app.put("/api/projects/:id", (req, res) => {
    const { id } = req.params;
    const index = projectsStore.findIndex(p => p.id === id);
    if (index !== -1) {
      projectsStore[index] = { ...projectsStore[index], ...req.body, lastActivity: "Just now" };
      res.json(projectsStore[index]);
    } else {
      res.status(404).json({ error: "Project not found" });
    }
  });

  // Documents API
  app.get("/api/documents", (req, res) => {
    res.json(documentsStore);
  });

  app.post("/api/documents", (req, res) => {
    const newDoc: DocumentItem = {
      id: `doc-${Date.now()}`,
      name: req.body.name || "New_Enterprise_Document.pdf",
      project: req.body.project || "Sunshine Education ERP",
      projectId: req.body.projectId || "proj-1",
      category: req.body.category || "Requirements",
      extension: req.body.extension || "pdf",
      fileSize: req.body.fileSize || "2.4 MB",
      version: req.body.version || "v1.0",
      uploader: req.body.uploader || "Adam Vance",
      lastModified: new Date().toISOString().split("T")[0],
      aiSummary: req.body.aiSummary || "Document ingested into Axion Knowledge Engine. AI entity extraction complete.",
      tags: req.body.tags || ["Ingested", "Enterprise"],
      securityLevel: req.body.securityLevel || "Internal",
      extractedEntities: req.body.extractedEntities || ["Axion Vault", "Ingested Entity"],
      contentSnippet: req.body.contentSnippet || "Enterprise document content snippet indexed."
    };
    documentsStore.unshift(newDoc);

    activityStore.unshift({
      id: `act-${Date.now()}`,
      user: newDoc.uploader,
      userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150',
      action: 'uploaded document:',
      target: newDoc.name,
      timestamp: 'Just now',
      type: 'upload'
    });

    res.status(201).json(newDoc);
  });

  // Tasks API
  app.get("/api/tasks", (req, res) => {
    res.json(tasksStore);
  });

  app.post("/api/tasks", (req, res) => {
    const newTask: TaskItem = {
      id: `task-${Date.now()}`,
      title: req.body.title || "New Enterprise Task",
      description: req.body.description || "Task assigned via Axion Vault.",
      project: req.body.project || "Sunshine Education ERP",
      projectId: req.body.projectId || "proj-1",
      status: req.body.status || "To Do",
      priority: req.body.priority || "Medium",
      assignee: req.body.assignee || "Adam Vance",
      assigneeAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150",
      dueDate: req.body.dueDate || "2026-08-30",
      attachmentsCount: 1,
      commentsCount: 0,
      aiSuggestions: ["Verify milestone completion", "Review security clearance"]
    };
    tasksStore.unshift(newTask);
    res.status(201).json(newTask);
  });

  app.put("/api/tasks/:id", (req, res) => {
    const { id } = req.params;
    const index = tasksStore.findIndex(t => t.id === id);
    if (index !== -1) {
      tasksStore[index] = { ...tasksStore[index], ...req.body };
      res.json(tasksStore[index]);
    } else {
      res.status(404).json({ error: "Task not found" });
    }
  });

  // Team API
  app.get("/api/team", (req, res) => {
    res.json(INITIAL_TEAM);
  });

  // Vault API
  app.get("/api/vault", (req, res) => {
    res.json(vaultStore);
  });

  app.get("/api/activity", (req, res) => {
    res.json(activityStore);
  });

  // --- AI ENGINE ROUTES (Axion AI powered by Gemini 3.6 Flash) ---

  // Axion AI Assistant Chat
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { prompt, contextProject, contextDoc, docSnippet, docSummary } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      if (!aiClient) {
        // Fallback intelligent simulated enterprise response if API key is not present in local test
        let fallbackText = `### Axion Enterprise AI Synthesis\n\nBased on workspace data across **${projectsStore.length} active projects** and **${documentsStore.length} documents**:\n\n`;
        
        if (contextDoc) {
          const matchedDoc = documentsStore.find(d => d.name === contextDoc || d.id === contextDoc) || {
            name: contextDoc,
            project: 'Enterprise Vault',
            aiSummary: docSummary || 'Document content analyzed under HSM security protocol.',
            contentSnippet: docSnippet || 'Verified enterprise contract agreement.',
            extractedEntities: ['Axion Tech', 'SLA 99.99%', 'AES-256 HSM']
          };

          fallbackText += `📄 **Document Context**: **${matchedDoc.name}**\n* **Associated Project**: ${matchedDoc.project}\n* **User Query**: "${prompt}"\n\n**Document Intelligence Synthesis:**\n1. **Clause & Term Analysis**: The document "${matchedDoc.name}" specifies mandatory compliance with enterprise SLAs, data security standards, and encryption controls.\n2. **Key Excerpt Analyzed**: "${matchedDoc.contentSnippet ? matchedDoc.contentSnippet.slice(0, 180) : 'Verified enterprise contract'}..."\n3. **Executive Takeaway**: ${matchedDoc.aiSummary}\n\n*Action Suggested*: Proceed with legal verification or export detailed clause audit.`;
        } else {
          fallbackText += `* **Project Context**: ${contextProject ? contextProject : 'Global Workspace'}\n* **Query**: ${prompt}\n\n**Key Findings & Recommendations:**\n1. **Sunshine Education ERP** is currently at **82% progress** with milestone UAT target set for October 15, 2026.\n2. **Warehouse AI Robotics** achieved 94% progress with edge-model vision models passing primary test suites.\n3. **CyberVault 2.0** maintains zero security vulnerability compliance under FIPS 140-3 Level 4 specs.\n\n*Action Suggested*: Schedule team review meeting with Adam Vance and Sophia Sterling.`;
        }

        return res.json({ text: fallbackText });
      }

      const projectsContext = projectsStore.map(p => `- ${p.name} (${p.client}): ${p.status}, ${p.progress}% complete, Budget: ${p.budget}, Deadline: ${p.deadline}. Risk Score: ${p.riskScore}`).join("\n");
      const docsContext = documentsStore.map(d => `- ${d.name} [Project: ${d.project}, Category: ${d.category}]: ${d.aiSummary}`).join("\n");

      const systemInstruction = `You are Axion AI, the Enterprise Project & Document Intelligence Assistant for Axion Technologies.
You speak with professional, executive composure, precision, and authority. You specialize in project management, document analysis, risk evaluation, architectural compliance, and technical synthesis.
Format responses cleanly with markdown headers, bullet points, and clear actionable takeaways.
Do NOT mention internal prompt mechanics.

Current Active Projects Context:
${projectsContext}

Current Enterprise Documents Context:
${docsContext}
${contextProject ? `Specific Focus Project: ${contextProject}` : ''}
${contextDoc ? `Specific Focus Document: ${contextDoc}\nDocument Content Snippet: ${docSnippet || 'Enterprise content'}\nDocument Executive Summary: ${docSummary || ''}` : ''}`;

      const response = await aiClient.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          systemInstruction: systemInstruction,
          temperature: 0.3
        }
      });

      res.json({ text: response.text || "No response generated by Axion AI." });
    } catch (err: any) {
      console.error("Gemini AI Chat Error:", err);
      res.status(500).json({ error: err.message || "Failed to process AI chat request" });
    }
  });

  // AI Document Summarizer & Entity Extractor
  app.post("/api/ai/summarize-doc", async (req, res) => {
    try {
      const { docName, category, contentSnippet } = req.body;

      if (!aiClient) {
        return res.json({
          summary: `Executive summary for ${docName}: Key clauses verified including SLA performance, technical compliance, and liability terms. Ready for executive sign-off.`,
          entities: ["Axion Technologies", "SLA 99.99%", "Master Agreement", "AES-256"],
          riskAnalysis: "Low Risk — Fully compliant with enterprise security standards."
        });
      }

      const prompt = `Analyze and summarize this enterprise document for Axion Vault:
Document Name: ${docName}
Category: ${category}
Snippet/Details: ${contentSnippet || 'Standard enterprise document'}

Provide a JSON object with:
- "summary": A crisp 2-sentence executive summary.
- "entities": Array of 4-6 key extracted entities (companies, dates, tech standards, monetary values).
- "riskAnalysis": A 1-sentence risk rating evaluation.`;

      const response = await aiClient.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0.2
        }
      });

      const parsed = JSON.parse(response.text || "{}");
      res.json(parsed);
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Document summarization failed" });
    }
  });

  // AI Knowledge Search Endpoint
  app.post("/api/ai/search", async (req, res) => {
    try {
      const { query } = req.body;
      if (!query) return res.status(400).json({ error: "Search query required" });

      if (!aiClient) {
        return res.json({
          synthesis: `Search analysis for "${query}": Found relevant references in Sunshine Education ERP, SAP Business One Migration, and CyberVault contracts. All key documentation and code artifacts are verified.`,
          relevantDocIds: ['doc-1', 'doc-3', 'doc-4'],
          relevantProjIds: ['proj-1', 'proj-2']
        });
      }

      const prompt = `Query: "${query}"

Synthesize an executive intelligence summary answering this search query based on enterprise knowledge in projects and contracts.
Format as markdown with direct answers and highlighted key details.`;

      const response = await aiClient.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are the Axion Vault AI Knowledge Engine. You scan all projects, documents, codebases, and contracts to provide accurate, grounded answers."
        }
      });

      res.json({
        synthesis: response.text || "No synthesis available for this query.",
        relevantDocIds: ['doc-1', 'doc-2', 'doc-3'],
        relevantProjIds: ['proj-1', 'proj-3']
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Knowledge search failed" });
    }
  });

  // AI Risk Analyzer for Projects
  app.post("/api/ai/analyze-risk", async (req, res) => {
    try {
      const { projectId } = req.body;
      const proj = projectsStore.find(p => p.id === projectId) || projectsStore[0];

      if (!aiClient) {
        return res.json({
          riskLevel: proj.riskScore > 30 ? "Medium Risk" : "Low Risk",
          riskScore: proj.riskScore,
          keyRisks: [
            "Milestone delivery dependency on third-party SLA verification",
            "Resource allocation overlap during UAT phase"
          ],
          mitigations: [
            "Establish secondary staging buffer zone",
            "Re-assign dedicated QA engineer from Cloud team"
          ]
        });
      }

      const prompt = `Perform an AI Project Risk Analysis for:
Project: ${proj.name}
Client: ${proj.client}
Status: ${proj.status}
Progress: ${proj.progress}%
Budget Spent: ${proj.spent} of ${proj.budget}
Deadline: ${proj.deadline}
Architecture: ${proj.architectureOverview || 'Microservices'}

Provide JSON output with:
- "riskLevel": "Low Risk" | "Medium Risk" | "High Risk" | "Critical Risk"
- "riskScore": number between 1 and 100
- "keyRisks": string array of 3 bullet points
- "mitigations": string array of 3 actionable mitigation steps`;

      const response = await aiClient.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0.2
        }
      });

      const parsed = JSON.parse(response.text || "{}");
      res.json(parsed);
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Risk analysis failed" });
    }
  });

  // --- VITE MIDDLEWARE / PRODUCTION STATIC SERVING ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Axion Vault Enterprise Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

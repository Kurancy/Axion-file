import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { StatusBar } from './components/StatusBar';
import { LoadingScreen } from './components/LoadingScreen';
import { AiAssistantPanel } from './components/AiAssistantPanel';
import { GlobalSearchModal } from './components/GlobalSearchModal';

import { DashboardView } from './components/views/DashboardView';
import { ProjectsView } from './components/views/ProjectsView';
import { DocumentsView } from './components/views/DocumentsView';
import { AiKnowledgeView } from './components/views/AiKnowledgeView';
import { TasksView } from './components/views/TasksView';
import { TeamView } from './components/views/TeamView';
import { AnalyticsView } from './components/views/AnalyticsView';
import { SecureVaultView } from './components/views/SecureVaultView';
import { SettingsView } from './components/views/SettingsView';

import { NewProjectModal } from './components/modals/NewProjectModal';
import { UploadDocModal } from './components/modals/UploadDocModal';
import { KeyboardShortcutsModal } from './components/modals/KeyboardShortcutsModal';

import { 
  INITIAL_PROJECTS, 
  INITIAL_DOCUMENTS, 
  INITIAL_TASKS, 
  INITIAL_TEAM, 
  INITIAL_ACTIVITY_LOGS, 
  INITIAL_VAULT_RECORDS 
} from './data/mockData';
import { ViewType, Project, DocumentItem, TaskItem, TaskStatus, ProjectPriority } from './types';

export function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  
  // Data state
  const [projects, setProjects] = useState<Project[]>(INITIAL_PROJECTS);
  const [documents, setDocuments] = useState<DocumentItem[]>(INITIAL_DOCUMENTS);
  const [tasks, setTasks] = useState<TaskItem[]>(INITIAL_TASKS);
  const [team, setTeam] = useState(INITIAL_TEAM);
  const [activities, setActivities] = useState(INITIAL_ACTIVITY_LOGS);
  const [vaultRecords, setVaultRecords] = useState(INITIAL_VAULT_RECORDS);

  // Selection & Detail Modals
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [selectedDocument, setSelectedDocument] = useState<DocumentItem | null>(null);

  // Modals & Drawers
  const [isAiPanelOpen, setIsAiPanelOpen] = useState(false);
  const [aiContext, setAiContext] = useState<Project | DocumentItem | null>(null);
  const [isGlobalSearchOpen, setIsGlobalSearchOpen] = useState(false);
  const [isNewProjectModalOpen, setIsNewProjectModalOpen] = useState(false);
  const [isUploadDocModalOpen, setIsUploadDocModalOpen] = useState(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState(false);

  // Global Keyboard shortcuts handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if typing in input or textarea
      const targetTag = (e.target as HTMLElement)?.tagName?.toLowerCase();
      if (targetTag === 'input' || targetTag === 'textarea' || (e.target as HTMLElement)?.isContentEditable) {
        if (e.key === 'Escape') {
          (e.target as HTMLElement).blur();
        }
        return;
      }

      // Ctrl + K or Cmd + K -> Search
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsGlobalSearchOpen(prev => !prev);
        return;
      }

      // Ctrl + / or Cmd + / -> AI Assistant
      if ((e.metaKey || e.ctrlKey) && e.key === '/') {
        e.preventDefault();
        setIsAiPanelOpen(prev => !prev);
        return;
      }

      // ? key -> Keyboard Shortcuts Cheat Sheet
      if (e.key === '?' || (e.shiftKey && e.key === '/')) {
        e.preventDefault();
        setIsShortcutsOpen(prev => !prev);
        return;
      }

      // Escape -> Close open modals
      if (e.key === 'Escape') {
        setIsGlobalSearchOpen(false);
        setIsAiPanelOpen(false);
        setIsNewProjectModalOpen(false);
        setIsUploadDocModalOpen(false);
        setIsShortcutsOpen(false);
        return;
      }

      // Alt + 1..7 -> View Navigation
      if (e.altKey) {
        if (e.key === '1') { e.preventDefault(); setCurrentView('dashboard'); }
        else if (e.key === '2') { e.preventDefault(); setCurrentView('projects'); }
        else if (e.key === '3') { e.preventDefault(); setCurrentView('documents'); }
        else if (e.key === '4') { e.preventDefault(); setCurrentView('tasks'); }
        else if (e.key === '5') { e.preventDefault(); setCurrentView('ai-knowledge'); }
        else if (e.key === '6') { e.preventDefault(); setCurrentView('vault'); }
        else if (e.key === '7') { e.preventDefault(); setCurrentView('team'); }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleAddProject = (newProjData: Partial<Project>) => {
    const newP: Project = {
      id: `proj-${Date.now()}`,
      name: newProjData.name || 'New Enterprise Project',
      client: newProjData.client || 'Enterprise Partner',
      description: newProjData.description || 'Strategic Digital Transformation.',
      category: newProjData.category || 'Enterprise ERP',
      status: newProjData.status || 'Planning',
      priority: newProjData.priority || 'Medium',
      budget: newProjData.budget || '$1,000,000',
      spent: '$0',
      startDate: new Date().toISOString().split('T')[0],
      deadline: newProjData.deadline || '2026-12-31',
      manager: newProjData.manager || 'Adam Vance',
      team: newProjData.team || ['Adam Vance'],
      progress: 0,
      tags: ['ERP', 'Cloud'],
      lastActivity: 'Just created',
      riskScore: 12,
      architectureOverview: 'Microservices container architecture on Cloud Run.'
    };

    setProjects(prev => [newP, ...prev]);
  };

  const handleUploadDoc = (newDocData: Partial<DocumentItem>) => {
    const newD: DocumentItem = {
      id: `doc-${Date.now()}`,
      name: newDocData.name || 'Document_Artifact.pdf',
      category: newDocData.category || 'Requirements',
      project: newDocData.project || 'Sunshine Education ERP',
      projectId: newDocData.projectId || 'proj-1',
      extension: 'pdf',
      fileSize: newDocData.fileSize || '2.4 MB',
      lastModified: 'Just now',
      version: 'v1.0',
      uploader: 'Adam Vance',
      aiSummary: newDocData.aiSummary || 'Indexed into Axion Vault Intelligence Engine.',
      tags: ['Uploaded', 'Vault'],
      securityLevel: 'Confidential',
      extractedEntities: newDocData.extractedEntities || ['Axion Vault'],
      contentSnippet: newDocData.contentSnippet || 'Master document content payload verified.'
    };

    setDocuments(prev => [newD, ...prev]);
  };

  const handleAddTask = (newTaskData: Partial<TaskItem>) => {
    const newT: TaskItem = {
      id: `task-${Date.now()}`,
      title: newTaskData.title || 'Execute Unit Testing Suite',
      description: newTaskData.description || 'Deliver automated regression test passes.',
      project: newTaskData.project || 'Sunshine Education ERP',
      projectId: 'proj-1',
      status: newTaskData.status || 'To Do',
      priority: newTaskData.priority || 'Medium',
      assignee: newTaskData.assignee || 'Adam Vance',
      dueDate: newTaskData.dueDate || '2026-08-30',
      attachmentsCount: 1,
      commentsCount: 0,
      aiSuggestions: ['Recommend automated container stress test pass']
    };

    setTasks(prev => [newT, ...prev]);
  };

  const handleUpdateTaskStatus = (taskId: string, newStatus: TaskStatus) => {
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: newStatus } : t));
  };

  const handleUpdateTaskPriority = (taskId: string, newPriority: ProjectPriority) => {
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, priority: newPriority } : t));
  };

  const handleReorderTasks = (newTasks: TaskItem[]) => {
    setTasks(newTasks);
  };

  if (isLoading) {
    return <LoadingScreen onComplete={() => setIsLoading(false)} />;
  }

  return (
    <div className="min-h-screen bg-[#050B18] text-slate-100 flex font-sans overflow-x-hidden selection:bg-[#2563EB] selection:text-white">
      
      {/* Left Sidebar Navigation */}
      <Sidebar
        currentView={currentView}
        onNavigate={(v) => {
          setCurrentView(v);
          setSelectedProject(null);
          setSelectedDocument(null);
        }}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(prev => !prev)}
      />

      {/* Main Workspace Column */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        
        {/* Global Action Header */}
        <Header
          onOpenGlobalSearch={() => setIsGlobalSearchOpen(true)}
          onOpenAiAssistant={() => {
            setAiContext(null);
            setIsAiPanelOpen(true);
          }}
          onOpenNewProject={() => setIsNewProjectModalOpen(true)}
          onOpenUploadDoc={() => setIsUploadDocModalOpen(true)}
        />

        {/* Dynamic Main View Content Area */}
        <main className="flex-1 pb-12 overflow-y-auto custom-scrollbar">
          {currentView === 'dashboard' && (
            <DashboardView
              projects={projects}
              documents={documents}
              activities={activities}
              onSelectProject={(p) => {
                setSelectedProject(p);
                setCurrentView('projects');
              }}
              onSelectDocument={(d) => {
                setSelectedDocument(d);
                setCurrentView('documents');
              }}
              onNavigate={(v) => setCurrentView(v)}
            />
          )}

          {currentView === 'projects' && (
            <ProjectsView
              projects={projects}
              documents={documents}
              tasks={tasks}
              selectedProject={selectedProject}
              onSelectProject={setSelectedProject}
              onOpenNewProjectModal={() => setIsNewProjectModalOpen(true)}
              onOpenAiAssistantWithContext={(proj) => {
                setAiContext(proj);
                setIsAiPanelOpen(true);
              }}
              onSelectDocument={(doc) => {
                setSelectedDocument(doc);
                setCurrentView('documents');
              }}
            />
          )}

          {currentView === 'documents' && (
            <DocumentsView
              documents={documents}
              selectedDocument={selectedDocument}
              onSelectDocument={setSelectedDocument}
              onOpenUploadDocModal={() => setIsUploadDocModalOpen(true)}
              onChatWithDocument={(doc) => {
                setAiContext(doc);
                setIsAiPanelOpen(true);
              }}
            />
          )}

          {currentView === 'ai-knowledge' && (
            <AiKnowledgeView
              projects={projects}
              documents={documents}
              onSelectProject={(p) => {
                setSelectedProject(p);
                setCurrentView('projects');
              }}
              onSelectDocument={(d) => {
                setSelectedDocument(d);
                setCurrentView('documents');
              }}
            />
          )}

          {currentView === 'tasks' && (
            <TasksView
              tasks={tasks}
              onAddTask={handleAddTask}
              onUpdateTaskStatus={handleUpdateTaskStatus}
              onUpdateTaskPriority={handleUpdateTaskPriority}
              onReorderTasks={handleReorderTasks}
            />
          )}

          {currentView === 'team' && (
            <TeamView
              team={team}
              activities={activities}
            />
          )}

          {currentView === 'analytics' && (
            <AnalyticsView />
          )}

          {currentView === 'vault' && (
            <SecureVaultView
              vaultRecords={vaultRecords}
            />
          )}

          {currentView === 'settings' && (
            <SettingsView
              onReplayLoadingScreen={() => setIsLoading(true)}
            />
          )}
        </main>

        {/* Fixed System Health & Status Footer */}
        <StatusBar onOpenShortcuts={() => setIsShortcutsOpen(true)} />
      </div>

      {/* AI Assistant Sliding Panel Drawer */}
      <AiAssistantPanel
        isOpen={isAiPanelOpen}
        onClose={() => setIsAiPanelOpen(false)}
        projects={projects}
        documents={documents}
        context={aiContext}
      />

      {/* Global Command-K Search Overlay Modal */}
      <GlobalSearchModal
        isOpen={isGlobalSearchOpen}
        onClose={() => setIsGlobalSearchOpen(false)}
        projects={projects}
        documents={documents}
        tasks={tasks}
        onSelectProject={(p) => {
          setSelectedProject(p);
          setCurrentView('projects');
        }}
        onSelectDocument={(d) => {
          setSelectedDocument(d);
          setCurrentView('documents');
        }}
      />

      {/* New Project Creation Modal */}
      <NewProjectModal
        isOpen={isNewProjectModalOpen}
        onClose={() => setIsNewProjectModalOpen(false)}
        onAddProject={handleAddProject}
      />

      {/* Document Upload Modal */}
      <UploadDocModal
        isOpen={isUploadDocModalOpen}
        onClose={() => setIsUploadDocModalOpen(false)}
        projects={projects}
        onUploadDoc={handleUploadDoc}
      />

      {/* Keyboard Shortcuts Cheat Sheet Modal */}
      <KeyboardShortcutsModal
        isOpen={isShortcutsOpen}
        onClose={() => setIsShortcutsOpen(false)}
      />

    </div>
  );
}

export default App;

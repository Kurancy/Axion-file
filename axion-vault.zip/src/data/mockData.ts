import { Project, DocumentItem, TaskItem, TeamMember, ActivityLog, VaultRecord } from '../types';

export const INITIAL_TEAM: TeamMember[] = [
  {
    id: 'team-1',
    name: 'Adam Vance',
    email: 'adam.vance@axiontech.com',
    role: 'Enterprise Solutions Architect',
    department: 'Engineering',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150',
    status: 'Online',
    permissions: ['Admin', 'Write', 'Read', 'Vault Access'],
    assignedProjects: ['proj-1', 'proj-2', 'proj-3']
  },
  {
    id: 'team-2',
    name: 'Elena Rostova',
    email: 'elena.rostova@axiontech.com',
    role: 'Principal Cloud Engineer',
    department: 'Infrastructure',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=150',
    status: 'Online',
    permissions: ['Write', 'Read', 'Vault Access'],
    assignedProjects: ['proj-1', 'proj-4']
  },
  {
    id: 'team-3',
    name: 'Marcus Chen',
    email: 'marcus.chen@axiontech.com',
    role: 'AI & Data Science Director',
    department: 'Axion AI Labs',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150',
    status: 'Busy',
    permissions: ['Admin', 'Write', 'Read', 'Vault Access'],
    assignedProjects: ['proj-2', 'proj-3']
  },
  {
    id: 'team-4',
    name: 'Sophia Sterling',
    email: 'sophia.sterling@axiontech.com',
    role: 'Chief Security Officer',
    department: 'Cybersecurity',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=150',
    status: 'Online',
    permissions: ['Admin', 'Write', 'Read', 'Vault Access'],
    assignedProjects: ['proj-1', 'proj-2', 'proj-3', 'proj-4']
  },
  {
    id: 'team-5',
    name: 'David Okafor',
    email: 'david.okafor@axiontech.com',
    role: 'Senior ERP Lead Consultant',
    department: 'Enterprise Applications',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150',
    status: 'Away',
    permissions: ['Write', 'Read'],
    assignedProjects: ['proj-1', 'proj-5']
  }
];

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'proj-1',
    name: 'Sunshine Education ERP',
    client: 'Sunshine Global Education Network',
    description: 'Next-generation cloud ERP unifying Student Lifecycle Management, Financial Operations, Attendance, HR, and Automated Reporting.',
    status: 'In Progress',
    priority: 'High',
    progress: 82,
    budget: '$3,400,000',
    spent: '$2,780,000',
    startDate: '2025-09-01',
    deadline: '2026-10-15',
    manager: 'Adam Vance',
    team: ['Adam Vance', 'Elena Rostova', 'David Okafor'],
    lastActivity: 'Today, 10:14 AM',
    category: 'Education ERP',
    tags: ['ERP', 'Cloud', 'SAP Integration', 'Multi-tenant'],
    architectureOverview: 'Microservices architecture with Node.js backend services, PostgreSQL database cluster, Redis caching layer, and React Vite frontend. Deployed on Kubernetes with Automated CI/CD.',
    riskScore: 18
  },
  {
    id: 'proj-2',
    name: 'Warehouse AI Autonomous Robotics',
    client: 'Global Logistics Corp',
    description: 'Autonomous inventory optimization system powered by Axion Computer Vision models, real-time telemetry, and robotic fleet management.',
    status: 'Review',
    priority: 'Critical',
    progress: 94,
    budget: '$5,800,000',
    spent: '$5,420,000',
    startDate: '2025-02-15',
    deadline: '2026-08-30',
    manager: 'Marcus Chen',
    team: ['Marcus Chen', 'Sophia Sterling', 'Elena Rostova'],
    lastActivity: 'Yesterday, 04:45 PM',
    category: 'Industrial AI',
    tags: ['Robotics', 'Computer Vision', 'IoT', 'Real-time'],
    architectureOverview: 'Edge computing nodes running TensorRT optimization models communicating with Central Cloud Engine over MQTT over TLS 1.3.',
    riskScore: 24
  },
  {
    id: 'proj-3',
    name: 'SAP Business One Integration & Migration',
    client: 'Apex Industrial Manufacturing',
    description: 'Migration from legacy SAP R/3 to SAP Business One Cloud with custom API connectors and real-time ledger synchronization.',
    status: 'In Progress',
    priority: 'Critical',
    progress: 58,
    budget: '$1,950,000',
    spent: '$1,320,000',
    startDate: '2025-11-10',
    deadline: '2026-08-18',
    manager: 'David Okafor',
    team: ['David Okafor', 'Adam Vance'],
    lastActivity: 'Today, 08:30 AM',
    category: 'ERP Migration',
    tags: ['SAP', 'B1', 'HANA Database', 'ETL'],
    architectureOverview: 'Hybrid cloud setup with SAP HANA database cluster and secure REST webhooks for real-time inventory and GL posting.',
    riskScore: 78
  },
  {
    id: 'proj-4',
    name: 'CyberVault 2.0 Security Architecture',
    client: 'Federal Tech Authority',
    description: 'Zero-trust enterprise identity and cryptographic vault implementation for defense contractor document management.',
    status: 'In Progress',
    priority: 'High',
    progress: 55,
    budget: '$8,200,000',
    spent: '$4,100,000',
    startDate: '2026-01-05',
    deadline: '2026-09-10',
    manager: 'Sophia Sterling',
    team: ['Sophia Sterling', 'Elena Rostova', 'Marcus Chen'],
    lastActivity: 'Jul 28, 2026',
    category: 'Defense & Security',
    tags: ['Zero-Trust', 'AES-256', 'FIPS-140-3', 'HSM'],
    architectureOverview: 'Multi-region hardware security module (HSM) deployment with double-wrapped AES-256-GCM envelope encryption.',
    riskScore: 48
  },
  {
    id: 'proj-5',
    name: 'GovTech Citizen Portal Transformation',
    client: 'Ministry of Digital Services',
    description: 'Omnichannel digital portal for 12M citizens covering permit processing, tax filings, and unified identity verification.',
    status: 'Completed',
    priority: 'High',
    progress: 100,
    budget: '$12,000,000',
    spent: '$11,850,000',
    startDate: '2024-06-01',
    deadline: '2026-05-30',
    manager: 'Adam Vance',
    team: ['Adam Vance', 'David Okafor'],
    lastActivity: 'Jul 15, 2026',
    category: 'Public Sector',
    tags: ['GovTech', 'e-ID', 'Accessibility', 'High-Availability'],
    architectureOverview: 'Multi-AZ Cloud Run serverless cluster handling up to 50,000 concurrent citizen requests per second.',
    riskScore: 5
  }
];

export const INITIAL_DOCUMENTS: DocumentItem[] = [
  {
    id: 'doc-1',
    name: 'Sunshine_ERP_Master_Contract_Signed.pdf',
    project: 'Sunshine Education ERP',
    projectId: 'proj-1',
    category: 'Contracts',
    extension: 'pdf',
    fileSize: '14.2 MB',
    version: 'v2.4 Final',
    uploader: 'Sophia Sterling',
    lastModified: '2026-06-12',
    aiSummary: 'Legally binding master service agreement outlining multi-campus deployment, SLA guarantees (99.99%), payment milestones ($3.4M total), and intellectual property protection.',
    tags: ['Contract', 'Signed', 'SLA', 'Legal'],
    securityLevel: 'Confidential',
    extractedEntities: ['Sunshine Network', 'Axion Technologies', '$3,400,000 USD', '99.99% Availability', 'Arbitration: NY'],
    contentSnippet: 'This Master Services Agreement is entered into by and between Sunshine Global Education Network and Axion Technologies...'
  },
  {
    id: 'doc-2',
    name: 'SAP_B1_Database_Schema_v3.sql',
    project: 'SAP Business One Integration & Migration',
    projectId: 'proj-3',
    category: 'Database',
    extension: 'sql',
    fileSize: '4.8 MB',
    version: 'v3.0',
    uploader: 'David Okafor',
    lastModified: '2026-07-22',
    aiSummary: 'Complete DDL script for SAP HANA migration mapping OINV (Invoices), OCRD (Business Partners), and OITM (Items) with indexes for sub-second query performance.',
    tags: ['SQL', 'Database', 'SAP HANA', 'Schema'],
    securityLevel: 'Internal',
    extractedEntities: ['Table OINV', 'Table OCRD', 'Foreign Keys', 'Primary Index'],
    contentSnippet: 'CREATE TABLE OINV_STAGING (DocEntry INT PRIMARY KEY, DocNum VARCHAR(50), CardCode VARCHAR(50), DocTotal DECIMAL(18,4)...'
  },
  {
    id: 'doc-3',
    name: 'Warehouse_Robotics_API_Authentication_Specs.pdf',
    project: 'Warehouse AI Autonomous Robotics',
    projectId: 'proj-2',
    category: 'API',
    extension: 'pdf',
    fileSize: '8.1 MB',
    version: 'v1.8',
    uploader: 'Adam Vance',
    lastModified: '2026-07-28',
    aiSummary: 'Technical specifications for mTLS and OAuth2 JWT authentication protocols between AMR fleet controllers and central telemetry streams.',
    tags: ['API', 'Auth', 'mTLS', 'JWT', 'OAuth2'],
    securityLevel: 'Internal',
    extractedEntities: ['OAuth 2.0', 'mTLS Certificate', 'Port 8443', 'Rate Limit: 10k req/s'],
    contentSnippet: 'Robotic endpoints must present a valid X.509 client certificate signed by Axion Internal CA...'
  },
  {
    id: 'doc-4',
    name: 'CyberVault_Security_Architecture_Blueprint.docx',
    project: 'CyberVault 2.0 Security Architecture',
    projectId: 'proj-4',
    category: 'Requirements',
    extension: 'docx',
    fileSize: '22.5 MB',
    version: 'v4.1',
    uploader: 'Sophia Sterling',
    lastModified: '2026-07-25',
    aiSummary: 'High-level security architecture specification detailing zero-trust data plane, FIPS 140-3 cryptography standards, and HSM tokenization pipeline.',
    tags: ['Zero-Trust', 'FIPS', 'HSM', 'Blueprint'],
    securityLevel: 'Restricted (Vault)',
    isVaultOnly: true,
    extractedEntities: ['FIPS 140-3 Level 4', 'Key Custodian Matrix', 'Air-gapped Key Generation'],
    contentSnippet: 'All cryptographic keys are generated inside dedicated Hardware Security Modules...'
  },
  {
    id: 'doc-5',
    name: 'Sunshine_ERP_Deployment_Architecture_Vite_Node.png',
    project: 'Sunshine Education ERP',
    projectId: 'proj-1',
    category: 'Deployment',
    extension: 'png',
    fileSize: '6.3 MB',
    version: 'v1.2',
    uploader: 'Elena Rostova',
    lastModified: '2026-07-20',
    aiSummary: 'Diagram illustrating Dockerized cloud run containers, Nginx load balancing, Cloud SQL PostgreSQL failover pair, and CDN caching layers.',
    tags: ['Architecture', 'Deployment', 'Diagram', 'Docker'],
    securityLevel: 'Internal',
    extractedEntities: ['Cloud Run', 'PostgreSQL Multi-AZ', 'Cloudflare Edge', 'Port 3000'],
    contentSnippet: '[Diagram Rendering: Nginx Gateway -> Node.js Express App -> PostgreSQL Replica Cluster]'
  },
  {
    id: 'doc-6',
    name: 'GovTech_Citizen_Portal_Final_Audit_Report.pdf',
    project: 'GovTech Citizen Portal Transformation',
    projectId: 'proj-5',
    category: 'Reports',
    extension: 'pdf',
    fileSize: '18.9 MB',
    version: 'v1.0 Final',
    uploader: 'Adam Vance',
    lastModified: '2026-05-28',
    aiSummary: 'Third-party penetration testing and compliance audit certifying zero critical vulnerabilities and 100% WCAG 2.1 AA accessibility compliance.',
    tags: ['Audit', 'Security', 'Compliance', 'GovTech'],
    securityLevel: 'Public',
    extractedEntities: ['Zero Vulnerabilities', 'WCAG 2.1 AA', 'ISO 27001 Certified'],
    contentSnippet: 'Independent Security Assessment performed by Deloitte Cybersecurity Services...'
  }
];

export const INITIAL_TASKS: TaskItem[] = [
  {
    id: 'task-1',
    title: 'Final User Acceptance Testing (UAT) for Sunshine ERP Student Module',
    description: 'Execute end-to-end regression tests on gradebook entry, attendance synchronization, and tuition fee portal.',
    project: 'Sunshine Education ERP',
    projectId: 'proj-1',
    status: 'In Progress',
    priority: 'High',
    assignee: 'David Okafor',
    assigneeAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150',
    dueDate: '2026-08-10',
    createdAt: '2026-07-20',
    attachmentsCount: 4,
    commentsCount: 12,
    aiSuggestions: [
      'Automate gradebook calculations using batch worker pool',
      'Verify student notification webhook resilience under load'
    ]
  },
  {
    id: 'task-2',
    title: 'Robotics Autonomous Obstacle Avoidance Fine-Tuning',
    description: 'Calibrate LIDAR and camera fusion AI models for warehouse aisles with low lighting conditions.',
    project: 'Warehouse AI Autonomous Robotics',
    projectId: 'proj-2',
    status: 'Review',
    priority: 'Critical',
    assignee: 'Marcus Chen',
    assigneeAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150',
    dueDate: '2026-08-05',
    createdAt: '2026-07-15',
    attachmentsCount: 8,
    commentsCount: 19,
    aiSuggestions: [
      'Model precision improved by 4.2% when applying temporal filtering',
      'Recommend edge deployment test before field release'
    ]
  },
  {
    id: 'task-3',
    title: 'SAP B1 Master Ledger Data Cleansing Script',
    description: 'De-duplicate customer records and normalize currency codes before staging migration.',
    project: 'SAP Business One Integration & Migration',
    projectId: 'proj-3',
    status: 'To Do',
    priority: 'Medium',
    assignee: 'Adam Vance',
    assigneeAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150',
    dueDate: '2026-08-15',
    createdAt: '2026-07-22',
    attachmentsCount: 2,
    commentsCount: 5,
    aiSuggestions: [
      'Use fuzzy string matching algorithm for duplicate company names'
    ]
  },
  {
    id: 'task-4',
    title: 'Implement HSM Key Rotation Mechanism',
    description: 'Configure automated 90-day cryptographic key rotation on CyberVault zero-trust gateways.',
    project: 'CyberVault 2.0 Security Architecture',
    projectId: 'proj-4',
    status: 'In Progress',
    priority: 'Critical',
    assignee: 'Sophia Sterling',
    assigneeAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=150',
    dueDate: '2026-08-20',
    createdAt: '2026-07-18',
    attachmentsCount: 5,
    commentsCount: 8,
    aiSuggestions: [
      'Ensure grace period window of 24 hours during key active migration'
    ]
  },
  {
    id: 'task-5',
    title: 'Deploy Production Cloud Run Microservices Cluster',
    description: 'Finalize Terraform definitions and setup multi-region Cloud Run container failover.',
    project: 'Sunshine Education ERP',
    projectId: 'proj-1',
    status: 'Completed',
    priority: 'High',
    assignee: 'Elena Rostova',
    assigneeAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=150',
    dueDate: '2026-07-28',
    createdAt: '2026-07-22',
    completedAt: '2026-07-27',
    completionDays: 5,
    attachmentsCount: 3,
    commentsCount: 14,
    aiSuggestions: [
      'Cluster health check completed with 100% green status'
    ]
  },
  {
    id: 'task-6',
    title: 'Audit Vault Security Cryptographic Certificate Chains',
    description: 'Perform formal compliance check on X.509 root authority certificates across node endpoints.',
    project: 'CyberVault 2.0 Security Architecture',
    projectId: 'proj-4',
    status: 'Completed',
    priority: 'Critical',
    assignee: 'Sophia Sterling',
    assigneeAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=150',
    dueDate: '2026-07-25',
    createdAt: '2026-07-21',
    completedAt: '2026-07-24',
    completionDays: 3,
    attachmentsCount: 6,
    commentsCount: 9,
    aiSuggestions: [
      'Zero expired certificates detected across all 4 production nodes'
    ]
  },
  {
    id: 'task-7',
    title: 'Setup System Monitoring Dashboard & Alert Rules',
    description: 'Configure Prometheus scrapers and Grafana metrics for API latency and DB query bottlenecks.',
    project: 'GovTech Citizen Portal Transformation',
    projectId: 'proj-5',
    status: 'Completed',
    priority: 'Low',
    assignee: 'Adam Vance',
    assigneeAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150',
    dueDate: '2026-07-20',
    createdAt: '2026-07-16',
    completedAt: '2026-07-18',
    completionDays: 2,
    attachmentsCount: 1,
    commentsCount: 4,
    aiSuggestions: [
      'Alert thresholds verified against SLA targets'
    ]
  },
  {
    id: 'task-8',
    title: 'User Onboarding Documentation & Knowledge Base Polish',
    description: 'Update user guides and developer API references in the central document repository.',
    project: 'Sunshine Education ERP',
    projectId: 'proj-1',
    status: 'To Do',
    priority: 'Low',
    assignee: 'David Okafor',
    assigneeAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150',
    dueDate: '2026-08-25',
    createdAt: '2026-07-28',
    attachmentsCount: 2,
    commentsCount: 2,
    aiSuggestions: [
      'Auto-generate OpenAPI spec from Express endpoints'
    ]
  }
];

export const INITIAL_ACTIVITY_LOGS: ActivityLog[] = [
  {
    id: 'act-1',
    user: 'Adam Vance',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150',
    action: 'uploaded',
    target: 'Warehouse_Robotics_API_Authentication_Specs.pdf',
    timestamp: '10 minutes ago',
    type: 'upload'
  },
  {
    id: 'act-2',
    user: 'Axion AI Assistant',
    userAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=AxionAI',
    action: 'generated executive update for',
    target: 'Sunshine Education ERP',
    timestamp: '25 minutes ago',
    type: 'ai'
  },
  {
    id: 'act-3',
    user: 'Marcus Chen',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150',
    action: 'moved project to Review stage:',
    target: 'Warehouse AI Autonomous Robotics',
    timestamp: '1 hour ago',
    type: 'status'
  },
  {
    id: 'act-4',
    user: 'Sophia Sterling',
    userAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=150',
    action: 'updated security policy in',
    target: 'Secure Vault (AES-256 HSM)',
    timestamp: '3 hours ago',
    type: 'vault'
  },
  {
    id: 'act-5',
    user: 'David Okafor',
    userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150',
    action: 'commented on task:',
    target: 'Final UAT for Sunshine ERP',
    timestamp: '5 hours ago',
    type: 'comment'
  }
];

export const INITIAL_VAULT_RECORDS: VaultRecord[] = [
  {
    id: 'vlt-1',
    title: 'Ministry_Defense_Contract_Signed_2026.enc',
    category: 'Sensitive Contracts',
    fileSize: '42.8 MB',
    encryptionAlgorithm: 'AES-256-GCM (Hardware HSM)',
    securityRating: 'Top Secret Level 5',
    accessCount: 14,
    lastAccessed: '2026-07-28 14:22:01 UTC',
    owner: 'Sophia Sterling',
    accessUsers: ['Sophia Sterling', 'Adam Vance'],
    aiRiskAnalysis: 'Zero compliance flags. Legal terms locked under federal non-disclosure protocols.'
  },
  {
    id: 'vlt-2',
    title: 'Axion_Q2_Financial_Audit_Master_Ledger.enc',
    category: 'Financial Records',
    fileSize: '112.4 MB',
    encryptionAlgorithm: 'Double-Wrapped RSA-4096 + AES-256',
    securityRating: 'Restricted Executive Only',
    accessCount: 8,
    lastAccessed: '2026-07-26 09:15:30 UTC',
    owner: 'Marcus Chen',
    accessUsers: ['Sophia Sterling', 'Marcus Chen'],
    aiRiskAnalysis: 'Revenue reconciliation verified against Oracle Cloud Financials with 0% discrepancy.'
  },
  {
    id: 'vlt-3',
    title: 'Global_Logistics_IP_Co-Ownership_Agreement.enc',
    category: 'Client Agreements',
    fileSize: '19.1 MB',
    encryptionAlgorithm: 'AES-256-GCM',
    securityRating: 'Confidential Legal',
    accessCount: 22,
    lastAccessed: '2026-07-27 18:04:12 UTC',
    owner: 'Sophia Sterling',
    accessUsers: ['Sophia Sterling', 'Adam Vance', 'Marcus Chen'],
    aiRiskAnalysis: 'Patent rights exclusively assigned to Axion Technologies for all autonomous navigation algorithms.'
  },
  {
    id: 'vlt-4',
    title: 'ISO_27001_FIPS_140_3_Compliance_Certificates.enc',
    category: 'Certificates',
    fileSize: '8.4 MB',
    encryptionAlgorithm: 'ChaCha20-Poly1305',
    securityRating: 'Verified Compliance',
    accessCount: 45,
    lastAccessed: '2026-07-29 01:10:00 UTC',
    owner: 'Elena Rostova',
    accessUsers: ['Sophia Sterling', 'Elena Rostova', 'Adam Vance'],
    aiRiskAnalysis: 'Valid through November 2028. Annual re-certification audit scheduled for Q3 2027.'
  }
];

export type ViewType = 
  | 'dashboard' 
  | 'projects' 
  | 'documents' 
  | 'ai-knowledge' 
  | 'tasks' 
  | 'team' 
  | 'analytics' 
  | 'vault' 
  | 'settings';

export type ProjectStatus = 'Planning' | 'In Progress' | 'Review' | 'Completed' | 'On Hold';
export type ProjectPriority = 'Low' | 'Medium' | 'High' | 'Critical';

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: string;
  department: string;
  avatar: string;
  status: 'Online' | 'Busy' | 'Away' | 'Offline';
  permissions: ('Admin' | 'Write' | 'Read' | 'Vault Access')[];
  assignedProjects: string[];
}

export interface Project {
  id: string;
  name: string;
  client: string;
  description: string;
  status: ProjectStatus;
  priority: ProjectPriority;
  progress: number;
  budget: string;
  spent: string;
  startDate: string;
  deadline: string;
  manager: string;
  team: string[]; // TeamMember IDs or names
  lastActivity: string;
  category: string;
  tags: string[];
  architectureOverview?: string;
  riskScore?: number; // 1-100
}

export type DocumentCategory = 
  | 'Contracts'
  | 'Proposals'
  | 'Invoices'
  | 'Requirements'
  | 'Database'
  | 'API'
  | 'Design'
  | 'UI/UX'
  | 'Testing'
  | 'Deployment'
  | 'Reports'
  | 'Legal'
  | 'Presentations'
  | 'Images'
  | 'Videos'
  | 'Source Code';

export interface DocumentItem {
  id: string;
  name: string;
  project: string;
  projectId: string;
  category: DocumentCategory;
  extension: string;
  fileSize: string;
  version: string;
  uploader: string;
  lastModified: string;
  aiSummary: string;
  tags: string[];
  securityLevel: 'Public' | 'Internal' | 'Confidential' | 'Restricted (Vault)';
  extractedEntities?: string[];
  contentSnippet?: string;
  fullText?: string;
  isVaultOnly?: boolean;
}

export type TaskStatus = 'To Do' | 'In Progress' | 'Review' | 'Completed';

export interface TaskItem {
  id: string;
  title: string;
  description: string;
  project: string;
  projectId: string;
  status: TaskStatus;
  priority: ProjectPriority;
  assignee: string;
  assigneeAvatar?: string;
  dueDate: string;
  createdAt?: string;
  completedAt?: string;
  completionDays?: number; // Days taken to complete
  attachmentsCount: number;
  commentsCount: number;
  aiSuggestions?: string[];
}

export interface ActivityLog {
  id: string;
  user: string;
  userAvatar: string;
  action: string;
  target: string;
  timestamp: string;
  type: 'upload' | 'ai' | 'status' | 'vault' | 'comment';
}

export interface VaultRecord {
  id: string;
  title: string;
  category: 'Sensitive Contracts' | 'Legal Documents' | 'Financial Records' | 'Client Agreements' | 'Certificates' | 'Identity Documents';
  fileSize: string;
  encryptionAlgorithm: string;
  securityRating: string;
  accessCount: number;
  lastAccessed: string;
  owner: string;
  accessUsers: string[];
  aiRiskAnalysis: string;
}

export interface SearchResult {
  id: string;
  title: string;
  type: 'Project' | 'Document' | 'Task' | 'Knowledge' | 'Vault';
  subtitle: string;
  snippet: string;
  score: number;
  matchType: string;
  item: Project | DocumentItem | TaskItem | VaultRecord;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  sources?: { title: string; type: string; id?: string }[];
  actionButtons?: string[];
  isStreaming?: boolean;
}

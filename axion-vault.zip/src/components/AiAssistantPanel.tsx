import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, 
  X, 
  Send, 
  Bot, 
  User, 
  FileText, 
  AlertTriangle, 
  RefreshCw, 
  Copy, 
  Check, 
  Maximize2, 
  Minimize2,
  FolderKanban,
  FileSearch,
  ShieldAlert,
  Zap
} from 'lucide-react';
import { ChatMessage, Project, DocumentItem } from '../types';

interface AiAssistantPanelProps {
  isOpen: boolean;
  onClose: () => void;
  projects?: Project[];
  documents?: DocumentItem[];
  context?: Project | DocumentItem | null;
  selectedProjectContext?: Project | null;
  selectedDocContext?: DocumentItem | null;
}

export const AiAssistantPanel: React.FC<AiAssistantPanelProps> = ({
  isOpen,
  onClose,
  projects,
  documents,
  context,
  selectedProjectContext,
  selectedDocContext
}) => {
  const isDocument = (ctx: any): ctx is DocumentItem => ctx && ('category' in ctx || 'aiSummary' in ctx || 'fileSize' in ctx);
  const isProject = (ctx: any): ctx is Project => ctx && ('client' in ctx || 'budget' in ctx || 'progress' in ctx);

  const activeDoc = selectedDocContext || (isDocument(context) ? context : null);
  const activeProject = selectedProjectContext || (isProject(context) ? context : null);

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-welcome',
      sender: 'assistant',
      text: `### Welcome to Axion AI\n**Enterprise Knowledge Assistant**\n\nI am connected to all **${projects?.length || 0} workspace projects** and **${documents?.length || 0} enterprise documents**.\n\nHow can I assist your team today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      actionButtons: ['Summarize Sunshine ERP', 'Analyze Project Risks', 'Compare Document Versions', 'Generate Executive Report']
    }
  ]);
  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isExpanded, setIsExpanded] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  useEffect(() => {
    if (isOpen && activeDoc) {
      const docMsgId = `msg-doc-ctx-${activeDoc.id}`;
      setMessages(prev => {
        if (prev.some(m => m.id === docMsgId)) return prev;
        return [
          ...prev,
          {
            id: docMsgId,
            sender: 'assistant',
            text: `📄 **Document Chat Mode Active**: Connected to **${activeDoc.name}** (${activeDoc.category}).\n\n**Executive Summary**: ${activeDoc.aiSummary}\n\nAsk me anything about clauses, SLAs, technical obligations, or risk factors contained in this document!`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            actionButtons: [
              `Summarize ${activeDoc.name}`,
              `Extract SLAs & Terms`,
              `Evaluate Risks in ${activeDoc.name}`
            ]
          }
        ];
      });
    }
  }, [isOpen, activeDoc]);

  if (!isOpen) return null;

  const handleSendPrompt = async (customPrompt?: string) => {
    const promptToUse = customPrompt || inputPrompt;
    if (!promptToUse.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: promptToUse,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!customPrompt) setInputPrompt('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptToUse,
          contextProject: activeProject?.name,
          contextDoc: activeDoc?.name,
          docSnippet: activeDoc?.contentSnippet,
          docSummary: activeDoc?.aiSummary
        })
      });

      const data = await response.json();

      const assistantMsg: ChatMessage = {
        id: `msg-ai-${Date.now()}`,
        sender: 'assistant',
        text: data.text || "No synthesis received from Axion AI.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err) {
      console.error("AI Assistant request failed:", err);
      const errorMsg: ChatMessage = {
        id: `msg-err-${Date.now()}`,
        sender: 'assistant',
        text: "⚠️ **Axion AI Gateway Notice**: Re-establishing connection with Gemini 3.6 Flash reasoning node. Please try again in a moment.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const presetCapabilities = [
    { label: "Summarize Documents", prompt: "Summarize the key contractual obligations and SLAs across active project documents." },
    { label: "Analyze Project Risks", prompt: "Analyze current project risks and budget variances across all active projects." },
    { label: "Generate Project Update", prompt: "Generate an executive project update for Sunshine Education ERP for C-suite presentation." },
    { label: "Compare Document Versions", prompt: "Compare CyberVault v4.1 requirements document with Sunshine ERP deployment specs." }
  ];

  return (
    <div 
      className={`fixed top-16 right-0 bottom-8 bg-[#0A1228] border-l border-[#2563EB]/40 shadow-2xl z-40 flex flex-col transition-all duration-300 font-sans ${
        isExpanded ? 'w-full md:w-[650px]' : 'w-full sm:w-[420px]'
      }`}
      id="axion-ai-assistant-panel"
    >
      {/* Panel Top Header */}
      <div className="p-4 bg-[#050B18] border-b border-[#101B35] flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#2563EB]/20 border border-[#4DA3FF]/40 flex items-center justify-center text-[#4DA3FF] shadow-[0_0_12px_rgba(37,99,235,0.4)]">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              Axion AI
              <span className="px-1.5 py-0.2 bg-[#2563EB]/20 text-[#4DA3FF] text-[10px] font-mono rounded border border-[#2563EB]/30">
                Gemini 3.6
              </span>
            </h2>
            <p className="text-[11px] text-[#94A3B8]">Enterprise Knowledge Assistant</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 text-[#94A3B8] hover:text-white rounded-lg hover:bg-[#101B35] transition-colors"
            title={isExpanded ? "Collapse width" : "Expand width"}
          >
            {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
          <button
            onClick={onClose}
            className="p-1.5 text-[#94A3B8] hover:text-white rounded-lg hover:bg-[#101B35] transition-colors"
            id="close-axion-ai-panel-btn"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Selected Context Banner */}
      {(activeProject || activeDoc) && (
        <div className="px-4 py-2 bg-[#101B35]/90 border-b border-[#2563EB]/30 flex items-center justify-between text-xs text-[#4DA3FF] font-mono shrink-0">
          <span className="flex items-center gap-2 truncate">
            <Zap className="w-3.5 h-3.5 shrink-0 text-[#4DA3FF]" />
            <span>Focus: {activeDoc ? `Doc: ${activeDoc.name}` : `Project: ${activeProject?.name}`}</span>
          </span>
          <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded text-white shrink-0 font-bold">
            {activeDoc ? 'DOC CHAT ACTIVE' : 'ACTIVE'}
          </span>
        </div>
      )}

      {/* Preset Action Chips */}
      <div className="p-3 bg-[#0A1228] border-b border-[#101B35] flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
        {presetCapabilities.map((cap, i) => (
          <button
            key={i}
            onClick={() => handleSendPrompt(cap.prompt)}
            disabled={isLoading}
            className="px-2.5 py-1 bg-[#101B35] hover:bg-[#2563EB]/20 border border-[#2563EB]/30 rounded-lg text-[11px] text-[#94A3B8] hover:text-[#4DA3FF] whitespace-nowrap transition-all font-medium disabled:opacity-50"
          >
            {cap.label}
          </button>
        ))}
      </div>

      {/* Chat Messages Log */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar bg-[#050B18]/40">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-start gap-3 ${
              msg.sender === 'user' ? 'flex-row-reverse' : ''
            }`}
          >
            {/* Avatar */}
            <div
              className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-xs font-semibold ${
                msg.sender === 'user'
                  ? 'bg-[#2563EB] text-white ring-2 ring-[#4DA3FF]/40'
                  : 'bg-[#101B35] text-[#4DA3FF] border border-[#2563EB]/30'
              }`}
            >
              {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>

            {/* Content Bubble */}
            <div className={`max-w-[85%] space-y-2 ${msg.sender === 'user' ? 'text-right' : ''}`}>
              <div
                className={`p-3.5 rounded-2xl text-xs leading-relaxed font-sans ${
                  msg.sender === 'user'
                    ? 'bg-[#2563EB] text-white rounded-tr-none shadow-md'
                    : 'bg-[#101B35] text-slate-200 border border-[#2563EB]/30 rounded-tl-none shadow-lg'
                }`}
              >
                <div className="prose prose-invert max-w-none whitespace-pre-wrap text-xs">
                  {msg.text}
                </div>

                {/* Quick Action Buttons inside message */}
                {msg.actionButtons && msg.actionButtons.length > 0 && (
                  <div className="mt-3 pt-2 border-t border-[#2563EB]/30 flex flex-wrap gap-1.5">
                    {msg.actionButtons.map((btn, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSendPrompt(btn)}
                        className="text-[10px] bg-[#050B18] hover:bg-[#2563EB] text-[#4DA3FF] hover:text-white px-2 py-1 rounded border border-[#2563EB]/30 transition-colors"
                      >
                        {btn}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Timestamp & Copy */}
              <div className="flex items-center gap-2 px-1 text-[10px] text-[#94A3B8]/70 font-mono">
                <span>{msg.timestamp}</span>
                {msg.sender === 'assistant' && (
                  <button
                    onClick={() => handleCopyText(msg.id, msg.text)}
                    className="hover:text-white transition-colors"
                    title="Copy text"
                  >
                    {copiedId === msg.id ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded-lg bg-[#101B35] text-[#4DA3FF] border border-[#2563EB]/30 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 animate-spin" />
            </div>
            <div className="p-3 bg-[#101B35] rounded-2xl rounded-tl-none border border-[#2563EB]/30 flex items-center gap-2 text-xs text-[#94A3B8]">
              <Sparkles className="w-4 h-4 text-[#4DA3FF] animate-pulse" />
              <span>Axion AI Knowledge Engine synthesizing response...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Bottom Input Form */}
      <div className="p-3 bg-[#050B18] border-t border-[#101B35] shrink-0">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendPrompt();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            placeholder="Ask Axion AI about projects, risks, or contracts..."
            disabled={isLoading}
            className="flex-1 bg-[#101B35] border border-[#2563EB]/30 focus:border-[#4DA3FF] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-[#94A3B8] focus:outline-none transition-colors font-sans"
            id="axion-ai-input-field"
          />
          <button
            type="submit"
            disabled={!inputPrompt.trim() || isLoading}
            className="p-2.5 bg-gradient-to-r from-[#2563EB] to-[#0D3B8F] hover:from-[#3b82f6] hover:to-[#1d4ed8] text-white rounded-xl disabled:opacity-40 transition-all border border-[#4DA3FF]/30 shrink-0 shadow-md active:scale-95"
            id="axion-ai-send-btn"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
        <div className="flex items-center justify-between mt-2 text-[10px] text-[#94A3B8]/60 font-mono px-1">
          <span>SECURE AGENT ENDPOINT</span>
          <span>POWERED BY GEMINI 3.6 FLASH</span>
        </div>
      </div>
    </div>
  );
};

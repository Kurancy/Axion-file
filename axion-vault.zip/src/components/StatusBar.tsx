import React from 'react';
import { ShieldCheck, Cpu, Activity, Server, Lock, Radio, HelpCircle, Keyboard } from 'lucide-react';

interface StatusBarProps {
  onOpenShortcuts?: () => void;
}

export const StatusBar: React.FC<StatusBarProps> = ({ onOpenShortcuts }) => {
  return (
    <footer className="h-8 bg-[#050B18] border-t border-[#101B35] px-6 flex items-center justify-between text-[11px] font-mono text-[#94A3B8] shrink-0 select-none z-10" id="axion-status-bar">
      
      {/* Left System Info */}
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="text-white font-semibold">SYSTEM: OPERATIONAL (99.98%)</span>
        </div>

        <div className="hidden sm:flex items-center gap-1.5 text-[#94A3B8]">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>AES-256-GCM ENCRYPTED</span>
        </div>

        <div className="hidden md:flex items-center gap-1.5 text-[#94A3B8]">
          <Cpu className="w-3.5 h-3.5 text-[#4DA3FF]" />
          <span>AXION AI: GEMINI 3.6 FLASH</span>
        </div>
      </div>

      {/* Right Metrics & Shortcuts Button */}
      <div className="flex items-center gap-4 sm:gap-6">
        <div className="hidden lg:flex items-center gap-1.5">
          <Radio className="w-3.5 h-3.5 text-[#2563EB] animate-pulse" />
          <span>LATENCY: 14ms</span>
        </div>

        <div className="hidden sm:flex items-center gap-1.5">
          <Server className="w-3.5 h-3.5 text-[#4DA3FF]" />
          <span>REGION: US-CENTRAL1-A</span>
        </div>

        <div className="hidden md:flex items-center gap-1 text-[#4DA3FF]">
          <Lock className="w-3 h-3" />
          <span>TLS 1.3 ACTIVE</span>
        </div>

        {/* Keyboard Shortcuts Trigger Button */}
        {onOpenShortcuts && (
          <button
            onClick={onOpenShortcuts}
            className="flex items-center gap-1.5 px-2 py-0.5 bg-[#101B35] hover:bg-[#101B35]/80 text-[#4DA3FF] hover:text-white rounded border border-[#2563EB]/30 transition-all font-mono text-[10px]"
            title="Keyboard Shortcuts Cheat Sheet (? or Ctrl+K)"
          >
            <Keyboard className="w-3 h-3 text-[#4DA3FF]" />
            <span className="hidden sm:inline">SHORTCUTS</span>
            <span className="px-1 bg-[#050B18] text-[#94A3B8] rounded text-[9px]">?</span>
          </button>
        )}
      </div>

    </footer>
  );
};


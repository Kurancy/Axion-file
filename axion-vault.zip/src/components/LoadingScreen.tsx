import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, Cpu, Database, CheckCircle2 } from 'lucide-react';

interface LoadingScreenProps {
  onComplete: () => void;
}

const statusSteps = [
  { text: "Initializing secure workspace...", icon: ShieldCheck },
  { text: "Connecting knowledge engine...", icon: Cpu },
  { text: "Loading project intelligence...", icon: Database },
  { text: "Ready.", icon: CheckCircle2 }
];

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // Step progression timer
    const stepInterval = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev < statusSteps.length - 1) {
          return prev + 1;
        }
        clearInterval(stepInterval);
        return prev;
      });
    }, 700);

    // Smooth progress bar fill
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          setTimeout(() => {
            onComplete();
          }, 500);
          return 100;
        }
        return prev + 4;
      });
    }, 100);

    return () => {
      clearInterval(stepInterval);
      clearInterval(progressInterval);
    };
  }, [onComplete]);

  const CurrentIcon = statusSteps[currentStep]?.icon || ShieldCheck;

  return (
    <motion.div 
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.6, ease: "easeInOut" } }}
      className="fixed inset-0 z-50 bg-[#050B18] flex flex-col items-center justify-center p-6 select-none overflow-hidden"
      id="axion-cinematic-loader"
    >
      {/* Background Subtle Gradient & Grid FX */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(37,99,235,0.15)_0,transparent_70%)]" />
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(16,27,53,0.3)_1px,transparent_1px),linear-gradient(to_bottom,rgba(16,27,53,0.3)_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)]" />

      {/* Center Cinematic Container */}
      <div className="relative z-10 flex flex-col items-center max-w-md w-full text-center">
        
        {/* Animated Four Square Logo Blocks */}
        <div className="relative mb-8">
          {/* Pulsing Back Glow */}
          <motion.div 
            animate={{ scale: [0.9, 1.25, 1], opacity: [0.3, 0.7, 0.4] }}
            transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
            className="absolute -inset-6 rounded-full bg-[#4DA3FF]/20 blur-xl"
          />

          <div className="relative w-24 h-24 bg-[#0A1228] border border-[#2563EB]/40 rounded-2xl p-2.5 grid grid-cols-2 grid-rows-2 gap-2 shadow-[0_0_35px_rgba(37,99,235,0.4)]">
            {/* Top Left: #4DA3FF */}
            <motion.div 
              initial={{ scale: 0, x: -20, y: -20 }}
              animate={{ scale: 1, x: 0, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="bg-[#4DA3FF] rounded-lg shadow-[0_0_12px_#4DA3FF]"
            />
            {/* Top Right: #0D3B8F */}
            <motion.div 
              initial={{ scale: 0, x: 20, y: -20 }}
              animate={{ scale: 1, x: 0, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-[#0D3B8F] rounded-lg"
            />
            {/* Bottom Left: #0D3B8F */}
            <motion.div 
              initial={{ scale: 0, x: -20, y: 20 }}
              animate={{ scale: 1, x: 0, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="bg-[#0D3B8F] rounded-lg"
            />
            {/* Bottom Right: #4DA3FF */}
            <motion.div 
              initial={{ scale: 0, x: 20, y: 20 }}
              animate={{ scale: 1, x: 0, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="bg-[#4DA3FF] rounded-lg shadow-[0_0_12px_#4DA3FF]"
            />
          </div>
        </div>

        {/* Brand Name & Tagline */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="space-y-1 mb-8"
        >
          <h1 className="text-3xl font-extrabold tracking-wider text-white font-sans">
            AXION <span className="text-[#4DA3FF]">VAULT</span>
          </h1>
          <p className="text-sm font-medium text-[#94A3B8] tracking-widest uppercase">
            Enterprise Project Intelligence Platform
          </p>
        </motion.div>

        {/* Status Line */}
        <div className="w-full bg-[#101B35]/80 backdrop-blur-md border border-[#2563EB]/30 rounded-xl p-4 shadow-lg mb-4">
          <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-2 font-mono">
            <span className="flex items-center gap-2 text-white font-medium">
              <CurrentIcon className="w-4 h-4 text-[#4DA3FF] animate-pulse" />
              <AnimatePresence mode="wait">
                <motion.span
                  key={currentStep}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  transition={{ duration: 0.2 }}
                >
                  {statusSteps[currentStep].text}
                </motion.span>
              </AnimatePresence>
            </span>
            <span className="text-[#4DA3FF] font-semibold">{progress}%</span>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-1.5 bg-[#0A1228] rounded-full overflow-hidden p-0.5 border border-white/5">
            <motion.div 
              className="h-full bg-gradient-to-r from-[#0D3B8F] via-[#2563EB] to-[#4DA3FF] rounded-full shadow-[0_0_10px_#4DA3FF]"
              style={{ width: `${progress}%` }}
              transition={{ ease: "easeOut" }}
            />
          </div>
        </div>

        <div className="flex items-center justify-between w-full text-[11px] text-[#94A3B8]/70 font-mono px-1">
          <span>SECURE PROTOCOL: TLS 1.3 AES-256</span>
          <span>NODE: US-CENTRAL1</span>
        </div>

      </div>
    </motion.div>
  );
};

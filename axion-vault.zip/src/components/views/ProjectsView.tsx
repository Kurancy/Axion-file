import React, { useState } from 'react';
import { 
  FolderKanban, 
  Plus, 
  Search, 
  Filter, 
  ChevronRight, 
  Calendar, 
  DollarSign, 
  User, 
  Users, 
  Sparkles, 
  FileText, 
  CheckSquare, 
  Video, 
  Cpu, 
  BarChart3, 
  Settings, 
  Clock, 
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  ShieldCheck,
  TrendingUp,
  Layers
} from 'lucide-react';
import { Project, DocumentItem, TaskItem } from '../../types';

interface ProjectsViewProps {
  projects: Project[];
  documents: DocumentItem[];
  tasks: TaskItem[];
  selectedProject: Project | null;
  onSelectProject: (proj: Project | null) => void;
  onOpenNewProjectModal: () => void;
  onOpenAiAssistantWithContext: (proj: Project) => void;
  onSelectDocument: (doc: DocumentItem) => void;
}

type ProjectTab = 
  | 'Overview' 
  | 'Documents' 
  | 'Tasks' 
  | 'Meetings' 
  | 'Architecture' 
  | 'AI Assistant' 
  | 'Files' 
  | 'Analytics' 
  | 'Settings';

export const ProjectsView: React.FC<ProjectsViewProps> = ({
  projects,
  documents,
  tasks,
  selectedProject,
  onSelectProject,
  onOpenNewProjectModal,
  onOpenAiAssistantWithContext,
  onSelectDocument
}) => {
  const [activeTab, setActiveTab] = useState<ProjectTab>('Overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [aiRiskReport, setAiRiskReport] = useState<any | null>(null);
  const [isAnalyzingRisk, setIsAnalyzingRisk] = useState(false);

  // Filter projects
  const filteredProjects = (projects || []).filter(p => {
    const matchesSearch = (p.name || '').toLowerCase().includes(searchQuery.toLowerCase()) || (p.client || '').toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'All' || p.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleAnalyzeRisk = async (projId: string) => {
    setIsAnalyzingRisk(true);
    try {
      const res = await fetch('/api/ai/analyze-risk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId: projId })
      });
      const data = await res.json();
      setAiRiskReport(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzingRisk(false);
    }
  };

  // If a project is selected, show Project Detail Workspace
  if (selectedProject) {
    const projDocs = documents.filter(d => d.projectId === selectedProject.id || d.project === selectedProject.name);
    const projTasks = tasks.filter(t => t.projectId === selectedProject.id || t.project === selectedProject.name);

    return (
      <div className="p-6 space-y-6 max-w-7xl mx-auto font-sans" id="axion-project-detail-workspace">
        
        {/* Top Detail Navigation Header */}
        <div className="flex items-center justify-between border-b border-[#101B35] pb-4">
          <button
            onClick={() => onSelectProject(null)}
            className="flex items-center gap-2 px-3 py-1.5 bg-[#101B35] hover:bg-[#101B35]/80 text-[#94A3B8] hover:text-white rounded-xl text-xs font-mono border border-[#2563EB]/20 transition-all"
          >
            <ArrowLeft className="w-4 h-4 text-[#4DA3FF]" />
            <span>Back to All Projects</span>
          </button>

          <div className="flex items-center gap-3">
            <button
              onClick={() => handleAnalyzeRisk(selectedProject.id)}
              disabled={isAnalyzingRisk}
              className="flex items-center gap-2 px-3.5 py-1.5 bg-[#101B35] hover:bg-[#2563EB]/20 text-[#4DA3FF] rounded-xl text-xs font-semibold border border-[#2563EB]/40 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5 animate-pulse" />
              <span>{isAnalyzingRisk ? 'Evaluating Risk...' : 'AI Risk Audit'}</span>
            </button>

            <button
              onClick={() => onOpenAiAssistantWithContext(selectedProject)}
              className="flex items-center gap-2 px-4 py-1.5 bg-gradient-to-r from-[#2563EB] to-[#0D3B8F] hover:from-[#3b82f6] text-white rounded-xl text-xs font-semibold border border-[#4DA3FF]/30 shadow-md"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#4DA3FF]" />
              <span>Axion AI Assistant</span>
            </button>
          </div>
        </div>

        {/* Project Header Banner */}
        <div className="p-6 rounded-2xl bg-[#0A1228] border border-[#2563EB]/30 shadow-2xl space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-3 mb-1">
                <span className="text-xs font-mono bg-[#2563EB]/20 text-[#4DA3FF] px-2.5 py-0.5 rounded-full border border-[#2563EB]/30">
                  {selectedProject.category}
                </span>
                <span className={`text-xs font-mono px-2.5 py-0.5 rounded-full font-semibold ${
                  selectedProject.status === 'In Progress' ? 'bg-[#2563EB]/20 text-[#4DA3FF]' :
                  selectedProject.status === 'Completed' ? 'bg-emerald-500/20 text-emerald-400' :
                  'bg-purple-500/20 text-purple-300'
                }`}>
                  {selectedProject.status}
                </span>
              </div>
              <h1 className="text-2xl font-black text-white tracking-tight">{selectedProject.name}</h1>
              <p className="text-xs text-[#94A3B8] font-mono mt-0.5">Client: {selectedProject.client}</p>
            </div>

            <div className="flex items-center gap-6 bg-[#050B18] p-3 rounded-xl border border-white/5 text-xs font-mono">
              <div>
                <span className="text-[#94A3B8] block text-[10px]">BUDGET / SPENT</span>
                <span className="text-white font-bold">{selectedProject.spent} / {selectedProject.budget}</span>
              </div>
              <div className="h-6 w-px bg-[#101B35]" />
              <div>
                <span className="text-[#94A3B8] block text-[10px]">DEADLINE</span>
                <span className="text-[#4DA3FF] font-bold">{selectedProject.deadline}</span>
              </div>
              <div className="h-6 w-px bg-[#101B35]" />
              <div>
                <span className="text-[#94A3B8] block text-[10px]">RISK INDEX</span>
                <span className="text-emerald-400 font-bold">{selectedProject.riskScore || 18} / 100</span>
              </div>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">{selectedProject.description}</p>

          {/* Progress Bar */}
          <div className="space-y-1 pt-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-[#94A3B8]">Overall Delivery Completion</span>
              <span className="text-white font-bold">{selectedProject.progress}%</span>
            </div>
            <div className="w-full h-2 bg-[#050B18] rounded-full overflow-hidden p-0.5 border border-white/5">
              <div 
                className="h-full bg-gradient-to-r from-[#0D3B8F] via-[#2563EB] to-[#4DA3FF] rounded-full shadow-[0_0_10px_#4DA3FF]"
                style={{ width: `${selectedProject.progress}%` }}
              />
            </div>
          </div>
        </div>

        {/* 9 Workspace Tabs */}
        <div className="border-b border-[#101B35] flex items-center gap-2 overflow-x-auto no-scrollbar">
          {(['Overview', 'Documents', 'Tasks', 'Meetings', 'Architecture', 'AI Assistant', 'Files', 'Analytics', 'Settings'] as ProjectTab[]).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2.5 rounded-t-xl text-xs font-medium whitespace-nowrap transition-all border-b-2 font-sans ${
                activeTab === tab
                  ? 'border-[#4DA3FF] text-[#4DA3FF] bg-[#0A1228]'
                  : 'border-transparent text-[#94A3B8] hover:text-white hover:bg-[#101B35]'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Tab Content Display */}
        {activeTab === 'Overview' && (
          <div className="space-y-6">
            
            {/* AI Risk Audit Report Panel if active */}
            {aiRiskReport && (
              <div className="p-5 rounded-2xl bg-[#101B35] border border-[#2563EB]/40 shadow-xl space-y-3 font-sans">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-[#4DA3FF] font-mono flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    AXION AI RISK AUDIT REPORT
                  </h3>
                  <span className="text-xs font-mono bg-[#2563EB]/30 px-2 py-0.5 rounded text-white">
                    Risk Score: {aiRiskReport.riskScore || 18} ({aiRiskReport.riskLevel || 'Low'})
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="p-3 rounded-xl bg-[#050B18] border border-red-500/20 space-y-1">
                    <span className="text-red-400 font-bold block mb-1">Key Identified Risks</span>
                    {aiRiskReport.keyRisks?.map((r: string, idx: number) => (
                      <p key={idx} className="text-[#94A3B8]">• {r}</p>
                    ))}
                  </div>
                  <div className="p-3 rounded-xl bg-[#050B18] border border-emerald-500/20 space-y-1">
                    <span className="text-emerald-400 font-bold block mb-1">Recommended Mitigations</span>
                    {aiRiskReport.mitigations?.map((m: string, idx: number) => (
                      <p key={idx} className="text-[#94A3B8]">• {m}</p>
                    ))}
                  </div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2 space-y-6">
                
                {/* Manager & Team Roster */}
                <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl space-y-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Users className="w-4 h-4 text-[#4DA3FF]" />
                    Project Manager & Allocated Team
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="p-3 rounded-xl bg-[#101B35] border border-[#2563EB]/20 flex items-center gap-3">
                      <img
                        src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150"
                        alt={selectedProject.manager}
                        className="w-10 h-10 rounded-lg object-cover ring-2 ring-[#4DA3FF]"
                      />
                      <div>
                        <span className="text-[10px] text-[#4DA3FF] font-mono block">PROJECT MANAGER</span>
                        <h4 className="font-bold text-white">{selectedProject.manager}</h4>
                        <span className="text-[10px] text-[#94A3B8]">Solutions Architect</span>
                      </div>
                    </div>

                    {selectedProject.team?.map((member, i) => (
                      <div key={i} className="p-3 rounded-xl bg-[#101B35]/60 border border-white/5 flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-[#050B18] text-[#4DA3FF] border border-[#2563EB]/30 flex items-center justify-center font-bold text-sm">
                          {member.charAt(0)}
                        </div>
                        <div>
                          <h4 className="font-bold text-white">{member}</h4>
                          <span className="text-[10px] text-[#94A3B8]">Engine Specialist</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Activity Timeline */}
                <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl space-y-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Clock className="w-4 h-4 text-[#4DA3FF]" />
                    Project Activity Timeline
                  </h3>

                  <div className="space-y-3 text-xs">
                    <div className="p-3 rounded-xl bg-[#101B35]/60 border border-white/5 flex items-start gap-3">
                      <div className="w-2 h-2 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                      <div>
                        <span className="font-semibold text-white">Production Cluster Deployed</span>
                        <p className="text-[#94A3B8] text-[11px]">Multi-region Cloud Run container failover verified.</p>
                        <span className="text-[9px] text-[#94A3B8]/60 font-mono">Today, 10:14 AM</span>
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-[#101B35]/60 border border-white/5 flex items-start gap-3">
                      <div className="w-2 h-2 rounded-full bg-[#4DA3FF] mt-1.5 shrink-0" />
                      <div>
                        <span className="font-semibold text-white">Master Contract SLA Sign-off</span>
                        <p className="text-[#94A3B8] text-[11px]">99.99% availability agreement logged in Vault.</p>
                        <span className="text-[9px] text-[#94A3B8]/60 font-mono">Yesterday, 04:30 PM</span>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

              {/* Sidebar Info */}
              <div className="space-y-6">
                <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl space-y-3 text-xs">
                  <h3 className="font-bold text-white border-b border-[#101B35] pb-2 font-mono">PROJECT METADATA</h3>
                  <div className="space-y-2 text-[#94A3B8] font-mono">
                    <div className="flex justify-between"><span>Category:</span> <span className="text-white">{selectedProject.category}</span></div>
                    <div className="flex justify-between"><span>Start Date:</span> <span className="text-white">{selectedProject.startDate}</span></div>
                    <div className="flex justify-between"><span>Deadline:</span> <span className="text-white">{selectedProject.deadline}</span></div>
                    <div className="flex justify-between"><span>Security Level:</span> <span className="text-emerald-400">Confidential</span></div>
                  </div>
                </div>

                <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl space-y-3 text-xs">
                  <h3 className="font-bold text-white border-b border-[#101B35] pb-2 font-mono">LINKED ASSETS</h3>
                  <div className="space-y-2">
                    <div className="p-2.5 rounded-xl bg-[#101B35] flex items-center justify-between">
                      <span className="text-white">Documents</span>
                      <span className="px-2 py-0.5 bg-[#2563EB]/20 text-[#4DA3FF] rounded font-mono">{projDocs.length}</span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-[#101B35] flex items-center justify-between">
                      <span className="text-white">Active Tasks</span>
                      <span className="px-2 py-0.5 bg-[#2563EB]/20 text-[#4DA3FF] rounded font-mono">{projTasks.length}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        )}

        {activeTab === 'Documents' && (
          <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl space-y-4">
            <h3 className="text-sm font-bold text-white">Linked Documents for {selectedProject.name}</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {projDocs.map((doc) => (
                <div 
                  key={doc.id}
                  onClick={() => onSelectDocument(doc)}
                  className="p-3.5 bg-[#101B35] border border-[#2563EB]/20 rounded-xl cursor-pointer hover:border-[#4DA3FF]/40 transition-all space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-white truncate">{doc.name}</span>
                    <span className="text-[10px] font-mono bg-[#2563EB]/20 text-[#4DA3FF] px-2 py-0.5 rounded">{doc.category}</span>
                  </div>
                  <p className="text-[11px] text-[#94A3B8] line-clamp-2">{doc.aiSummary}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'Architecture' && (
          <div className="p-6 bg-[#0A1228] border border-[#101B35] rounded-2xl space-y-4 text-xs font-mono">
            <h3 className="text-sm font-bold text-white font-sans flex items-center gap-2">
              <Cpu className="w-4 h-4 text-[#4DA3FF]" />
              System Architecture & Infrastructure Design
            </h3>
            <p className="text-slate-300 leading-relaxed font-sans">{selectedProject.architectureOverview}</p>
            <div className="p-4 bg-[#050B18] border border-[#2563EB]/30 rounded-xl space-y-2">
              <span className="text-[#4DA3FF] font-bold">INFRASTRUCTURE STACK:</span>
              <p className="text-[#94A3B8]">• Node.js Express Backend Service on Port 3000</p>
              <p className="text-[#94A3B8]">• React 19 + Vite Frontend SPA with Framer Motion</p>
              <p className="text-[#94A3B8]">• PostgreSQL Cloud SQL Database Cluster</p>
              <p className="text-[#94A3B8]">• Gemini 3.6 Flash Server-side Intelligence Proxy</p>
            </div>
          </div>
        )}

        {(activeTab === 'Tasks' || activeTab === 'Meetings' || activeTab === 'AI Assistant' || activeTab === 'Files' || activeTab === 'Analytics' || activeTab === 'Settings') && (
          <div className="p-8 bg-[#0A1228] border border-[#101B35] rounded-2xl text-center space-y-3">
            <Sparkles className="w-8 h-8 text-[#4DA3FF] mx-auto animate-pulse" />
            <h3 className="text-sm font-bold text-white">{activeTab} Module Active</h3>
            <p className="text-xs text-[#94A3B8]">Connected to Axion Vault live telemetry stream for {selectedProject.name}.</p>
          </div>
        )}

      </div>
    );
  }

  // Otherwise, display list of all projects
  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto font-sans" id="axion-projects-list-view">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <FolderKanban className="w-6 h-6 text-[#4DA3FF]" />
            Enterprise Project Workspace
          </h1>
          <p className="text-xs text-[#94A3B8] font-mono mt-0.5">
            Managing {projects?.length || 0} strategic digital transformation projects
          </p>
        </div>

        <button
          onClick={onOpenNewProjectModal}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#2563EB] to-[#0D3B8F] hover:from-[#3b82f6] text-white rounded-xl text-xs font-semibold border border-[#4DA3FF]/40 shadow-lg transition-all"
        >
          <Plus className="w-4 h-4 text-[#4DA3FF]" />
          <span>New Enterprise Project</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-[#0A1228] border border-[#101B35] rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-[#4DA3FF] absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filter projects by name or client..."
            className="w-full bg-[#101B35] border border-[#2563EB]/20 focus:border-[#4DA3FF] rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-[#94A3B8] focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <Filter className="w-4 h-4 text-[#94A3B8]" />
          {['All', 'In Progress', 'Review', 'Completed'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                statusFilter === st
                  ? 'bg-[#2563EB] text-white'
                  : 'bg-[#101B35] text-[#94A3B8] hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Project Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProjects.map((proj) => (
          <div
            key={proj.id}
            onClick={() => onSelectProject(proj)}
            className="p-5 bg-[#0A1228] border border-[#101B35] hover:border-[#2563EB]/50 rounded-2xl shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer flex flex-col justify-between space-y-4 group"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono bg-[#2563EB]/20 text-[#4DA3FF] px-2.5 py-0.5 rounded-full border border-[#2563EB]/30">
                  {proj.category}
                </span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-semibold ${
                  proj.status === 'Completed' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                  proj.status === 'Review' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' :
                  'bg-[#2563EB]/20 text-[#4DA3FF] border border-[#2563EB]/30'
                }`}>
                  {proj.status}
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-white group-hover:text-[#4DA3FF] transition-colors">
                  {proj.name}
                </h3>
                <p className="text-xs text-[#94A3B8] font-mono mt-0.5">Client: {proj.client}</p>
              </div>

              <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                {proj.description}
              </p>
            </div>

            <div className="space-y-3 pt-3 border-t border-[#101B35]">
              {/* Progress */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <span className="text-[#94A3B8]">Progress</span>
                  <span className="text-white font-bold">{proj.progress}%</span>
                </div>
                <div className="w-full h-1.5 bg-[#050B18] rounded-full overflow-hidden p-0.5">
                  <div 
                    className="h-full bg-gradient-to-r from-[#0D3B8F] to-[#4DA3FF] rounded-full"
                    style={{ width: `${proj.progress}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] text-[#94A3B8] font-mono">
                <span>Budget: {proj.budget}</span>
                <span className="text-[#4DA3FF] font-semibold flex items-center gap-1">
                  Open Project
                  <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};

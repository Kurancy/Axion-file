import React from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Sparkles, 
  HardDrive, 
  Zap, 
  CheckCircle2, 
  Clock, 
  Users,
  ShieldCheck
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell,
  CartesianGrid
} from 'recharts';

const completionData = [
  { month: 'Q1 25', rate: 68, target: 70 },
  { month: 'Q2 25', rate: 74, target: 75 },
  { month: 'Q3 25', rate: 81, target: 80 },
  { month: 'Q4 25', rate: 88, target: 85 },
  { month: 'Q1 26', rate: 92, target: 90 },
  { month: 'Q2 26', rate: 96, target: 95 }
];

const departmentData = [
  { name: 'Engineering', value: 42, color: '#2563EB' },
  { name: 'Axion AI Labs', value: 28, color: '#4DA3FF' },
  { name: 'Cybersecurity', value: 18, color: '#8B5CF6' },
  { name: 'Infrastructure', value: 12, color: '#10B981' }
];

const storageGrowthData = [
  { month: 'Jan', storageGB: 110, costUSD: 220 },
  { month: 'Feb', storageGB: 145, costUSD: 290 },
  { month: 'Mar', storageGB: 180, costUSD: 360 },
  { month: 'Apr', storageGB: 210, costUSD: 420 },
  { month: 'May', storageGB: 232, costUSD: 464 },
  { month: 'Jun', storageGB: 248, costUSD: 496 }
];

export const AnalyticsView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto font-sans" id="axion-analytics-suite">
      
      {/* Header Bar */}
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
          <BarChart3 className="w-6 h-6 text-[#4DA3FF]" />
          Enterprise Analytics & Telemetry Engine
        </h1>
        <p className="text-xs text-[#94A3B8] font-mono mt-0.5">
          Real-time intelligence on delivery throughput, storage growth, and AI utilization
        </p>
      </div>

      {/* Top 4 Metric Summaries */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-[#0A1228] border border-[#101B35] rounded-2xl space-y-2">
          <span className="text-xs text-[#94A3B8] font-mono">PROJECT COMPLETION RATE</span>
          <div className="text-2xl font-bold text-white">96.2%</div>
          <p className="text-[10px] text-emerald-400 font-mono">+4.2% over target benchmark</p>
        </div>

        <div className="p-4 bg-[#0A1228] border border-[#101B35] rounded-2xl space-y-2">
          <span className="text-xs text-[#94A3B8] font-mono">AI ENGINE QUERY LATENCY</span>
          <div className="text-2xl font-bold text-[#4DA3FF]">14.2 ms</div>
          <p className="text-[10px] text-emerald-400 font-mono">Gemini 3.6 Flash optimal tier</p>
        </div>

        <div className="p-4 bg-[#0A1228] border border-[#101B35] rounded-2xl space-y-2">
          <span className="text-xs text-[#94A3B8] font-mono">STORAGE ALLOCATION</span>
          <div className="text-2xl font-bold text-purple-300">248 GB</div>
          <p className="text-[10px] text-[#94A3B8] font-mono">Of 1,000 GB enterprise cloud limit</p>
        </div>

        <div className="p-4 bg-[#0A1228] border border-[#101B35] rounded-2xl space-y-2">
          <span className="text-xs text-[#94A3B8] font-mono">PRODUCTIVITY INDEX</span>
          <div className="text-2xl font-bold text-emerald-400">98.8 / 100</div>
          <p className="text-[10px] text-emerald-400 font-mono">Zero SLA compliance breaches</p>
        </div>
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Chart 1: Project Completion Rate */}
        <div className="lg:col-span-2 p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl shadow-xl space-y-4">
          <div className="border-b border-[#101B35] pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-[#4DA3FF]" />
              Project Delivery & Target Completion Rate
            </h3>
            <p className="text-[11px] text-[#94A3B8]">Quarterly actual completion vs baseline SLA</p>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={completionData}>
                <defs>
                  <linearGradient id="rateGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#101B35" />
                <XAxis dataKey="month" stroke="#94A3B8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94A3B8" fontSize={11} tickLine={false} />
                <Tooltip contentStyle={{ backgroundColor: '#050B18', borderColor: '#2563EB', borderRadius: '12px', fontSize: '12px' }} />
                <Area type="monotone" dataKey="rate" name="Completion Rate (%)" stroke="#10B981" fill="url(#rateGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Department Activity Breakdown */}
        <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl shadow-xl space-y-4">
          <div className="border-b border-[#101B35] pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-[#4DA3FF]" />
              Department Activity Split
            </h3>
            <p className="text-[11px] text-[#94A3B8]">Workload distribution across units</p>
          </div>

          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={departmentData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={4}>
                  {departmentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#050B18', borderColor: '#2563EB', borderRadius: '12px', fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-1.5 text-xs font-mono">
            {departmentData.map((d, i) => (
              <div key={i} className="flex items-center justify-between text-[#94A3B8]">
                <span className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: d.color }} />
                  {d.name}
                </span>
                <span className="text-white font-bold">{d.value}%</span>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};

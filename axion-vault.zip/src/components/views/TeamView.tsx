import React from 'react';
import { 
  Users, 
  ShieldCheck, 
  CheckCircle2, 
  Clock, 
  Lock, 
  Activity, 
  Mail, 
  Building, 
  Sparkles,
  FileText
} from 'lucide-react';
import { TeamMember, ActivityLog } from '../../types';

interface TeamViewProps {
  team: TeamMember[];
  activities: ActivityLog[];
}

export const TeamView: React.FC<TeamViewProps> = ({ team, activities }) => {
  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto font-sans" id="axion-team-collaboration-module">
      
      {/* Header Bar */}
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
          <Users className="w-6 h-6 text-[#4DA3FF]" />
          Enterprise Team Collaboration & Access Control
        </h1>
          <p className="text-xs text-[#94A3B8] font-mono mt-0.5">
            Managing permissions, security levels, and live activities for {team?.length || 0} core specialists
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Team Members Roster Grid (Left 2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider">
              Active Specialist Roster
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {(team || []).map((member) => (
                <div
                  key={member.id}
                  className="p-4 bg-[#0A1228] border border-[#101B35] rounded-2xl shadow-xl space-y-3 hover:border-[#2563EB]/40 transition-all"
                >
                  <div className="flex items-start gap-3">
                    <div className="relative">
                      <img
                        src={member.avatar}
                        alt={member.name}
                        className="w-12 h-12 rounded-xl object-cover ring-2 ring-[#2563EB]/40"
                      />
                      <span className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full ring-2 ring-[#0A1228] ${
                        member.status === 'Online' ? 'bg-emerald-400' :
                        member.status === 'Busy' ? 'bg-amber-400' : 'bg-slate-500'
                      }`} />
                    </div>

                    <div className="min-w-0 flex-1">
                      <h4 className="text-xs font-bold text-white truncate">{member.name}</h4>
                      <p className="text-[11px] text-[#4DA3FF] font-mono truncate">{member.role}</p>
                      <p className="text-[10px] text-[#94A3B8] font-mono truncate">{member.department}</p>
                    </div>
                  </div>

                  {/* Permissions Badges */}
                  <div className="space-y-1">
                    <span className="text-[10px] text-[#94A3B8] font-mono block">PERMISSIONS MATRIX</span>
                    <div className="flex flex-wrap gap-1">
                      {member.permissions?.map((p, idx) => (
                        <span key={idx} className="px-2 py-0.5 bg-[#101B35] border border-[#2563EB]/20 text-[#4DA3FF] text-[10px] font-mono rounded">
                          {p}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-[#101B35] flex items-center justify-between text-[10px] text-[#94A3B8] font-mono">
                    <span>Assigned: {member.assignedProjects?.length || 0} Projects</span>
                    <span className="text-emerald-400 font-semibold">{member.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Real-time Enterprise Activity Feed Stream (Right 1 col) */}
          <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl shadow-xl space-y-4 h-fit">
            <div className="flex items-center justify-between border-b border-[#101B35] pb-3">
              <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#4DA3FF]" />
                Live Workspace Activity Feed
              </h3>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-mono">
                STREAM ACTIVE
              </span>
            </div>

            <div className="space-y-3 font-sans text-xs">
              {(activities || []).map((act) => (
              <div key={act.id} className="p-3 rounded-xl bg-[#101B35]/70 border border-white/5 space-y-1">
                <div className="flex items-center gap-2">
                  <img src={act.userAvatar} alt={act.user} className="w-5 h-5 rounded-full object-cover shrink-0" />
                  <span className="font-bold text-white truncate">{act.user}</span>
                  <span className="text-[9px] text-[#94A3B8]/60 font-mono ml-auto">{act.timestamp}</span>
                </div>
                <p className="text-[#94A3B8] text-[11px] pl-7">
                  {act.action} <span className="text-[#4DA3FF] font-semibold">{act.target}</span>
                </p>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};

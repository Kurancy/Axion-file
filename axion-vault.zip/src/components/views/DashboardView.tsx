import React from 'react';
import { 
  FolderKanban, 
  CheckCircle2, 
  FileText, 
  HardDrive, 
  Sparkles, 
  Activity, 
  ArrowUpRight, 
  Clock, 
  ChevronRight,
  TrendingUp,
  ShieldCheck,
  Users,
  ShieldAlert,
  AlertTriangle
} from 'lucide-react';
import { Project, DocumentItem, ActivityLog } from '../../types';
import { ProjectHealthMonitor } from '../ProjectHealthMonitor';
import { evaluateProjectHealth } from '../../utils/projectHealth';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  BarChart, 
  Bar,
  CartesianGrid
} from 'recharts';

interface DashboardViewProps {
  projects: Project[];
  documents: DocumentItem[];
  activities: ActivityLog[];
  onSelectProject: (proj: Project) => void;
  onSelectDocument: (doc: DocumentItem) => void;
  onNavigate: (view: any) => void;
}

const analyticsData = [
  { month: 'Jan', active: 18, completed: 62, docs: 920, ai: 4200 },
  { month: 'Feb', active: 20, completed: 68, docs: 1050, ai: 5800 },
  { month: 'Mar', active: 21, completed: 74, docs: 1180, ai: 7400 },
  { month: 'Apr', active: 22, completed: 79, docs: 1290, ai: 9100 },
  { month: 'May', active: 23, completed: 83, docs: 1380, ai: 11200 },
  { month: 'Jun', active: 24, completed: 87, docs: 1482, ai: 12940 }
];

export const DashboardView: React.FC<DashboardViewProps> = ({
  projects,
  documents,
  activities,
  onSelectProject,
  onSelectDocument,
  onNavigate
}) => {

  const stats = [
    { label: "Active Projects", value: "24", icon: FolderKanban, change: "+12.5%", color: "#4DA3FF" },
    { label: "Completed Projects", value: "87", icon: CheckCircle2, change: "+8 this quarter", color: "#10B981" },
    { label: "Documents", value: "1,482", icon: FileText, change: "+140 files", color: "#3B82F6" },
    { label: "Storage Used", value: "248 GB", icon: HardDrive, change: "Of 1.0 TB allocated", color: "#8B5CF6" },
    { label: "AI Searches", value: "12,940", icon: Sparkles, change: "+34% AI engagement", color: "#EC4899" },
    { label: "System Health", value: "99.98%", icon: Activity, change: "0 incident reports", color: "#059669" }
  ];

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto font-sans" id="axion-dashboard-view">
      
      {/* Executive Welcome Hero Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-[#0A1228] via-[#101B35] to-[#0D3B8F] border border-[#2563EB]/40 shadow-2xl relative overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(77,163,255,0.15),transparent_60%)]" />
        
        <div className="relative z-10 space-y-2 max-w-xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#2563EB]/20 border border-[#4DA3FF]/40 rounded-full text-xs text-[#4DA3FF] font-mono">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>ENTERPRISE WORKSPACE • AES-256 HSM ACTIVE</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Executive Intelligence Command
          </h1>
          <p className="text-xs sm:text-sm text-[#94A3B8] leading-relaxed">
            A unified workspace where 24 active projects, 1,482 documents, and AI-powered knowledge engines operate in continuous synchronization.
          </p>
        </div>

        <div className="relative z-10 flex items-center gap-3 shrink-0">
          <button
            onClick={() => onNavigate('ai-knowledge')}
            className="px-4 py-2.5 bg-gradient-to-r from-[#2563EB] to-[#0D3B8F] hover:from-[#3b82f6] hover:to-[#1d4ed8] text-white rounded-xl text-xs font-semibold border border-[#4DA3FF]/40 shadow-lg transition-all flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-[#4DA3FF]" />
            <span>AI Knowledge Query</span>
          </button>
        </div>
      </div>

      {/* Automated Project Health Monitor System */}
      <ProjectHealthMonitor 
        projects={projects}
        onSelectProject={onSelectProject}
        onNavigate={onNavigate}
        onConsultAi={(proj) => {
          onSelectProject(proj);
          onNavigate('ai-knowledge');
        }}
      />

      {/* 6 Metric Statistics Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div
              key={i}
              className="p-4 bg-[#0A1228] border border-[#101B35] hover:border-[#2563EB]/40 rounded-2xl shadow-lg transition-all duration-300 hover:-translate-y-1 group"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs text-[#94A3B8] font-medium truncate">{stat.label}</span>
                <div className="p-2 rounded-xl bg-[#101B35] border border-white/5 text-[#4DA3FF] group-hover:scale-110 transition-transform">
                  <Icon className="w-4 h-4" />
                </div>
              </div>

              <div className="space-y-1">
                <div className="text-2xl font-black text-white tracking-tight font-sans">
                  {stat.value}
                </div>
                <div className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  <span>{stat.change}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Analytics Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Chart 1: Project Progress & Ingestion Trend */}
        <div className="lg:col-span-2 p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-[#101B35] pb-3">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#4DA3FF]" />
                Project Intelligence & AI Engagement Velocity
              </h3>
              <p className="text-[11px] text-[#94A3B8]">Document Ingestion vs. AI Query Volume (6-Month Trend)</p>
            </div>
            <span className="text-xs font-mono bg-[#101B35] text-[#4DA3FF] px-2.5 py-1 rounded-lg border border-[#2563EB]/20">
              Q2 - Q3 2026
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={analyticsData}>
                <defs>
                  <linearGradient id="aiGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4DA3FF" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#4DA3FF" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="docsGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#101B35" />
                <XAxis dataKey="month" stroke="#94A3B8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94A3B8" fontSize={11} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#050B18', borderColor: '#2563EB', borderRadius: '12px', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="ai" name="AI Searches" stroke="#4DA3FF" fillOpacity={1} fill="url(#aiGrad)" strokeWidth={2} />
                <Area type="monotone" dataKey="docs" name="Documents" stroke="#2563EB" fillOpacity={1} fill="url(#docsGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Department Activity Distribution */}
        <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl shadow-xl space-y-4">
          <div className="border-b border-[#101B35] pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-[#4DA3FF]" />
              Completed Milestones
            </h3>
            <p className="text-[11px] text-[#94A3B8]">Monthly delivery progression</p>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analyticsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#101B35" />
                <XAxis dataKey="month" stroke="#94A3B8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94A3B8" fontSize={11} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#050B18', borderColor: '#2563EB', borderRadius: '12px', fontSize: '12px' }}
                />
                <Bar dataKey="completed" name="Completed Projects" fill="#10B981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* Grid: Recent Projects & Recent Documents */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Recent Projects */}
        <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-[#101B35] pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <FolderKanban className="w-4 h-4 text-[#4DA3FF]" />
              Recent Enterprise Projects
            </h3>
            <button
              onClick={() => onNavigate('projects')}
              className="text-xs text-[#4DA3FF] hover:underline flex items-center gap-1 font-mono"
            >
              <span>View All</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {(projects || []).slice(0, 4).map((proj) => {
              const health = evaluateProjectHealth(proj);
              const isCritical = health.healthLevel === 'critical';
              const isWarning = health.healthLevel === 'warning';

              return (
                <div
                  key={proj.id}
                  onClick={() => onSelectProject(proj)}
                  className={`p-3.5 bg-[#101B35]/70 hover:bg-[#101B35] border rounded-xl cursor-pointer transition-all space-y-2 group ${
                    isCritical 
                      ? 'border-red-500/30 hover:border-red-400' 
                      : isWarning 
                        ? 'border-amber-500/30 hover:border-amber-400' 
                        : 'border-[#2563EB]/20 hover:border-[#4DA3FF]/40'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-bold text-white group-hover:text-[#4DA3FF] transition-colors truncate">
                          {proj.name}
                        </h4>
                      </div>
                      <span className="text-[11px] text-[#94A3B8] font-mono truncate block">{proj.client}</span>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {isCritical ? (
                        <span className="text-[9px] px-2 py-0.5 rounded font-mono font-bold uppercase bg-red-500/20 text-red-400 border border-red-500/30 flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-ping" />
                          Critical Risk
                        </span>
                      ) : isWarning ? (
                        <span className="text-[9px] px-2 py-0.5 rounded font-mono font-bold uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          Elevated Risk
                        </span>
                      ) : (
                        <span className="text-[9px] px-2 py-0.5 rounded font-mono font-bold uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          Healthy
                        </span>
                      )}

                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-semibold ${
                        proj.status === 'Completed' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                        proj.status === 'Review' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' :
                        'bg-[#2563EB]/20 text-[#4DA3FF] border border-[#2563EB]/30'
                      }`}>
                        {proj.status}
                      </span>
                    </div>
                  </div>

                  {/* Progress Bar & Risk Meter */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[10px] font-mono">
                      <span className="text-[#94A3B8]">Progress ({proj.progress}%)</span>
                      <span className={`font-semibold ${
                        (proj.riskScore ?? 0) >= 60 ? 'text-red-400' : (proj.riskScore ?? 0) >= 40 ? 'text-amber-400' : 'text-[#4DA3FF]'
                      }`}>
                        Risk Index: {proj.riskScore ?? 0}/100
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-[#050B18] rounded-full overflow-hidden p-0.5">
                      <div 
                        className={`h-full rounded-full ${
                          isCritical 
                            ? 'bg-gradient-to-r from-red-600 to-amber-500' 
                            : isWarning 
                              ? 'bg-gradient-to-r from-amber-600 to-amber-400' 
                              : 'bg-gradient-to-r from-[#0D3B8F] to-[#4DA3FF]'
                        }`}
                        style={{ width: `${proj.progress}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-[#94A3B8]/70 font-mono pt-1 border-t border-white/5">
                    <span>Deadline: {proj.deadline}</span>
                    <span>Manager: {proj.manager}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Documents */}
        <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-[#101B35] pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#4DA3FF]" />
              Recent Documents & Contracts
            </h3>
            <button
              onClick={() => onNavigate('documents')}
              className="text-xs text-[#4DA3FF] hover:underline flex items-center gap-1 font-mono"
            >
              <span>View All</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {(documents || []).slice(0, 4).map((doc) => (
              <div
                key={doc.id}
                onClick={() => onSelectDocument(doc)}
                className="p-3.5 bg-[#101B35]/70 hover:bg-[#101B35] border border-[#2563EB]/20 hover:border-[#4DA3FF]/40 rounded-xl cursor-pointer transition-all space-y-2 group"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="p-2 bg-[#050B18] text-[#4DA3FF] rounded-lg border border-[#2563EB]/30 shrink-0">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <h4 className="text-xs font-bold text-white group-hover:text-[#4DA3FF] transition-colors truncate">
                        {doc.name}
                      </h4>
                      <p className="text-[10px] text-[#94A3B8] font-mono truncate">
                        {doc.project} • {doc.category}
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono bg-[#2563EB]/20 text-[#4DA3FF] px-2 py-0.5 rounded border border-[#2563EB]/30 shrink-0">
                    {doc.version}
                  </span>
                </div>

                <p className="text-[11px] text-slate-300 line-clamp-1 italic">
                  "{doc.aiSummary}"
                </p>

                <div className="flex items-center justify-between text-[10px] text-[#94A3B8]/70 font-mono pt-1">
                  <span>Size: {doc.fileSize}</span>
                  <span className="text-emerald-400">AI Summary Available</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Visual Activity Timeline: Project History & System Events */}
      <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl shadow-xl space-y-4 font-sans">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#101B35] pb-3">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#4DA3FF]" />
              Project History & Live Activity Timeline
            </h3>
            <p className="text-[11px] text-[#94A3B8] font-mono">
              Aggregated real-time audit trail of document uploads, AI extractions, status updates, and vault security events
            </p>
          </div>

          <button
            onClick={() => onNavigate('team')}
            className="text-xs text-[#4DA3FF] hover:underline flex items-center gap-1 font-mono shrink-0"
          >
            <span>Full Roster Feed</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Timeline Events List */}
        <div className="relative pl-6 space-y-4 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-gradient-to-b before:from-[#2563EB] before:via-[#101B35] before:to-transparent">
          {(activities || []).map((act, idx) => {
            const getActivityBadge = (type: string) => {
              switch(type) {
                case 'upload':
                  return { icon: FileText, color: 'text-blue-400 bg-blue-500/20 border-blue-500/30', label: 'Document' };
                case 'ai':
                  return { icon: Sparkles, color: 'text-purple-400 bg-purple-500/20 border-purple-500/30', label: 'Axion AI' };
                case 'status':
                  return { icon: Clock, color: 'text-emerald-400 bg-emerald-500/20 border-emerald-500/30', label: 'Status' };
                case 'vault':
                  return { icon: ShieldCheck, color: 'text-amber-400 bg-amber-500/20 border-amber-500/30', label: 'Security' };
                default:
                  return { icon: Activity, color: 'text-[#4DA3FF] bg-[#2563EB]/20 border-[#2563EB]/30', label: 'Update' };
              }
            };

            const badge = getActivityBadge(act.type);
            const BadgeIcon = badge.icon;

            return (
              <div key={act.id || idx} className="relative flex items-start gap-4 group">
                {/* Timeline Bullet Node */}
                <div className={`absolute -left-[19px] top-1 p-1 rounded-full border bg-[#050B18] ${badge.color} group-hover:scale-125 transition-transform`}>
                  <BadgeIcon className="w-3 h-3" />
                </div>

                <div className="flex-1 bg-[#101B35]/60 hover:bg-[#101B35] border border-white/5 hover:border-[#2563EB]/30 p-3 rounded-xl transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img 
                      src={act.userAvatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150"} 
                      alt={act.user} 
                      className="w-7 h-7 rounded-full object-cover ring-1 ring-[#4DA3FF]/40 shrink-0" 
                    />
                    <div className="text-xs">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-white">{act.user}</span>
                        <span className="text-[#94A3B8]">{act.action}</span>
                        <span className="font-mono text-[#4DA3FF] font-semibold bg-[#050B18] px-2 py-0.5 rounded border border-[#2563EB]/20">
                          {act.target}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                    <span className={`text-[9px] font-mono px-2 py-0.5 rounded border uppercase font-bold ${badge.color}`}>
                      {badge.label}
                    </span>
                    <span className="text-[10px] text-[#94A3B8] font-mono">
                      {act.timestamp}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>


    </div>
  );
};

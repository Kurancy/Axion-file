import React, { useState } from 'react';
import { 
  Settings, 
  ShieldCheck, 
  Key, 
  HardDrive, 
  Server, 
  Cpu, 
  Check, 
  RotateCcw,
  RefreshCw,
  Bell,
  Lock,
  Globe
} from 'lucide-react';

interface SettingsViewProps {
  onReplayLoadingScreen: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onReplayLoadingScreen }) => {
  const [geminiStatus, setGeminiStatus] = useState("Connected (Gemini 3.6 Flash)");
  const [selectedRegion, setSelectedRegion] = useState("us-central1-a");

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto font-sans" id="axion-settings-module">
      
      {/* Header Bar */}
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
          <Settings className="w-6 h-6 text-[#4DA3FF]" />
          Axion Vault System Preferences & Security Controls
        </h1>
        <p className="text-xs text-[#94A3B8] font-mono mt-0.5">
          Enterprise node configuration, Gemini AI integration, and security controls
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Box 1: Gemini AI Integration Status */}
        <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2 font-mono">
            <Cpu className="w-4 h-4 text-[#4DA3FF]" />
            Axion AI Integration Status
          </h3>

          <div className="p-3 bg-[#050B18] rounded-xl border border-[#2563EB]/30 space-y-2 text-xs font-mono">
            <div className="flex items-center justify-between">
              <span className="text-[#94A3B8]">AI Engine SDK:</span>
              <span className="text-white">@google/genai ^2.4.0</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#94A3B8]">Active Reasoning Model:</span>
              <span className="text-[#4DA3FF] font-bold">gemini-3.6-flash</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#94A3B8]">API Key Config:</span>
              <span className="text-emerald-400 font-bold">Runtime Injected via Secrets</span>
            </div>
          </div>

          <p className="text-xs text-[#94A3B8] leading-relaxed">
            Axion AI operates server-side via Node.js Express routes. Secret keys are never exposed to the client. Configure Gemini keys in <strong className="text-white">Settings &gt; Secrets</strong> in AI Studio UI.
          </p>
        </div>

        {/* Box 2: Node & Infrastructure Config */}
        <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2 font-mono">
            <Server className="w-4 h-4 text-[#4DA3FF]" />
            Cloud Infrastructure Nodes
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-[#94A3B8] block mb-1 font-mono">Primary Node Region</label>
              <select
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value)}
                className="w-full bg-[#101B35] border border-[#2563EB]/30 rounded-xl px-3 py-2 text-white font-mono focus:outline-none"
              >
                <option value="us-central1-a">US-CENTRAL1-A (Iowa, USA)</option>
                <option value="europe-west1-b">EUROPE-WEST1-B (Belgium)</option>
                <option value="asia-southeast1-a">ASIA-SOUTHEAST1-A (Singapore)</option>
              </select>
            </div>

            <div className="p-3 bg-[#050B18] rounded-xl border border-white/5 space-y-1 font-mono text-[11px]">
              <div className="flex justify-between text-[#94A3B8]"><span>Container Runtime:</span> <span className="text-white">Cloud Run Docker</span></div>
              <div className="flex justify-between text-[#94A3B8]"><span>Express Port:</span> <span className="text-white">3000 (Ingress Proxy)</span></div>
              <div className="flex justify-between text-[#94A3B8]"><span>SSL/TLS Certificate:</span> <span className="text-emerald-400">TLS 1.3 Active</span></div>
            </div>
          </div>
        </div>

        {/* Box 3: Cinematic Loader Re-trigger */}
        <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl shadow-xl space-y-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2 font-mono">
            <RotateCcw className="w-4 h-4 text-[#4DA3FF]" />
            Cinematic Initialization Sequence
          </h3>
          <p className="text-xs text-[#94A3B8] leading-relaxed">
            Re-run the Axion Vault executive loading animation and workspace status initialization.
          </p>
          <button
            onClick={onReplayLoadingScreen}
            className="px-4 py-2 bg-[#2563EB] hover:bg-[#3b82f6] text-white rounded-xl text-xs font-semibold shadow transition-colors"
          >
            Replay Loading Screen
          </button>
        </div>

        {/* Box 4: Security Policy */}
        <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl shadow-xl space-y-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2 font-mono">
            <Lock className="w-4 h-4 text-emerald-400" />
            Zero-Trust Access Control Matrix
          </h3>
          <div className="space-y-1.5 text-xs font-mono text-[#94A3B8]">
            <p className="text-white">• MFA Requirement: Enforced Hardware Security Key (FIPS 140-3)</p>
            <p>• Data Encryption: Double-wrapped AES-256-GCM envelope</p>
            <p>• Session Timeout: 15 minutes inactive auto-lock</p>
          </div>
        </div>

      </div>

    </div>
  );
};

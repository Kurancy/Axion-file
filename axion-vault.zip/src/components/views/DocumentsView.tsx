import React, { useState } from 'react';
import { 
  FileText, 
  Upload, 
  Search, 
  Filter, 
  Folder, 
  Sparkles, 
  Download, 
  Share2, 
  Copy, 
  Clock, 
  Eye, 
  Languages, 
  Scan, 
  Check, 
  X, 
  ShieldCheck, 
  Tag, 
  Code, 
  Database,
  Layers,
  FileCode,
  FileCheck,
  MessageSquare,
  Bot
} from 'lucide-react';
import { DocumentItem, DocumentCategory } from '../../types';

interface DocumentsViewProps {
  documents: DocumentItem[];
  selectedDocument: DocumentItem | null;
  onSelectDocument: (doc: DocumentItem | null) => void;
  onOpenUploadDocModal: () => void;
  onChatWithDocument?: (doc: DocumentItem) => void;
}

const categoriesList: DocumentCategory[] = [
  'Contracts',
  'Proposals',
  'Invoices',
  'Requirements',
  'Database',
  'API',
  'Design',
  'UI/UX',
  'Testing',
  'Deployment',
  'Reports',
  'Legal',
  'Presentations',
  'Images',
  'Videos',
  'Source Code'
];

export const DocumentsView: React.FC<DocumentsViewProps> = ({
  documents,
  selectedDocument,
  onSelectDocument,
  onOpenUploadDocModal,
  onChatWithDocument
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);
  const [translatedText, setTranslatedText] = useState<string | null>(null);
  const [ocrText, setOcrText] = useState<string | null>(null);

  const filteredDocs = (documents || []).filter(d => {
    const matchesCategory = selectedCategory === 'All' || d.category === selectedCategory;
    const matchesSearch = (d.name || '').toLowerCase().includes(searchQuery.toLowerCase()) || (d.project || '').toLowerCase().includes(searchQuery.toLowerCase()) || (d.aiSummary || '').toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleTranslate = () => {
    setTranslatedText("Translated (Spanish): Documento oficial que describe el acuerdo de servicios administrados con un nivel de disponibilidad garantizado del 99,99%.");
  };

  const handleOcr = () => {
    setOcrText("OCR Extracted Text: [PAGE 1/14] Master Services Agreement - Signed & Verified by Enterprise Security Engine.");
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto font-sans" id="axion-documents-module">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <FileText className="w-6 h-6 text-[#4DA3FF]" />
            Enterprise Document Intelligence Vault
          </h1>
          <p className="text-xs text-[#94A3B8] font-mono mt-0.5">
            Indexed {documents?.length || 0} contracts, codebases, and architecture blueprints
          </p>
        </div>

        <button
          onClick={onOpenUploadDocModal}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#2563EB] to-[#0D3B8F] hover:from-[#3b82f6] text-white rounded-xl text-xs font-semibold border border-[#4DA3FF]/40 shadow-lg transition-all"
        >
          <Upload className="w-4 h-4 text-[#4DA3FF]" />
          <span>Upload Enterprise Document</span>
        </button>
      </div>

      {/* Main Layout: Folder Navigation Sidebar (Left) + Document Grid (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Category Folders Navigation */}
        <div className="p-4 bg-[#0A1228] border border-[#101B35] rounded-2xl space-y-3 h-fit">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider px-2">
            Folder Categories
          </h3>

          <div className="space-y-1">
            <button
              onClick={() => setSelectedCategory('All')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-colors ${
                selectedCategory === 'All'
                  ? 'bg-[#2563EB] text-white'
                  : 'text-[#94A3B8] hover:text-white hover:bg-[#101B35]'
              }`}
            >
              <span className="flex items-center gap-2">
                <Folder className="w-4 h-4 text-[#4DA3FF]" />
                All Folders
              </span>
              <span className="font-mono text-[10px]">{documents?.length || 0}</span>
            </button>

            {categoriesList.map((cat) => {
              const count = (documents || []).filter(d => d.category === cat).length;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`w-full flex items-center justify-between px-3 py-1.5 rounded-xl text-xs font-medium transition-colors ${
                    selectedCategory === cat
                      ? 'bg-[#2563EB] text-white'
                      : 'text-[#94A3B8] hover:text-white hover:bg-[#101B35]'
                  }`}
                >
                  <span className="flex items-center gap-2 truncate">
                    <Folder className="w-3.5 h-3.5 text-[#4DA3FF]/70" />
                    {cat}
                  </span>
                  <span className="font-mono text-[10px] bg-[#101B35] px-1.5 py-0.2 rounded text-[#94A3B8]">
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Side Documents Container */}
        <div className="lg:col-span-3 space-y-4">
          
          {/* Search Filter Bar */}
          <div className="p-3 bg-[#0A1228] border border-[#101B35] rounded-2xl flex items-center gap-3">
            <Search className="w-4 h-4 text-[#4DA3FF]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={`Search in ${selectedCategory === 'All' ? 'all documents' : selectedCategory}...`}
              className="w-full bg-transparent text-xs text-white placeholder-[#94A3B8] focus:outline-none"
            />
          </div>

          {/* Document Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredDocs.map((doc) => (
              <div
                key={doc.id}
                onClick={() => onSelectDocument(doc)}
                className="p-4 bg-[#0A1228] border border-[#101B35] hover:border-[#2563EB]/50 rounded-2xl shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer flex flex-col justify-between space-y-3 group"
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="p-2.5 bg-[#050B18] text-[#4DA3FF] rounded-xl border border-[#2563EB]/30 shrink-0">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="text-xs font-bold text-white group-hover:text-[#4DA3FF] transition-colors truncate">
                          {doc.name}
                        </h3>
                        <p className="text-[10px] text-[#94A3B8] font-mono truncate">
                          {doc.project} • {doc.category}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (onChatWithDocument) {
                            onChatWithDocument(doc);
                          }
                        }}
                        className="px-2 py-0.5 bg-[#2563EB]/20 hover:bg-[#2563EB] text-[#4DA3FF] hover:text-white rounded text-[10px] font-mono border border-[#2563EB]/30 transition-all flex items-center gap-1 shadow-sm"
                        title="Chat with Document AI"
                      >
                        <Sparkles className="w-3 h-3 text-[#4DA3FF]" />
                        <span className="hidden sm:inline">Chat</span>
                      </button>
                      <span className="text-[10px] font-mono bg-[#2563EB]/20 text-[#4DA3FF] px-2 py-0.5 rounded border border-[#2563EB]/30">
                        {doc.version}
                      </span>
                    </div>
                  </div>

                  <div className="p-2.5 bg-[#101B35]/70 rounded-xl border border-white/5 space-y-1">
                    <span className="text-[10px] text-[#4DA3FF] font-mono font-semibold flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      AI Executive Summary
                    </span>
                    <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                      {doc.aiSummary}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] text-[#94A3B8] font-mono pt-2 border-t border-[#101B35]">
                  <span>Size: {doc.fileSize}</span>
                  <span>Modified: {doc.lastModified}</span>
                  <span className="text-emerald-400">{doc.securityLevel}</span>
                </div>
              </div>
            ))}
          </div>

        </div>

      </div>

      {/* Comprehensive Document Viewer Modal */}
      {selectedDocument && (
        <div className="fixed inset-0 z-50 bg-[#050B18]/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-8 font-sans" id="axion-document-viewer-modal">
          <div className="bg-[#0A1228] border border-[#2563EB]/40 rounded-2xl w-full max-w-5xl h-[85vh] shadow-2xl overflow-hidden flex flex-col">
            
            {/* Modal Header */}
            <div className="p-4 bg-[#050B18] border-b border-[#101B35] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#101B35] text-[#4DA3FF] rounded-lg border border-[#2563EB]/30">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-white truncate max-w-md">{selectedDocument.name}</h2>
                  <p className="text-[11px] text-[#94A3B8] font-mono">
                    Project: {selectedDocument.project} • Version {selectedDocument.version}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    if (onChatWithDocument && selectedDocument) {
                      onChatWithDocument(selectedDocument);
                    }
                  }}
                  className="px-3 py-1.5 bg-gradient-to-r from-[#2563EB] to-[#0D3B8F] hover:from-[#3b82f6] text-white rounded-lg text-xs font-semibold border border-[#4DA3FF]/40 flex items-center gap-1.5 transition-all shadow-md"
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#4DA3FF]" />
                  <span>Chat with Doc</span>
                </button>

                <button
                  onClick={handleCopyLink}
                  className="px-3 py-1.5 bg-[#101B35] hover:bg-[#101B35]/80 text-[#94A3B8] hover:text-white rounded-lg text-xs font-mono border border-white/10 flex items-center gap-1.5"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-[#4DA3FF]" />}
                  <span>{copiedLink ? 'Copied' : 'Copy Link'}</span>
                </button>

                <button
                  onClick={() => onSelectDocument(null)}
                  className="p-1.5 text-[#94A3B8] hover:text-white rounded-lg hover:bg-[#101B35]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body Grid: Left Preview + Right AI Analysis */}
            <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 overflow-hidden">
              
              {/* Left Column: Document Preview & Extracted Snippet */}
              <div className="p-6 bg-[#050B18]/60 border-r border-[#101B35] overflow-y-auto space-y-4 custom-scrollbar">
                <div className="flex items-center justify-between text-xs text-[#94A3B8] font-mono border-b border-[#101B35] pb-2">
                  <span>DOCUMENT CONTENT PREVIEW</span>
                  <span className="text-[#4DA3FF]">AES-256 HSM VERIFIED</span>
                </div>

                <div className="p-4 bg-[#101B35]/90 rounded-xl border border-[#2563EB]/20 text-xs text-slate-200 font-mono whitespace-pre-wrap leading-relaxed">
                  {selectedDocument.contentSnippet || "Full document contents locked in secure HSM vault. Text snippet preview loaded."}
                </div>

                {/* Translation or OCR Output if triggered */}
                {translatedText && (
                  <div className="p-3 bg-[#101B35] border border-blue-500/30 rounded-xl text-xs text-blue-200 font-sans">
                    {translatedText}
                  </div>
                )}

                {ocrText && (
                  <div className="p-3 bg-[#101B35] border border-emerald-500/30 rounded-xl text-xs text-emerald-200 font-mono">
                    {ocrText}
                  </div>
                )}
              </div>

              {/* Right Column: AI Summary & Entity Insights */}
              <div className="p-6 bg-[#0A1228] overflow-y-auto space-y-5 custom-scrollbar font-sans">
                
                {/* AI Executive Summary Block */}
                <div className="p-4 bg-[#101B35] rounded-xl border border-[#2563EB]/30 space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-[#4DA3FF] font-mono">
                    <span className="flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 animate-pulse" />
                      AXION AI EXECUTIVE SUMMARY
                    </span>
                    <span className="bg-[#2563EB]/30 px-2 py-0.5 rounded text-[10px] text-white">GEMINI 3.6</span>
                  </div>
                  <p className="text-xs text-slate-200 leading-relaxed">
                    {selectedDocument.aiSummary}
                  </p>
                </div>

                {/* Extracted Key Entities */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-white font-mono uppercase">Extracted Key Entities</span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedDocument.extractedEntities?.map((ent, i) => (
                      <span key={i} className="px-2.5 py-1 bg-[#101B35] border border-[#2563EB]/30 text-[#4DA3FF] text-xs font-mono rounded-lg">
                        {ent}
                      </span>
                    )) || <span className="text-xs text-[#94A3B8]">No entities extracted.</span>}
                  </div>
                </div>

                {/* Document Metadata Details */}
                <div className="p-4 bg-[#101B35]/60 rounded-xl border border-white/5 text-xs space-y-2 font-mono">
                  <div className="flex justify-between text-[#94A3B8]"><span>Category:</span> <span className="text-white">{selectedDocument.category}</span></div>
                  <div className="flex justify-between text-[#94A3B8]"><span>File Size:</span> <span className="text-white">{selectedDocument.fileSize}</span></div>
                  <div className="flex justify-between text-[#94A3B8]"><span>Uploader:</span> <span className="text-white">{selectedDocument.uploader}</span></div>
                  <div className="flex justify-between text-[#94A3B8]"><span>Last Modified:</span> <span className="text-white">{selectedDocument.lastModified}</span></div>
                  <div className="flex justify-between text-[#94A3B8]"><span>Security Rating:</span> <span className="text-emerald-400">{selectedDocument.securityLevel}</span></div>
                </div>

                {/* Interactive Action Buttons */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-2">
                  <button 
                    onClick={() => {
                      if (onChatWithDocument && selectedDocument) {
                        onChatWithDocument(selectedDocument);
                      }
                    }}
                    className="p-2.5 bg-gradient-to-r from-[#2563EB] to-[#0D3B8F] hover:from-[#3b82f6] hover:to-[#1d4ed8] text-white rounded-xl text-xs font-semibold shadow-lg transition-all flex items-center justify-center gap-2 border border-[#4DA3FF]/40 col-span-2 sm:col-span-3 group"
                  >
                    <Sparkles className="w-4 h-4 text-[#4DA3FF] group-hover:rotate-12 transition-transform" />
                    <span>Chat with Document (Pass Content & Summary to Axion AI)</span>
                  </button>

                  <button 
                    onClick={handleTranslate}
                    className="p-2.5 bg-[#101B35] hover:bg-[#2563EB]/20 border border-[#2563EB]/30 rounded-xl text-xs text-[#4DA3FF] font-medium transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Languages className="w-3.5 h-3.5" />
                    <span>Translate</span>
                  </button>

                  <button 
                    onClick={handleOcr}
                    className="p-2.5 bg-[#101B35] hover:bg-[#2563EB]/20 border border-[#2563EB]/30 rounded-xl text-xs text-[#4DA3FF] font-medium transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Scan className="w-3.5 h-3.5" />
                    <span>Run OCR</span>
                  </button>

                  <button 
                    className="p-2.5 bg-[#101B35] hover:bg-[#101B35]/80 text-[#94A3B8] hover:text-white border border-white/10 rounded-xl text-xs font-medium transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                </div>

              </div>

            </div>

          </div>
        </div>
      )}

    </div>
  );
};

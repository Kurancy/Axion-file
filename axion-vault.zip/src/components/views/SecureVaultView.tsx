import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Key, 
  FileCheck, 
  Eye, 
  AlertTriangle, 
  Clock, 
  UserCheck, 
  CheckCircle2, 
  ShieldAlert,
  HardDrive
} from 'lucide-react';
import { VaultRecord } from '../../types';

interface SecureVaultViewProps {
  vaultRecords: VaultRecord[];
}

export const SecureVaultView: React.FC<SecureVaultViewProps> = ({ vaultRecords }) => {
  const [unlockedRecordId, setUnlockedRecordId] = useState<string | null>(null);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto font-sans" id="axion-secure-vault-module">
      
      {/* Vault Shield Banner */}
      <div className="p-8 rounded-2xl bg-gradient-to-r from-[#050B18] via-[#0A1228] to-[#0D3B8F] border border-[#2563EB]/50 shadow-2xl space-y-4 relative overflow-hidden">
        <div className="absolute right-6 top-6 opacity-10 text-[#4DA3FF]">
          <ShieldCheck className="w-40 h-40" />
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-emerald-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>AES-256-GCM DOUBLE-ENVELOPED ENCRYPTION • FIPS 140-3 LEVEL 4 HSM</span>
        </div>

        <h1 className="text-3xl font-black text-white tracking-tight flex items-center gap-3">
          <Lock className="w-8 h-8 text-[#4DA3FF]" />
          Axion Secure Encrypted Vault
        </h1>

        <p className="text-xs sm:text-sm text-[#94A3B8] max-w-2xl leading-relaxed">
          Isolated hardware security module (HSM) store for classified defense contracts, high-value legal agreements, executive financial ledgers, and zero-trust identity certificates.
        </p>

        <div className="flex flex-wrap items-center gap-4 pt-2 font-mono text-xs">
          <div className="px-3 py-1.5 bg-[#101B35] rounded-xl border border-[#2563EB]/30 text-[#4DA3FF]">
            STATUS: ENCRYPTED AT REST
          </div>
          <div className="px-3 py-1.5 bg-[#101B35] rounded-xl border border-emerald-500/30 text-emerald-400">
            MFA: VERIFIED HARDWARE KEY
          </div>
          <div className="px-3 py-1.5 bg-[#101B35] rounded-xl border border-purple-500/30 text-purple-300">
            AUDIT LOGS: ACTIVE
          </div>
        </div>
      </div>

      {/* Vault Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {vaultRecords.map((rec) => (
          <div
            key={rec.id}
            className="p-5 bg-[#0A1228] border border-[#2563EB]/30 rounded-2xl shadow-2xl space-y-4 hover:border-[#4DA3FF]/60 transition-all duration-300"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="p-2.5 bg-[#050B18] text-[#4DA3FF] rounded-xl border border-[#2563EB]/40">
                <Lock className="w-5 h-5 text-emerald-400" />
              </div>

              <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-400 px-2.5 py-0.5 rounded-full border border-emerald-500/30 font-semibold">
                {rec.securityRating}
              </span>
            </div>

            <div>
              <span className="text-[10px] font-mono text-[#4DA3FF] uppercase block mb-0.5">{rec.category}</span>
              <h3 className="text-xs font-bold text-white truncate font-mono">{rec.title}</h3>
              <p className="text-[10px] text-[#94A3B8] font-mono mt-1">Size: {rec.fileSize} • Owner: {rec.owner}</p>
            </div>

            <div className="p-3 bg-[#050B18] rounded-xl border border-white/5 space-y-1 text-[11px]">
              <span className="text-[#4DA3FF] font-mono font-bold block">Encryption Algorithm</span>
              <p className="text-slate-300 font-mono text-[10px]">{rec.encryptionAlgorithm}</p>
            </div>

            <div className="p-3 bg-[#101B35]/70 rounded-xl border border-white/5 space-y-1 text-xs font-sans">
              <span className="text-emerald-400 font-mono font-bold text-[10px] block">AI Compliance Check</span>
              <p className="text-slate-300 text-[11px] leading-relaxed">{rec.aiRiskAnalysis}</p>
            </div>

            <div className="pt-2 border-t border-[#101B35] flex items-center justify-between text-[10px] text-[#94A3B8] font-mono">
              <span>Access Count: {rec.accessCount}</span>
              <button
                onClick={() => setUnlockedRecordId(unlockedRecordId === rec.id ? null : rec.id)}
                className="px-3 py-1 bg-[#2563EB]/20 hover:bg-[#2563EB] text-[#4DA3FF] hover:text-white rounded-lg border border-[#2563EB]/30 transition-colors"
              >
                {unlockedRecordId === rec.id ? 'Lock Vault' : 'Authenticate & Unlock'}
              </button>
            </div>

            {/* Unlocked Secrets Details if authenticated */}
            {unlockedRecordId === rec.id && (
              <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl text-xs space-y-2 animate-in fade-in">
                <div className="flex items-center justify-between font-mono text-emerald-400 text-[10px] font-bold">
                  <span>UNLOCKED SECURE DECRYPTED PIPELINE</span>
                  <span>SESSION TOKEN VALID</span>
                </div>
                <p className="text-emerald-200 text-[11px] font-mono">
                  Payload Key Hash: SHA256-e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
                </p>
                <div className="flex gap-2">
                  <button className="px-2.5 py-1 bg-emerald-500 text-black font-bold text-[10px] font-mono rounded">
                    Download Decrypted Blob
                  </button>
                </div>
              </div>
            )}

          </div>
        ))}
      </div>

      {/* Access Audit Trail Log */}
      <div className="p-5 bg-[#0A1228] border border-[#101B35] rounded-2xl space-y-3 font-mono text-xs">
        <h3 className="font-bold text-white flex items-center gap-2">
          <Clock className="w-4 h-4 text-[#4DA3FF]" />
          HSM Vault Access Audit Trail (Zero-Trust Log)
        </h3>
        <div className="space-y-2 text-[#94A3B8]">
          <div className="p-2.5 rounded-xl bg-[#050B18] border border-white/5 flex items-center justify-between">
            <span>[2026-07-29 01:10:00 UTC] Sophia Sterling authenticated via YubiKey FIPS for Ministry_Defense_Contract.enc</span>
            <span className="text-emerald-400">SUCCESS</span>
          </div>
          <div className="p-2.5 rounded-xl bg-[#050B18] border border-white/5 flex items-center justify-between">
            <span>[2026-07-28 18:04:12 UTC] Marcus Chen accessed Axion_Q2_Financial_Audit_Master_Ledger.enc</span>
            <span className="text-emerald-400">SUCCESS</span>
          </div>
        </div>
      </div>

    </div>
  );
};

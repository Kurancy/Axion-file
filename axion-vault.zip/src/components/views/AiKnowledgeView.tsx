import React, { useState } from 'react';
import { 
  BrainCircuit, 
  Search, 
  Sparkles, 
  ArrowRight, 
  FileText, 
  FolderKanban, 
  ShieldCheck, 
  CheckCircle2, 
  Database,
  ExternalLink
} from 'lucide-react';
import { Project, DocumentItem } from '../../types';

interface AiKnowledgeViewProps {
  projects: Project[];
  documents: DocumentItem[];
  onSelectProject: (proj: Project) => void;
  onSelectDocument: (doc: DocumentItem) => void;
}

const exampleQueries = [
  "Show the signed contract for Sunshine ERP",
  "Find all SAP Business One documents",
  "Summarize the warehouse project",
  "Show deployment architecture",
  "Find API authentication requirements"
];

export const AiKnowledgeView: React.FC<AiKnowledgeViewProps> = ({
  projects,
  documents,
  onSelectProject,
  onSelectDocument
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [synthesisResult, setSynthesisResult] = useState<string | null>(null);

  const handleSearch = async (promptToUse?: string) => {
    const q = promptToUse || searchQuery;
    if (!q.trim()) return;

    if (promptToUse) setSearchQuery(promptToUse);
    setIsSynthesizing(true);
    setSynthesisResult(null);

    try {
      const res = await fetch('/api/ai/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q })
      });
      const data = await res.json();
      setSynthesisResult(data.synthesis || "AI Knowledge synthesis complete.");
    } catch (err) {
      console.error(err);
      setSynthesisResult("Axion AI Knowledge Engine response ready. Check grounding matches below.");
    } finally {
      setIsSynthesizing(false);
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto font-sans" id="axion-ai-knowledge-module">
      
      {/* Hero Banner */}
      <div className="p-8 rounded-2xl bg-gradient-to-r from-[#0A1228] via-[#101B35] to-[#0D3B8F] border border-[#2563EB]/40 shadow-2xl space-y-4">
        <div className="flex items-center gap-2 text-xs font-mono text-[#4DA3FF]">
          <BrainCircuit className="w-4 h-4 animate-pulse" />
          <span>AXION AI KNOWLEDGE RETRIEVAL ENGINE • GEMINI 3.6 FLASH GROUNDED</span>
        </div>
        <h1 className="text-3xl font-black text-white tracking-tight">
          Enterprise Knowledge Intelligence
        </h1>
        <p className="text-xs sm:text-sm text-[#94A3B8] max-w-2xl leading-relaxed">
          Ask complex questions across contracts, architecture specifications, SAP database schemas, robotics telemetry models, and financial ledgers.
        </p>

        {/* Big AI Search Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSearch();
          }}
          className="flex items-center gap-3 bg-[#050B18] p-2.5 rounded-2xl border border-[#2563EB]/40 shadow-xl max-w-3xl"
        >
          <Search className="w-5 h-5 text-[#4DA3FF] ml-2 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search across all projects, documents, and knowledge..."
            className="flex-1 bg-transparent text-sm text-white placeholder-[#94A3B8] focus:outline-none font-sans"
            id="ai-knowledge-search-input"
          />
          <button
            type="submit"
            disabled={isSynthesizing || !searchQuery.trim()}
            className="px-5 py-2.5 bg-gradient-to-r from-[#2563EB] to-[#0D3B8F] hover:from-[#3b82f6] text-white font-semibold text-xs rounded-xl border border-[#4DA3FF]/40 shadow transition-all shrink-0 flex items-center gap-2 disabled:opacity-40"
            id="ai-knowledge-search-btn"
          >
            <Sparkles className="w-4 h-4 text-[#4DA3FF]" />
            <span>{isSynthesizing ? 'Querying Engine...' : 'Search'}</span>
          </button>
        </form>
      </div>

      {/* Recommended Queries Grid */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-[#94A3B8] font-mono tracking-wider uppercase">
          Enterprise Example Queries
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {exampleQueries.map((prompt, i) => (
            <button
              key={i}
              onClick={() => handleSearch(prompt)}
              className="p-3.5 bg-[#0A1228] hover:bg-[#101B35] border border-[#101B35] hover:border-[#2563EB]/40 rounded-2xl text-left text-xs text-[#94A3B8] hover:text-white transition-all flex items-center justify-between group shadow-lg"
            >
              <span className="font-medium pr-2 truncate">{prompt}</span>
              <ArrowRight className="w-4 h-4 text-[#4DA3FF] opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
            </button>
          ))}
        </div>
      </div>

      {/* AI Synthesis Box */}
      {isSynthesizing && (
        <div className="p-6 rounded-2xl bg-[#0A1228] border border-[#2563EB]/40 shadow-2xl flex items-center gap-4 text-xs text-[#4DA3FF] animate-pulse font-mono">
          <Sparkles className="w-6 h-6 text-[#4DA3FF] animate-spin shrink-0" />
          <span>Axion AI Knowledge Engine synthesizing cross-document references and project metadata...</span>
        </div>
      )}

      {synthesisResult && !isSynthesizing && (
        <div className="p-6 rounded-2xl bg-[#0A1228] border border-[#2563EB]/40 shadow-2xl space-y-4">
          <div className="flex items-center justify-between border-b border-[#101B35] pb-3 text-xs font-mono">
            <span className="text-[#4DA3FF] font-bold flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              AXION AI GROUNDED KNOWLEDGE SYNTHESIS
            </span>
            <span className="bg-emerald-500/20 text-emerald-400 px-2.5 py-0.5 rounded border border-emerald-500/30">
              CONFIDENCE SCORE: 98.4%
            </span>
          </div>

          <div className="prose prose-invert max-w-none text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-wrap">
            {synthesisResult}
          </div>
        </div>
      )}

      {/* Relevant Grounding Matches */}
      <div className="space-y-4">
        <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider">
          Indexed Workspace Knowledge Artifacts
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {documents.map((doc) => (
            <div
              key={doc.id}
              onClick={() => onSelectDocument(doc)}
              className="p-4 bg-[#0A1228] border border-[#101B35] hover:border-[#2563EB]/50 rounded-2xl shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer space-y-3 group"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono bg-[#2563EB]/20 text-[#4DA3FF] px-2 py-0.5 rounded border border-[#2563EB]/30">
                  {doc.category}
                </span>
                <span className="text-[10px] text-emerald-400 font-mono font-semibold">Grounded</span>
              </div>

              <div>
                <h4 className="text-xs font-bold text-white group-hover:text-[#4DA3FF] transition-colors truncate">
                  {doc.name}
                </h4>
                <p className="text-[10px] text-[#94A3B8] font-mono mt-0.5">Project: {doc.project}</p>
              </div>

              <p className="text-xs text-slate-300 line-clamp-2 italic leading-relaxed">
                "{doc.aiSummary}"
              </p>

              <div className="flex items-center justify-between text-[10px] text-[#94A3B8] font-mono pt-2 border-t border-[#101B35]">
                <span>Version {doc.version}</span>
                <span className="text-[#4DA3FF] flex items-center gap-1">
                  Inspect
                  <ExternalLink className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};

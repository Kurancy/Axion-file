import React from 'react';
import { Keyboard, X, Command, Search, Sparkles, Navigation, Layers, ShieldCheck } from 'lucide-react';

interface KeyboardShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ShortcutItem {
  keys: string[];
  description: string;
}

interface ShortcutGroup {
  category: string;
  icon: React.ComponentType<{ className?: string }>;
  items: ShortcutItem[];
}

const shortcutGroups: ShortcutGroup[] = [
  {
    category: 'Global & Search',
    icon: Command,
    items: [
      { keys: ['Ctrl', 'K'], description: 'Open Global Intelligence Search' },
      { keys: ['Ctrl', '/'], description: 'Toggle Axion AI Assistant Drawer' },
      { keys: ['?'], description: 'Toggle Keyboard Shortcuts Cheat Sheet' },
      { keys: ['Esc'], description: 'Close active modal or sliding panel' }
    ]
  },
  {
    category: 'Quick View Navigation',
    icon: Navigation,
    items: [
      { keys: ['Alt', '1'], description: 'Executive Command Dashboard' },
      { keys: ['Alt', '2'], description: 'Enterprise Projects Portfolio' },
      { keys: ['Alt', '3'], description: 'Document Intelligence Vault' },
      { keys: ['Alt', '4'], description: 'Execution Task Kanban Board' },
      { keys: ['Alt', '5'], description: 'AI Knowledge Query Engine' },
      { keys: ['Alt', '6'], description: 'AES-256 Secure Vault' },
      { keys: ['Alt', '7'], description: 'Team Roster & Access Control' }
    ]
  },
  {
    category: 'Board & Workspace Interactions',
    icon: Layers,
    items: [
      { keys: ['Drag', 'Drop'], description: 'Move tasks between Status / Priority columns' },
      { keys: ['Click', 'Card'], description: 'Inspect project or document details' },
      { keys: ['Shift', 'Click'], description: 'Quick-ask Axion AI about context item' }
    ]
  }
];

export const KeyboardShortcutsModal: React.FC<KeyboardShortcutsModalProps> = ({
  isOpen,
  onClose
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#050B18]/85 backdrop-blur-md flex items-center justify-center p-4 font-sans animate-fade-in">
      <div 
        className="bg-[#0A1228] border border-[#2563EB]/40 rounded-2xl w-full max-w-2xl p-6 shadow-2xl space-y-6 relative overflow-hidden"
        id="axion-keyboard-shortcuts-modal"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-[#2563EB]/10 to-transparent pointer-events-none rounded-bl-full" />

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-[#101B35] pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-[#101B35] text-[#4DA3FF] rounded-xl border border-[#2563EB]/30">
              <Keyboard className="w-5 h-5 text-[#4DA3FF]" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                System Keyboard Shortcuts
              </h3>
              <p className="text-xs text-[#94A3B8] font-mono">
                Speed up your enterprise workspace navigation & search
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-[#94A3B8] hover:text-white bg-[#101B35] hover:bg-[#101B35]/80 rounded-xl transition-colors border border-white/5"
            aria-label="Close shortcuts modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Shortcut Groups Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {shortcutGroups.map((group, idx) => {
            const GroupIcon = group.icon;
            return (
              <div 
                key={idx} 
                className={`p-4 bg-[#101B35]/50 border border-[#2563EB]/20 rounded-xl space-y-3 ${
                  idx === 2 ? 'md:col-span-2' : ''
                }`}
              >
                <div className="flex items-center gap-2 text-xs font-bold text-white font-mono uppercase tracking-wider border-b border-[#2563EB]/20 pb-2">
                  <GroupIcon className="w-4 h-4 text-[#4DA3FF]" />
                  <span>{group.category}</span>
                </div>

                <div className="space-y-2.5">
                  {group.items.map((item, itemIdx) => (
                    <div key={itemIdx} className="flex items-center justify-between text-xs">
                      <span className="text-[#94A3B8] font-sans">{item.description}</span>
                      <div className="flex items-center gap-1 shrink-0 ml-2">
                        {item.keys.map((k, kIdx) => (
                          <kbd
                            key={kIdx}
                            className="px-2 py-1 bg-[#050B18] border border-[#2563EB]/40 text-[#4DA3FF] font-mono text-[10px] font-bold rounded-md shadow-inner min-w-[22px] text-center"
                          >
                            {k}
                          </kbd>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Footer Tip */}
        <div className="pt-3 border-t border-[#101B35] flex items-center justify-between text-[11px] font-mono text-[#94A3B8]">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Shortcuts active across all Axion Workspace views</span>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#2563EB] hover:bg-[#3b82f6] text-white text-xs font-semibold rounded-lg transition-colors"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};

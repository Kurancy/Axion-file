import React, { useState } from 'react';
import { X, Upload, FileText, Sparkles } from 'lucide-react';
import { DocumentItem, DocumentCategory, Project } from '../../types';

interface UploadDocModalProps {
  isOpen: boolean;
  onClose: () => void;
  projects: Project[];
  onUploadDoc: (doc: Partial<DocumentItem>) => void;
}

const categoriesList: DocumentCategory[] = [
  'Contracts',
  'Proposals',
  'Invoices',
  'Requirements',
  'Database',
  'API',
  'Design',
  'UI/UX',
  'Testing',
  'Deployment',
  'Reports',
  'Legal',
  'Presentations',
  'Images',
  'Videos',
  'Source Code'
];

export const UploadDocModal: React.FC<UploadDocModalProps> = ({
  isOpen,
  onClose,
  projects,
  onUploadDoc
}) => {
  const [docName, setDocName] = useState('');
  const [category, setCategory] = useState<DocumentCategory>('Requirements');
  const [selectedProjectId, setSelectedProjectId] = useState(projects[0]?.id || 'proj-1');
  const [isUploading, setIsUploading] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!docName.trim()) return;

    setIsUploading(true);

    const proj = projects.find(p => p.id === selectedProjectId) || projects[0];

    try {
      // Call AI summarizer backend
      const sumRes = await fetch('/api/ai/summarize-doc', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          docName: docName,
          category: category,
          contentSnippet: `Document uploaded to project ${proj.name}.`
        })
      });

      const sumData = await sumRes.json();

      onUploadDoc({
        name: docName,
        category: category,
        project: proj.name,
        projectId: proj.id,
        fileSize: '3.6 MB',
        version: 'v1.0',
        uploader: 'Adam Vance',
        aiSummary: sumData.summary || "Document indexed into Axion Vault Knowledge Engine.",
        extractedEntities: sumData.entities || ["Axion Vault", "Ingested Document"],
        contentSnippet: `Master enterprise document artifact [${docName}] assigned to project ${proj.name}.`
      });

      setDocName('');
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#050B18]/80 backdrop-blur-md flex items-center justify-center p-4 font-sans" id="axion-upload-doc-modal">
      <div className="bg-[#0A1228] border border-[#2563EB]/40 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-[#101B35] pb-3">
          <div className="flex items-center gap-2 text-white font-bold text-sm">
            <Upload className="w-5 h-5 text-[#4DA3FF]" />
            <span>Upload Enterprise Document</span>
          </div>
          <button onClick={onClose} className="text-[#94A3B8] hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          
          {/* Drag and Drop Zone */}
          <div
            onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
            onDragLeave={() => setIsDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragOver(false);
              if (e.dataTransfer.files?.[0]) {
                setDocName(e.dataTransfer.files[0].name);
              }
            }}
            className={`p-6 rounded-2xl border-2 border-dashed text-center transition-all cursor-pointer ${
              isDragOver ? 'border-[#4DA3FF] bg-[#2563EB]/20' : 'border-[#2563EB]/30 bg-[#050B18]/60 hover:border-[#4DA3FF]/50'
            }`}
          >
            <Upload className="w-8 h-8 text-[#4DA3FF] mx-auto mb-2 animate-bounce" />
            <p className="text-white font-bold mb-1">Drag & Drop Enterprise File</p>
            <p className="text-[10px] text-[#94A3B8] font-mono">Supports PDF, DOCX, SQL, PNG, ZIP (Max 100MB)</p>
          </div>

          <div>
            <label className="text-[#94A3B8] block mb-1">Document Name</label>
            <input
              type="text"
              value={docName}
              onChange={(e) => setDocName(e.target.value)}
              placeholder="e.g. Master_SLA_Agreement_v1.pdf"
              className="w-full bg-[#101B35] border border-[#2563EB]/30 rounded-xl px-3 py-2 text-white focus:outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[#94A3B8] block mb-1">Assigned Project</label>
              <select
                value={selectedProjectId}
                onChange={(e) => setSelectedProjectId(e.target.value)}
                className="w-full bg-[#101B35] border border-[#2563EB]/30 rounded-xl px-3 py-2 text-white focus:outline-none"
              >
                {projects.map(p => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[#94A3B8] block mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as DocumentCategory)}
                className="w-full bg-[#101B35] border border-[#2563EB]/30 rounded-xl px-3 py-2 text-white focus:outline-none"
              >
                {categoriesList.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-[#101B35]/80 border border-[#2563EB]/20 flex items-center gap-2 text-[11px] text-[#4DA3FF] font-mono">
            <Sparkles className="w-4 h-4 shrink-0" />
            <span>Axion AI will automatically extract entities & generate executive summary on upload.</span>
          </div>

          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 bg-[#101B35] text-[#94A3B8] hover:text-white rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isUploading}
              className="flex-1 py-2 bg-[#2563EB] hover:bg-[#3b82f6] text-white rounded-xl font-semibold shadow-md flex items-center justify-center gap-2"
            >
              <Upload className="w-4 h-4" />
              <span>{isUploading ? 'Ingesting...' : 'Upload & Process'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { X, FolderPlus, Plus } from 'lucide-react';
import { Project, ProjectPriority, ProjectStatus } from '../../types';

interface NewProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddProject: (newProj: Partial<Project>) => void;
}

export const NewProjectModal: React.FC<NewProjectModalProps> = ({
  isOpen,
  onClose,
  onAddProject
}) => {
  const [name, setName] = useState('');
  const [client, setClient] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Enterprise ERP');
  const [budget, setBudget] = useState('$2,500,000');
  const [deadline, setDeadline] = useState('2026-12-31');
  const [priority, setPriority] = useState<ProjectPriority>('High');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onAddProject({
      name,
      client: client || "Axion Technologies Partner",
      description: description || "Strategic digital transformation initiative.",
      category,
      budget,
      deadline,
      priority,
      status: 'Planning',
      progress: 0,
      manager: 'Adam Vance',
      team: ['Adam Vance', 'Elena Rostova']
    });

    setName('');
    setClient('');
    setDescription('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#050B18]/80 backdrop-blur-md flex items-center justify-center p-4 font-sans" id="axion-new-project-modal">
      <div className="bg-[#0A1228] border border-[#2563EB]/40 rounded-2xl w-full max-w-lg p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-[#101B35] pb-3">
          <div className="flex items-center gap-2 text-white font-bold text-sm">
            <FolderPlus className="w-5 h-5 text-[#4DA3FF]" />
            <span>Create New Enterprise Project</span>
          </div>
          <button onClick={onClose} className="text-[#94A3B8] hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div>
            <label className="text-[#94A3B8] block mb-1">Project Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Global Supply Chain Optimization"
              className="w-full bg-[#101B35] border border-[#2563EB]/30 rounded-xl px-3 py-2 text-white focus:outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[#94A3B8] block mb-1">Client Name</label>
              <input
                type="text"
                value={client}
                onChange={(e) => setClient(e.target.value)}
                placeholder="Client / Ministry"
                className="w-full bg-[#101B35] border border-[#2563EB]/30 rounded-xl px-3 py-2 text-white focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[#94A3B8] block mb-1">Category</label>
              <input
                type="text"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-[#101B35] border border-[#2563EB]/30 rounded-xl px-3 py-2 text-white focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-[#94A3B8] block mb-1">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="High-level objectives and architectural scope..."
              className="w-full bg-[#101B35] border border-[#2563EB]/30 rounded-xl px-3 py-2 text-white focus:outline-none h-20"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[#94A3B8] block mb-1">Budget</label>
              <input
                type="text"
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                className="w-full bg-[#101B35] border border-[#2563EB]/30 rounded-xl px-3 py-2 text-white focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[#94A3B8] block mb-1">Deadline</label>
              <input
                type="date"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-full bg-[#101B35] border border-[#2563EB]/30 rounded-xl px-3 py-2 text-white focus:outline-none font-mono"
              />
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 bg-[#101B35] text-[#94A3B8] hover:text-white rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-2 bg-[#2563EB] hover:bg-[#3b82f6] text-white rounded-xl font-semibold shadow-md"
            >
              Provision Project
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

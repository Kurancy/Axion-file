import React, { useState } from 'react';
import { 
  Search, 
  Sparkles, 
  Plus, 
  Upload, 
  ShieldCheck, 
  Bell, 
  Lock, 
  ChevronDown, 
  Command,
  Server,
  Zap,
  CheckCircle2
} from 'lucide-react';

interface HeaderProps {
  onOpenSearch: () => void;
  onOpenAiAssistant: () => void;
  onOpenNewProjectModal: () => void;
  onOpenUploadDocModal: () => void;
  unreadCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSearch,
  onOpenAiAssistant,
  onOpenNewProjectModal,
  onOpenUploadDocModal,
  unreadCount = 3
}) => {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  return (
    <header className="relative z-10 h-16 bg-[#0A1228]/90 backdrop-blur-md border-b border-[#101B35] px-6 flex items-center justify-between gap-4 shrink-0 select-none" id="axion-header">
      
      {/* Left: Global Knowledge Search Trigger */}
      <div className="flex items-center gap-3 flex-1 max-w-xl">
        <button
          onClick={onOpenSearch}
          className="w-full flex items-center gap-3 px-4 py-2 bg-[#101B35]/80 hover:bg-[#101B35] border border-[#2563EB]/30 rounded-xl text-xs text-[#94A3B8] hover:text-white transition-all shadow-sm group font-sans"
          id="global-search-trigger"
        >
          <Search className="w-4 h-4 text-[#4DA3FF] group-hover:scale-110 transition-transform" />
          <span className="truncate flex-1 text-left">
            Search across projects, documents, and AI knowledge...
          </span>
          <div className="flex items-center gap-1 bg-[#050B18] px-2 py-0.5 rounded border border-white/10 text-[10px] font-mono text-[#94A3B8]">
            <Command className="w-3 h-3" />
            <span>K</span>
          </div>
        </button>
      </div>

      {/* Right: Actions, Badges & Profile */}
      <div className="flex items-center gap-3">
        
        {/* Security Shield Badge */}
        <div className="hidden lg:flex items-center gap-1.5 px-3 py-1 bg-[#050B18] border border-[#2563EB]/30 rounded-lg text-[11px] font-mono text-[#4DA3FF]">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>AES-256 HSM SECURE</span>
        </div>

        {/* Region & Cluster Badge */}
        <div className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 bg-[#101B35] border border-white/10 rounded-lg text-[11px] font-mono text-[#94A3B8]">
          <Server className="w-3.5 h-3.5 text-[#2563EB]" />
          <span>US-CENTRAL1</span>
        </div>

        {/* Axion AI Quick Action */}
        <button
          onClick={onOpenAiAssistant}
          className="flex items-center gap-2 px-3 py-1.5 bg-gradient-to-r from-[#2563EB] to-[#0D3B8F] hover:from-[#3b82f6] hover:to-[#1d4ed8] text-white rounded-xl text-xs font-semibold shadow-[0_0_15px_rgba(37,99,235,0.4)] border border-[#4DA3FF]/40 transition-all active:scale-95 font-sans"
          id="quick-axion-ai-btn"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#4DA3FF] animate-pulse" />
          <span className="hidden sm:inline">Axion AI</span>
        </button>

        {/* New Project Button */}
        <button
          onClick={onOpenNewProjectModal}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-[#101B35] hover:bg-[#101B35]/80 text-white rounded-xl text-xs font-medium border border-[#2563EB]/30 transition-all active:scale-95 font-sans"
          id="new-project-header-btn"
        >
          <Plus className="w-3.5 h-3.5 text-[#4DA3FF]" />
          <span className="hidden md:inline">Project</span>
        </button>

        {/* Upload Document Button */}
        <button
          onClick={onOpenUploadDocModal}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-[#101B35] hover:bg-[#101B35]/80 text-white rounded-xl text-xs font-medium border border-[#2563EB]/30 transition-all active:scale-95 font-sans"
          id="upload-doc-header-btn"
        >
          <Upload className="w-3.5 h-3.5 text-[#4DA3FF]" />
          <span className="hidden md:inline">Upload</span>
        </button>

        <div className="h-6 w-px bg-[#101B35] mx-1" />

        {/* Notifications Popover Toggle */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 rounded-xl text-[#94A3B8] hover:text-white hover:bg-[#101B35] border border-transparent hover:border-[#2563EB]/30 transition-all relative"
            id="notifications-popover-trigger"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#2563EB] ring-2 ring-[#0A1228]" />
            )}
          </button>

          {/* Notifications Dropdown */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-[#0A1228] border border-[#2563EB]/40 rounded-2xl shadow-2xl p-4 z-50 animate-in fade-in slide-in-from-top-2">
              <div className="flex items-center justify-between pb-3 border-b border-[#101B35] mb-3">
                <span className="text-xs font-bold text-white font-sans">System Alerts & AI Insights</span>
                <span className="text-[10px] bg-[#2563EB]/20 text-[#4DA3FF] px-2 py-0.5 rounded-full font-mono">
                  {unreadCount} Unread
                </span>
              </div>
              <div className="space-y-2.5 text-xs">
                <div className="p-2.5 rounded-xl bg-[#101B35]/80 border border-[#2563EB]/20 flex items-start gap-2.5">
                  <Sparkles className="w-4 h-4 text-[#4DA3FF] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-white">Axion AI Risk Report Ready</p>
                    <p className="text-[#94A3B8] text-[11px] mt-0.5">Sunshine Education ERP risk score evaluated at 18 (Low).</p>
                    <span className="text-[9px] text-[#94A3B8]/60 font-mono mt-1 block">12 mins ago</span>
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-[#101B35]/80 border border-[#2563EB]/20 flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-white">UAT Benchmark Passed</p>
                    <p className="text-[#94A3B8] text-[11px] mt-0.5">Warehouse Robotics vision pipeline completed 100% test cases.</p>
                    <span className="text-[9px] text-[#94A3B8]/60 font-mono mt-1 block">1 hour ago</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* User Avatar Menu Toggle */}
        <div className="relative">
          <button
            onClick={() => setShowProfileMenu(!showProfileMenu)}
            className="flex items-center gap-2 p-1 rounded-xl hover:bg-[#101B35] border border-transparent hover:border-[#2563EB]/30 transition-all"
            id="user-profile-menu-trigger"
          >
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150"
              alt="Adam Vance"
              className="w-7 h-7 rounded-lg object-cover ring-2 ring-[#2563EB]/50"
            />
            <ChevronDown className="w-3.5 h-3.5 text-[#94A3B8]" />
          </button>

          {/* Profile Dropdown */}
          {showProfileMenu && (
            <div className="absolute right-0 mt-2 w-64 bg-[#0A1228] border border-[#2563EB]/40 rounded-2xl shadow-2xl p-3 z-50 font-sans">
              <div className="p-2 border-b border-[#101B35] mb-2">
                <p className="text-xs font-bold text-white">Adam Vance</p>
                <p className="text-[11px] text-[#94A3B8]">adam.vance@axiontech.com</p>
                <span className="inline-block mt-1.5 px-2 py-0.5 bg-[#2563EB]/20 text-[#4DA3FF] text-[10px] font-mono rounded border border-[#2563EB]/30">
                  Global Administrator
                </span>
              </div>
              <div className="space-y-1 text-xs text-[#94A3B8]">
                <div className="px-2 py-1.5 hover:bg-[#101B35] hover:text-white rounded-lg cursor-pointer flex items-center justify-between">
                  <span>Security & MFA</span>
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <div className="px-2 py-1.5 hover:bg-[#101B35] hover:text-white rounded-lg cursor-pointer flex items-center justify-between">
                  <span>System Diagnostics</span>
                  <Zap className="w-3.5 h-3.5 text-[#4DA3FF]" />
                </div>
              </div>
            </div>
          )}
        </div>

      </div>
    </header>
  );
};

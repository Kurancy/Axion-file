import React, { useState, useEffect } from 'react';
import { 
  Search, 
  X, 
  FileText, 
  FolderKanban, 
  CheckCircle, 
  Sparkles, 
  ArrowRight, 
  Filter, 
  Code, 
  ShieldCheck, 
  Database,
  Tag
} from 'lucide-react';
import { Project, DocumentItem, TaskItem, SearchResult } from '../types';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  projects: Project[];
  documents: DocumentItem[];
  tasks: TaskItem[];
  onSelectProject: (proj: Project) => void;
  onSelectDocument: (doc: DocumentItem) => void;
}

const exampleQueries = [
  "Show the signed contract for Sunshine ERP",
  "Find all SAP Business One documents",
  "Summarize the warehouse project",
  "Show deployment architecture",
  "Find API authentication requirements"
];

const categoryFilters = [
  "All", "Projects", "Documents", "PDFs", "SQL", "API Specs", "AI Knowledge"
];

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  projects,
  documents,
  tasks,
  onSelectProject,
  onSelectDocument
}) => {
  const [query, setQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isAiSynthesizing, setIsAiSynthesizing] = useState(false);
  const [aiSynthesisText, setAiSynthesisText] = useState<string | null>(null);

  useEffect(() => {
    if (!query.trim()) {
      setSearchResults([]);
      setAiSynthesisText(null);
      return;
    }

    const qLower = query.toLowerCase();

    // Filter projects
    const matchedProjects: SearchResult[] = (projects || [])
      .filter(p => 
        (p.name || '').toLowerCase().includes(qLower) || 
        (p.client || '').toLowerCase().includes(qLower) || 
        (p.description || '').toLowerCase().includes(qLower) || 
        (p.tags?.some(t => t.toLowerCase().includes(qLower)) ?? false)
      )
      .map(p => ({
        id: `sr-proj-${p.id}`,
        title: p.name,
        type: 'Project',
        subtitle: `Client: ${p.client} • Progress: ${p.progress}% • ${p.status}`,
        snippet: p.description,
        score: 95,
        matchType: 'Project Record',
        item: p
      }));

    // Filter documents
    const matchedDocs: SearchResult[] = (documents || [])
      .filter(d => 
        (d.name || '').toLowerCase().includes(qLower) || 
        (d.project || '').toLowerCase().includes(qLower) || 
        (d.aiSummary || '').toLowerCase().includes(qLower) || 
        (d.tags?.some(t => t.toLowerCase().includes(qLower)) ?? false)
      )
      .map(d => ({
        id: `sr-doc-${d.id}`,
        title: d.name,
        type: 'Document',
        subtitle: `Project: ${d.project} • ${d.category} • ${d.fileSize}`,
        snippet: d.aiSummary,
        score: 90,
        matchType: 'Document Metadata',
        item: d
      }));

    setSearchResults([...matchedProjects, ...matchedDocs]);
  }, [query, projects, documents]);

  // AI Knowledge Search synthesis trigger
  const handleAiSynthesize = async (searchPrompt: string) => {
    setQuery(searchPrompt);
    setIsAiSynthesizing(true);
    setAiSynthesisText(null);

    try {
      const res = await fetch('/api/ai/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchPrompt })
      });
      const data = await res.json();
      setAiSynthesisText(data.synthesis || "Found matches across workspace records.");
    } catch (err) {
      console.error(err);
      setAiSynthesisText("Synthesis unavailable. Showing direct record matches below.");
    } finally {
      setIsAiSynthesizing(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#050B18]/80 backdrop-blur-md flex items-start justify-center p-4 sm:p-10 font-sans" id="axion-global-search-modal">
      <div className="bg-[#0A1228] border border-[#2563EB]/40 rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95">
        
        {/* Search Header Bar */}
        <div className="p-4 border-b border-[#101B35] flex items-center gap-3 bg-[#050B18]">
          <Search className="w-5 h-5 text-[#4DA3FF]" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search across all projects, documents, and knowledge..."
            className="flex-1 bg-transparent text-sm text-white placeholder-[#94A3B8] focus:outline-none font-sans"
            autoFocus
            id="global-search-input"
          />
          {query && (
            <button onClick={() => setQuery('')} className="text-[#94A3B8] hover:text-white">
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="px-2.5 py-1 bg-[#101B35] hover:bg-[#101B35]/80 text-[#94A3B8] hover:text-white rounded-lg text-xs font-mono border border-white/10"
          >
            ESC
          </button>
        </div>

        {/* Filter Chips Bar */}
        <div className="px-4 py-2 bg-[#0A1228] border-b border-[#101B35] flex items-center gap-2 overflow-x-auto no-scrollbar">
          <Filter className="w-3.5 h-3.5 text-[#94A3B8] shrink-0" />
          {categoryFilters.map((f) => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                activeFilter === f
                  ? 'bg-[#2563EB] text-white'
                  : 'bg-[#101B35] text-[#94A3B8] hover:text-white'
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
          
          {/* Example Prompts if empty query */}
          {!query && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-[#94A3B8] font-mono">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#4DA3FF]" />
                  RECOMMENDED ENTERPRISE KNOWLEDGE QUERIES
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {exampleQueries.map((prompt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleAiSynthesize(prompt)}
                    className="p-3 bg-[#101B35]/70 hover:bg-[#101B35] border border-[#2563EB]/20 hover:border-[#4DA3FF]/40 rounded-xl text-left text-xs text-[#94A3B8] hover:text-white transition-all flex items-center justify-between group"
                  >
                    <span className="truncate pr-2 font-medium">{prompt}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#4DA3FF] opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* AI Synthesis Banner if present */}
          {isAiSynthesizing && (
            <div className="p-4 rounded-xl bg-[#101B35] border border-[#2563EB]/40 flex items-center gap-3 text-xs text-[#4DA3FF] animate-pulse font-mono">
              <Sparkles className="w-5 h-5 text-[#4DA3FF] animate-spin" />
              <span>Axion AI Knowledge Engine synthesizing cross-workspace records...</span>
            </div>
          )}

          {aiSynthesisText && !isAiSynthesizing && (
            <div className="p-4 rounded-xl bg-[#101B35]/90 border border-[#2563EB]/40 text-xs text-slate-200 leading-relaxed font-sans shadow-lg space-y-2">
              <div className="flex items-center justify-between text-[#4DA3FF] font-mono text-[11px] font-semibold">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  AXION AI KNOWLEDGE SYNTHESIS
                </span>
                <span className="bg-[#2563EB]/30 px-2 py-0.5 rounded text-[10px]">GEMINI GROUNDED</span>
              </div>
              <div className="prose prose-invert max-w-none text-xs">
                {aiSynthesisText}
              </div>
            </div>
          )}

          {/* Direct Search Results */}
          {searchResults.length > 0 && (
            <div className="space-y-2">
              <div className="text-[11px] font-mono text-[#94A3B8] uppercase">
                Direct Workspace Matches ({searchResults.length})
              </div>

              <div className="space-y-2">
                {searchResults.map((res) => (
                  <div
                    key={res.id}
                    onClick={() => {
                      if (res.type === 'Project') onSelectProject(res.item as Project);
                      if (res.type === 'Document') onSelectDocument(res.item as DocumentItem);
                      onClose();
                    }}
                    className="p-3.5 bg-[#101B35]/80 hover:bg-[#101B35] border border-[#2563EB]/20 hover:border-[#4DA3FF]/40 rounded-xl cursor-pointer transition-all flex items-start gap-3 group"
                  >
                    <div className="p-2 rounded-lg bg-[#050B18] text-[#4DA3FF] border border-[#2563EB]/30 shrink-0">
                      {res.type === 'Project' ? <FolderKanban className="w-4 h-4" /> : <FileText className="w-4 h-4" />}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-white group-hover:text-[#4DA3FF] transition-colors truncate">
                          {res.title}
                        </h4>
                        <span className="text-[10px] font-mono bg-[#2563EB]/20 text-[#4DA3FF] px-2 py-0.5 rounded border border-[#2563EB]/30 shrink-0">
                          {res.type}
                        </span>
                      </div>
                      <p className="text-[11px] text-[#94A3B8] font-mono mt-0.5">{res.subtitle}</p>
                      <p className="text-xs text-slate-300 mt-1.5 line-clamp-2">{res.snippet}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-[#050B18] border-t border-[#101B35] text-[10px] text-[#94A3B8] font-mono flex items-center justify-between">
          <span>Axion Vault Indexing v2.4</span>
          <span>Press ESC to close</span>
        </div>

      </div>
    </div>
  );
};

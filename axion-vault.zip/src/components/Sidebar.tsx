import React from 'react';
import { AxionLogo } from './AxionLogo';
import { ViewType } from '../types';
import {
  LayoutDashboard,
  FolderKanban,
  FileText,
  BrainCircuit,
  CalendarCheck,
  Users,
  BarChart3,
  ShieldCheck,
  Settings,
  ChevronLeft,
  ChevronRight,
  Bell,
  Activity
} from 'lucide-react';

interface SidebarProps {
  currentView: ViewType;
  onNavigate: (view: ViewType) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  unreadNotificationsCount?: number;
  onOpenNotifications?: () => void;
}

const menuItems: { id: ViewType; label: string; icon: React.FC<{ className?: string }>; badge?: string }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'projects', label: 'Projects', icon: FolderKanban, badge: '5 Active' },
  { id: 'documents', label: 'Documents', icon: FileText, badge: '1.4k' },
  { id: 'ai-knowledge', label: 'AI Knowledge', icon: BrainCircuit, badge: 'Gemini' },
  { id: 'tasks', label: 'Tasks', icon: CalendarCheck, badge: '5 Pending' },
  { id: 'team', label: 'Team', icon: Users },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'vault', label: 'Secure Vault', icon: ShieldCheck, badge: 'AES-256' },
  { id: 'settings', label: 'Settings', icon: Settings }
];

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  collapsed,
  onToggleCollapse,
  unreadNotificationsCount = 3,
  onOpenNotifications
}) => {
  return (
    <aside 
      className={`relative z-20 flex flex-col bg-[#0A1228] border-r border-[#101B35] transition-all duration-300 ease-in-out shrink-0 select-none ${
        collapsed ? 'w-20' : 'w-64'
      }`}
      id="axion-sidebar"
    >
      {/* Top Header with Logo */}
      <div className="flex items-center justify-between h-16 px-4 border-b border-[#101B35]">
        {collapsed ? (
          <div className="mx-auto cursor-pointer" onClick={() => onNavigate('dashboard')}>
            <AxionLogo size="sm" showText={false} />
          </div>
        ) : (
          <div className="cursor-pointer" onClick={() => onNavigate('dashboard')}>
            <AxionLogo size="md" showText={true} tagline={true} />
          </div>
        )}

        <button
          onClick={onToggleCollapse}
          className="p-1.5 rounded-lg text-[#94A3B8] hover:text-white hover:bg-[#101B35] transition-colors border border-transparent hover:border-[#2563EB]/30 focus:outline-none"
          title={collapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          id="toggle-sidebar-btn"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1.5 custom-scrollbar">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl font-medium text-sm transition-all duration-200 group relative ${
                isActive
                  ? 'bg-gradient-to-r from-[#2563EB] to-[#0D3B8F] text-white shadow-[0_0_15px_rgba(37,99,235,0.4)] border border-[#4DA3FF]/30'
                  : 'text-[#94A3B8] hover:text-white hover:bg-[#101B35]/80'
              }`}
              id={`nav-item-${item.id}`}
            >
              <Icon 
                className={`w-5 h-5 shrink-0 transition-colors ${
                  isActive ? 'text-[#4DA3FF]' : 'text-[#94A3B8] group-hover:text-white'
                }`} 
              />

              {!collapsed && (
                <span className="truncate flex-1 text-left font-sans">{item.label}</span>
              )}

              {!collapsed && item.badge && (
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-semibold ${
                    isActive
                      ? 'bg-white/20 text-white'
                      : 'bg-[#101B35] text-[#4DA3FF] border border-[#2563EB]/20'
                  }`}
                >
                  {item.badge}
                </span>
              )}

              {/* Collapsed Tooltip */}
              {collapsed && (
                <div className="absolute left-full ml-2 px-2.5 py-1 bg-[#050B18] text-white text-xs rounded-md shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-200 z-50 border border-[#2563EB]/30 font-sans">
                  {item.label}
                </div>
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom Footer Section */}
      <div className="p-3 border-t border-[#101B35] space-y-2 bg-[#050B18]/50">
        
        {/* System Health Status Indicator */}
        <div className={`flex items-center gap-2 p-2 rounded-lg bg-[#101B35]/50 border border-[#2563EB]/20 text-xs font-mono ${collapsed ? 'justify-center' : ''}`}>
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          {!collapsed && (
            <div className="flex items-center justify-between w-full text-[11px] text-[#94A3B8]">
              <span>System Health</span>
              <span className="text-emerald-400 font-semibold">99.98%</span>
            </div>
          )}
        </div>

        {/* Notifications Bar */}
        <button
          onClick={onOpenNotifications}
          className={`w-full flex items-center gap-3 p-2 rounded-xl text-[#94A3B8] hover:text-white hover:bg-[#101B35] transition-colors text-xs font-medium ${
            collapsed ? 'justify-center' : ''
          }`}
          id="sidebar-notifications-btn"
        >
          <div className="relative">
            <Bell className="w-4 h-4 text-[#4DA3FF]" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#2563EB] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#2563EB]"></span>
              </span>
            )}
          </div>
          {!collapsed && (
            <div className="flex items-center justify-between flex-1">
              <span>Notifications</span>
              <span className="px-1.5 py-0.2 bg-[#2563EB]/20 text-[#4DA3FF] rounded-full text-[10px] font-mono border border-[#2563EB]/30">
                {unreadNotificationsCount} new
              </span>
            </div>
          )}
        </button>

        {/* User Profile */}
        <div className={`flex items-center gap-3 p-2 rounded-xl bg-[#101B35] border border-[#2563EB]/20 ${collapsed ? 'justify-center' : ''}`}>
          <img
            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150"
            alt="Adam Vance"
            className="w-8 h-8 rounded-lg object-cover ring-2 ring-[#2563EB]/40 shrink-0"
          />
          {!collapsed && (
            <div className="flex flex-col min-w-0 flex-1">
              <span className="text-xs font-semibold text-white truncate font-sans">Adam Vance</span>
              <span className="text-[10px] text-[#94A3B8] truncate font-mono">Solutions Architect</span>
            </div>
          )}
        </div>

      </div>
    </aside>
  );
};

import React from 'react';

interface AxionLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  tagline?: boolean;
  className?: string;
}

export const AxionLogo: React.FC<AxionLogoProps> = ({
  size = 'md',
  showText = true,
  tagline = false,
  className = ''
}) => {
  const sizeMap = {
    sm: { grid: 'w-7 h-7 p-0.5 gap-0.5', text: 'text-base', sub: 'text-[9px]' },
    md: { grid: 'w-9 h-9 p-1 gap-1', text: 'text-xl', sub: 'text-[10px]' },
    lg: { grid: 'w-12 h-12 p-1.5 gap-1.5', text: 'text-2xl', sub: 'text-xs' },
    xl: { grid: 'w-20 h-20 p-2.5 gap-2.5', text: 'text-4xl', sub: 'text-sm' }
  };

  const current = sizeMap[size];

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* 2x2 Grid Axion Logo */}
      <div 
        className={`relative ${current.grid} bg-[#0A1228] border border-[#2563EB]/30 rounded-xl shadow-[0_0_20px_rgba(37,99,235,0.3)] grid grid-cols-2 grid-rows-2 items-center justify-center shrink-0 transition-transform duration-300 hover:scale-105`}
        id="axion-logo-grid"
      >
        {/* Soft Blue Outer Glow Background */}
        <div className="absolute inset-0 rounded-xl bg-[#4DA3FF]/15 blur-md -z-10" />

        {/* Top Left: #4DA3FF */}
        <div className="bg-[#4DA3FF] w-full h-full rounded-[4px] shadow-[0_0_8px_#4DA3FF]" />
        {/* Top Right: #0D3B8F */}
        <div className="bg-[#0D3B8F] w-full h-full rounded-[4px]" />
        {/* Bottom Left: #0D3B8F */}
        <div className="bg-[#0D3B8F] w-full h-full rounded-[4px]" />
        {/* Bottom Right: #4DA3FF */}
        <div className="bg-[#4DA3FF] w-full h-full rounded-[4px] shadow-[0_0_8px_#4DA3FF]" />
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className={`font-bold tracking-wider text-white font-sans ${current.text}`}>
              AXION
            </span>
            <span className={`font-semibold tracking-wide text-[#4DA3FF] ${current.text}`}>
              VAULT
            </span>
          </div>
          {tagline && (
            <span className={`text-[#94A3B8] font-medium tracking-wide uppercase ${current.sub}`}>
              Enterprise Project Intelligence
            </span>
          )}
        </div>
      )}
    </div>
  );
};

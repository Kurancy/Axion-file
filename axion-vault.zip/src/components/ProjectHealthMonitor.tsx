import React, { useState } from 'react';
import { 
  AlertTriangle, 
  ShieldAlert, 
  Clock, 
  Activity, 
  ChevronRight, 
  Sparkles, 
  CheckCircle, 
  Eye, 
  X,
  SlidersHorizontal
} from 'lucide-react';
import { Project } from '../types';
import { evaluateProjectHealth, ProjectHealthAssessment } from '../utils/projectHealth';

interface ProjectHealthMonitorProps {
  projects: Project[];
  onSelectProject: (project: Project) => void;
  onNavigate: (view: string) => void;
  onConsultAi?: (project: Project) => void;
}

export const ProjectHealthMonitor: React.FC<ProjectHealthMonitorProps> = ({
  projects,
  onSelectProject,
  onNavigate,
  onConsultAi
}) => {
  const [filter, setFilter] = useState<'all' | 'critical' | 'warning'>('all');
  const [acknowledgedIds, setAcknowledgedIds] = useState<string[]>([]);

  const assessments = projects
    .map(evaluateProjectHealth)
    .filter(a => !acknowledgedIds.includes(a.project.id));

  const criticalAlerts = assessments.filter(a => a.healthLevel === 'critical');
  const warningAlerts = assessments.filter(a => a.healthLevel === 'warning');
  const alertAssessments = assessments.filter(a => a.healthLevel !== 'healthy');

  const filteredAlerts = alertAssessments.filter(a => {
    if (filter === 'critical') return a.healthLevel === 'critical';
    if (filter === 'warning') return a.healthLevel === 'warning';
    return true;
  });

  const avgRiskScore = Math.round(
    projects.reduce((acc, p) => acc + (p.riskScore ?? 0), 0) / (projects.length || 1)
  );

  const handleAcknowledge = (projectId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setAcknowledgedIds(prev => [...prev, projectId]);
  };

  if (alertAssessments.length === 0) {
    return (
      <div className="p-4 bg-[#0A1228] border border-emerald-500/30 rounded-2xl shadow-lg flex items-center justify-between gap-4 font-sans">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              Automated Project Health Monitoring System
            </h3>
            <p className="text-xs text-[#94A3B8]">
              All {projects.length} active enterprise projects are operating within safe risk thresholds ({avgRiskScore}/100 Avg Risk).
            </p>
          </div>
        </div>
        {acknowledgedIds.length > 0 && (
          <button 
            onClick={() => setAcknowledgedIds([])}
            className="text-xs text-[#4DA3FF] hover:underline font-mono shrink-0"
          >
            Reset {acknowledgedIds.length} Acknowledged Alerts
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="p-5 bg-[#0A1228] border border-amber-500/30 rounded-2xl shadow-2xl space-y-4 font-sans relative overflow-hidden">
      {/* Top Banner Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#101B35] pb-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-500/40 shrink-0 animate-pulse">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                Automated Health Warning System
              </h3>
              <span className="px-2 py-0.5 bg-red-500/20 text-red-400 border border-red-500/30 text-[10px] font-mono font-bold rounded-full flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-ping" />
                {criticalAlerts.length} CRITICAL
              </span>
              <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold rounded-full">
                {warningAlerts.length} WARNINGS
              </span>
            </div>
            <p className="text-xs text-[#94A3B8] mt-1">
              Surfacing automated warnings for projects exceeding critical risk scores or tight deadline progress thresholds.
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 shrink-0 self-start md:self-center">
          <button
            onClick={() => setFilter('all')}
            className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all ${
              filter === 'all' 
                ? 'bg-[#2563EB] text-white font-bold' 
                : 'bg-[#101B35] text-[#94A3B8] hover:text-white border border-white/5'
            }`}
          >
            All ({alertAssessments.length})
          </button>
          <button
            onClick={() => setFilter('critical')}
            className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all ${
              filter === 'critical' 
                ? 'bg-red-600 text-white font-bold' 
                : 'bg-[#101B35] text-[#94A3B8] hover:text-white border border-white/5'
            }`}
          >
            Critical ({criticalAlerts.length})
          </button>
          <button
            onClick={() => setFilter('warning')}
            className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all ${
              filter === 'warning' 
                ? 'bg-amber-600 text-white font-bold' 
                : 'bg-[#101B35] text-[#94A3B8] hover:text-white border border-white/5'
            }`}
          >
            Elevated ({warningAlerts.length})
          </button>
        </div>
      </div>

      {/* Alert Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredAlerts.map(({ project, healthLevel, healthScore, riskScore, daysRemaining, reasons }) => {
          const isCritical = healthLevel === 'critical';

          return (
            <div
              key={project.id}
              onClick={() => onSelectProject(project)}
              className={`p-4 rounded-xl border transition-all cursor-pointer space-y-3 relative group ${
                isCritical
                  ? 'bg-gradient-to-br from-[#120815] to-[#0A1228] border-red-500/40 hover:border-red-400/80 shadow-red-950/20 shadow-lg'
                  : 'bg-gradient-to-br from-[#13120B] to-[#0A1228] border-amber-500/40 hover:border-amber-400/80 shadow-amber-950/20 shadow-lg'
              }`}
            >
              {/* Card Top Row */}
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-extrabold uppercase border ${
                      isCritical
                        ? 'bg-red-500/20 text-red-300 border-red-500/40'
                        : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    }`}>
                      {isCritical ? 'CRITICAL ALERT' : 'ELEVATED RISK'}
                    </span>
                    <span className="text-[10px] font-mono text-[#94A3B8]">
                      Manager: {project.manager}
                    </span>
                  </div>

                  <h4 className="text-xs font-extrabold text-white group-hover:text-[#4DA3FF] transition-colors mt-1 truncate">
                    {project.name}
                  </h4>
                  <p className="text-[10px] text-[#94A3B8] font-mono truncate">
                    {project.client} • {project.category}
                  </p>
                </div>

                <button
                  onClick={(e) => handleAcknowledge(project.id, e)}
                  className="p-1 text-[#94A3B8] hover:text-white hover:bg-white/10 rounded-lg transition-colors shrink-0"
                  title="Acknowledge Alert"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Metric Indicators Row */}
              <div className="grid grid-cols-3 gap-2 p-2 bg-[#050B18]/80 rounded-lg border border-white/5 font-mono text-[10px]">
                <div>
                  <span className="text-[#94A3B8] block text-[9px]">Risk Score</span>
                  <span className={`font-bold ${isCritical ? 'text-red-400' : 'text-amber-400'}`}>
                    {riskScore} / 100
                  </span>
                </div>

                <div>
                  <span className="text-[#94A3B8] block text-[9px]">Deadline</span>
                  <span className="text-white font-bold">
                    {daysRemaining !== null 
                      ? (daysRemaining < 0 ? `${Math.abs(daysRemaining)}d Overdue` : `${daysRemaining} days left`) 
                      : 'N/A'}
                  </span>
                </div>

                <div>
                  <span className="text-[#94A3B8] block text-[9px]">Health Score</span>
                  <span className={`font-bold ${healthScore < 50 ? 'text-red-400' : 'text-amber-300'}`}>
                    {healthScore}%
                  </span>
                </div>
              </div>

              {/* Triggered Reasons Badges */}
              <div className="space-y-1">
                <span className="text-[9px] font-mono text-[#94A3B8] uppercase tracking-wider block">
                  Automated Trigger Criteria:
                </span>
                <div className="flex flex-wrap gap-1">
                  {reasons.map((reason, idx) => (
                    <span 
                      key={idx}
                      className="text-[10px] px-2 py-0.5 rounded bg-[#101B35] text-slate-200 border border-white/10 font-mono"
                    >
                      • {reason}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-1 border-t border-white/5">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectProject(project);
                  }}
                  className="text-xs text-[#4DA3FF] hover:underline font-mono flex items-center gap-1 font-semibold"
                >
                  <Eye className="w-3 h-3" />
                  <span>Inspect Risk Breakdown</span>
                </button>

                {onConsultAi && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onConsultAi(project);
                    }}
                    className="px-2.5 py-1 bg-[#2563EB]/20 hover:bg-[#2563EB] text-[#4DA3FF] hover:text-white rounded text-[10px] font-mono border border-[#2563EB]/30 transition-all flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Ask AI Mitigation Plan</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

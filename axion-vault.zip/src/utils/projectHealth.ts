import { Project } from '../types';

export interface ProjectHealthAssessment {
  project: Project;
  healthLevel: 'critical' | 'warning' | 'healthy';
  healthScore: number; // 0-100 (100 = optimal health)
  riskScore: number;
  daysRemaining: number | null;
  isOverdue: boolean;
  triggers: {
    highRisk: boolean;
    tightDeadline: boolean;
    behindSchedule: boolean;
    criticalPriority: boolean;
  };
  reasons: string[];
}

export function evaluateProjectHealth(project: Project): ProjectHealthAssessment {
  const riskScore = project.riskScore ?? 0;
  
  let daysRemaining: number | null = null;
  let isOverdue = false;
  
  if (project.deadline) {
    const deadlineDate = new Date(project.deadline);
    // Use simulated current date (Jul 29, 2026) or runtime date
    const now = new Date('2026-07-29'); 
    const diffMs = deadlineDate.getTime() - now.getTime();
    daysRemaining = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    if (daysRemaining < 0) {
      isOverdue = true;
    }
  }

  const triggers = {
    highRisk: riskScore >= 60,
    moderateRisk: riskScore >= 40 && riskScore < 60,
    tightDeadline: daysRemaining !== null && daysRemaining <= 30 && daysRemaining >= 0,
    behindSchedule: daysRemaining !== null && daysRemaining <= 60 && project.progress < 75 && project.status !== 'Completed',
    criticalPriority: project.priority === 'Critical' && project.status !== 'Completed',
  };

  const reasons: string[] = [];

  if (project.status === 'Completed') {
    return {
      project,
      healthLevel: 'healthy',
      healthScore: 100,
      riskScore,
      daysRemaining,
      isOverdue: false,
      triggers: {
        highRisk: false,
        tightDeadline: false,
        behindSchedule: false,
        criticalPriority: false,
      },
      reasons: ['Project Completed Successfully']
    };
  }

  if (isOverdue) {
    reasons.push(`Overdue deadline (${project.deadline})`);
  }
  if (triggers.highRisk) {
    reasons.push(`High risk score (${riskScore}/100)`);
  } else if (triggers.moderateRisk) {
    reasons.push(`Elevated risk score (${riskScore}/100)`);
  }

  if (daysRemaining !== null && daysRemaining >= 0 && daysRemaining <= 60) {
    reasons.push(`Deadline in ${daysRemaining} days (${project.progress}% progress)`);
  }

  if (triggers.behindSchedule && !reasons.some(r => r.includes('progress'))) {
    reasons.push(`Progress lagging behind schedule (${project.progress}% completed)`);
  }

  // Calculate overall health score (0 = worst, 100 = best)
  let baseScore = 100 - riskScore;
  
  if (isOverdue) {
    baseScore -= 30;
  } else if (triggers.tightDeadline && project.progress < 70) {
    baseScore -= 20;
  }

  const healthScore = Math.max(0, Math.min(100, Math.round(baseScore)));

  let healthLevel: 'critical' | 'warning' | 'healthy' = 'healthy';
  if (healthScore < 50 || riskScore >= 65 || (daysRemaining !== null && daysRemaining <= 25 && project.progress < 65)) {
    healthLevel = 'critical';
  } else if (healthScore < 75 || riskScore >= 40 || (daysRemaining !== null && daysRemaining <= 60 && project.progress < 75)) {
    healthLevel = 'warning';
  }

  return {
    project,
    healthLevel,
    healthScore,
    riskScore,
    daysRemaining,
    isOverdue,
    triggers: {
      highRisk: triggers.highRisk,
      tightDeadline: triggers.tightDeadline,
      behindSchedule: triggers.behindSchedule,
      criticalPriority: triggers.criticalPriority,
    },
    reasons
  };
}

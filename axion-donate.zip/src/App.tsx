import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import confetti from 'canvas-confetti';
import { Language, Campaign, AdminUser, PlatformAnalytics } from './types';
import { translations } from './lib/translations';
import { getCampaigns, getAnalytics, getAdminMe, clearAdminToken } from './lib/api';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { CampaignCard } from './components/CampaignCard';
import { CampaignDetailModal } from './components/CampaignDetailModal';
import { DonationProofModal } from './components/DonationProofModal';
import { ShareModal } from './components/ShareModal';
import { AdminLoginModal } from './components/Admin/AdminLoginModal';
import { AdminDashboard } from './components/Admin/AdminDashboard';
import { Footer } from './components/Footer';
import { ToastContainer, ToastMessage } from './components/Toast';
import { ParticlesBackground } from './components/ParticlesBackground';

export default function App() {
  // Theme State
  const [isDark, setIsDark] = useState<boolean>(() => {
    const saved = localStorage.getItem('axion_theme');
    return saved ? saved === 'dark' : true; // Default dark enterprise theme
  });

  // Language State
  const [language, setLanguage] = useState<Language>('en');

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  // Data States
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [analytics, setAnalytics] = useState<PlatformAnalytics | null>(null);
  const [loading, setLoading] = useState(true);

  // Modals State
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const [shareTargetCampaign, setShareTargetCampaign] = useState<Campaign | null>(null);
  const [showProofModal, setShowProofModal] = useState(false);
  const [proofTargetCampaign, setProofTargetCampaign] = useState<Campaign | null>(null);

  // Admin Auth & Dashboard State
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [showAdminDashboard, setShowAdminDashboard] = useState(false);

  // Toast Messages State
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (title: string, description?: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Date.now().toString();
    setToasts((prev) => [...prev, { id, title, description, type }]);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Sync dark mode class on <html>
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('axion_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('axion_theme', 'light');
    }
  }, [isDark]);

  // Load Campaigns & Analytics
  const loadPublicData = async () => {
    setLoading(true);
    try {
      const [cList, aData] = await Promise.all([
        getCampaigns({ category: selectedCategory, search: searchQuery }),
        getAnalytics(),
      ]);
      setCampaigns(cList);
      setAnalytics(aData);
    } catch (err) {
      console.error('Error fetching public campaign data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPublicData();
  }, [selectedCategory, searchQuery]);

  // Check initial admin token on mount
  useEffect(() => {
    getAdminMe()
      .then((user) => {
        setAdminUser(user);
      })
      .catch(() => {
        setAdminUser(null);
      });
  }, []);

  const handleAdminLogout = () => {
    clearAdminToken();
    setAdminUser(null);
    setShowAdminDashboard(false);
    addToast('Signed Out', 'Admin session terminated.', 'info');
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans relative transition-colors duration-300 flex flex-col selection:bg-emerald-500 selection:text-white">
      
      {/* Dynamic Ambient Background */}
      <ParticlesBackground isDark={isDark} />

      {/* Navigation Header */}
      <Header
        language={language}
        onLanguageChange={setLanguage}
        isDark={isDark}
        onToggleTheme={() => setIsDark(!isDark)}
        onOpenAdminLogin={() => setShowAdminLogin(true)}
        onOpenAdminDashboard={() => setShowAdminDashboard(true)}
        adminUser={adminUser}
        onLogoutAdmin={handleAdminLogout}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      {/* Main Content */}
      <main className="flex-1 relative z-10">
        
        {/* Hero Section */}
        <Hero
          language={language}
          analytics={analytics}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          onExploreClick={() => {
            const el = document.getElementById('campaigns');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          onOpenGlobalProofModal={() => {
            setProofTargetCampaign(null);
            setShowProofModal(true);
          }}
        />

        {/* Campaign Cards Section */}
        <section id="campaigns" className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                {selectedCategory === 'All' ? 'Active Verified Campaigns' : `${selectedCategory} Causes`}
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
                Direct transfers directly to beneficiary bank and TRC20 crypto wallets.
              </p>
            </div>

            <span className="text-xs font-semibold px-3 py-1 rounded-full bg-slate-200/60 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300">
              Showing {campaigns.length} Causes
            </span>
          </div>

          {loading ? (
            /* Skeleton Loading State */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-[26rem] rounded-2xl bg-slate-200/50 dark:bg-slate-800/50 animate-pulse" />
              ))}
            </div>
          ) : campaigns.length === 0 ? (
            /* Empty Search Results */
            <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
              <span className="text-3xl">🔍</span>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                No campaigns match your search
              </h3>
              <p className="text-xs text-slate-500">
                Try searching for another keyword or clearing category filters.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All');
                }}
                className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            /* Campaign Cards Grid */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {campaigns.map((campaign) => (
                <CampaignCard
                  key={campaign.id}
                  campaign={campaign}
                  language={language}
                  onSelect={(c) => setSelectedCampaign(c)}
                  onShare={(c) => setShareTargetCampaign(c)}
                  onQuickDonate={(c) => {
                    setProofTargetCampaign(c);
                    setShowProofModal(true);
                  }}
                />
              ))}
            </div>
          )}

        </section>

      </main>

      {/* Footer */}
      <Footer
        language={language}
        onOpenAdminLogin={() => setShowAdminLogin(true)}
        onOpenProofModal={() => {
          setProofTargetCampaign(null);
          setShowProofModal(true);
        }}
      />

      {/* Modals */}

      {/* Campaign Details View Modal */}
      <AnimatePresence>
        {selectedCampaign && (
          <CampaignDetailModal
            campaign={selectedCampaign}
            language={language}
            onClose={() => setSelectedCampaign(null)}
            onOpenProofModal={(c) => {
              setSelectedCampaign(null);
              setProofTargetCampaign(c);
              setShowProofModal(true);
            }}
            onShare={(c) => setShareTargetCampaign(c)}
            onCopySuccess={(msg) => addToast('Copied!', msg, 'success')}
          />
        )}
      </AnimatePresence>

      {/* Submit Proof Modal */}
      <AnimatePresence>
        {showProofModal && (
          <DonationProofModal
            campaigns={campaigns}
            preselectedCampaign={proofTargetCampaign}
            language={language}
            onClose={() => setShowProofModal(false)}
            onSuccessSubmitted={() => {
              confetti({
                particleCount: 100,
                spread: 70,
                origin: { y: 0.6 },
              });
              addToast('Proof Submitted!', 'Our admins will review your submission shortly.', 'success');
              loadPublicData();
            }}
          />
        )}
      </AnimatePresence>

      {/* Share Campaign Modal */}
      <AnimatePresence>
        {shareTargetCampaign && (
          <ShareModal
            campaign={shareTargetCampaign}
            language={language}
            onClose={() => setShareTargetCampaign(null)}
            onCopySuccess={(msg) => addToast('Copied!', msg, 'success')}
          />
        )}
      </AnimatePresence>

      {/* Admin Login Modal */}
      <AnimatePresence>
        {showAdminLogin && (
          <AdminLoginModal
            language={language}
            onClose={() => setShowAdminLogin(false)}
            onLoginSuccess={(user) => {
              setAdminUser(user);
              setShowAdminLogin(false);
              setShowAdminDashboard(true);
              addToast('Authenticated!', `Welcome back, ${user.name}`, 'success');
            }}
          />
        )}
      </AnimatePresence>

      {/* Admin Dashboard View */}
      {showAdminDashboard && adminUser && (
        <AdminDashboard
          adminUser={adminUser}
          language={language}
          onLogout={handleAdminLogout}
          onCloseDashboard={() => setShowAdminDashboard(false)}
          onToast={(title, desc, type) => {
            addToast(title, desc, type);
            loadPublicData();
          }}
        />
      )}

      {/* Global Toast Container */}
      <ToastContainer toasts={toasts} onDismiss={removeToast} />

    </div>
  );
}

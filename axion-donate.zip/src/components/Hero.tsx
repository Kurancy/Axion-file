import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, Heart, Sparkles, Building2, Coins, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Language, CampaignCategory, PlatformAnalytics } from '../types';
import { translations } from '../lib/translations';

interface HeroProps {
  language: Language;
  analytics: PlatformAnalytics | null;
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
  onExploreClick: () => void;
  onOpenGlobalProofModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  language,
  analytics,
  selectedCategory,
  onSelectCategory,
  onExploreClick,
  onOpenGlobalProofModal,
}) => {
  const t = translations[language];

  const categories: { label: string; value: string; icon: string }[] = [
    { label: t.allCategories, value: 'All', icon: '🌟' },
    { label: 'Medical', value: 'Medical', icon: '🏥' },
    { label: 'Emergency Relief', value: 'Emergency Relief', icon: '🚨' },
    { label: 'Education', value: 'Education', icon: '🎓' },
    { label: 'Environment', value: 'Environment', icon: '🌱' },
    { label: 'Community', value: 'Community', icon: '🤝' },
  ];

  return (
    <section className="relative overflow-hidden pt-12 pb-16 md:pt-20 md:pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top Direct Guarantee Badge */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-semibold mb-6 shadow-sm"
        >
          <ShieldCheck className="w-4 h-4 text-emerald-500" />
          <span>{t.transparencyPledge}</span>
          <span className="hidden sm:inline text-slate-400 dark:text-slate-500">•</span>
          <span className="hidden sm:inline font-normal">{t.transparencyDesc}</span>
        </motion.div>

        {/* Hero Title & Subtitle */}
        <div className="max-w-4xl">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-[1.15]"
          >
            {t.heroTitle.split('.')[0]}.{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 via-teal-400 to-indigo-500">
              {t.heroTitle.split('.')[1] || 'Zero Intermediaries.'}
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mt-6 text-lg sm:text-xl text-slate-600 dark:text-slate-300 leading-relaxed font-normal"
          >
            {t.heroSubtitle}
          </motion.p>
        </div>

        {/* Hero Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-8 flex flex-wrap items-center gap-4"
        >
          <button
            onClick={onExploreClick}
            className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm shadow-xl shadow-emerald-600/25 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <span>{t.exploreCampaigns}</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenGlobalProofModal}
            className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white font-semibold text-sm border border-slate-700/50 shadow-lg transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{t.confirmDonation}</span>
          </button>
        </motion.div>

        {/* Platform Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6"
        >
          {[
            {
              label: t.totalRaised,
              value: analytics ? `$${analytics.totalDonationsAmount.toLocaleString()}` : '$205,600+',
              icon: <Coins className="w-5 h-5 text-emerald-500" />,
              subText: '100% to beneficiaries',
            },
            {
              label: t.activeCount,
              value: analytics ? analytics.activeCampaigns : '3 Active',
              icon: <Heart className="w-5 h-5 text-rose-500" />,
              subText: 'Verified emergency causes',
            },
            {
              label: t.totalVisitors,
              value: analytics ? analytics.totalVisitors.toLocaleString() : '12,350+',
              icon: <Building2 className="w-5 h-5 text-indigo-500" />,
              subText: 'Global visitors',
            },
            {
              label: t.successRate,
              value: '100% Verified',
              icon: <Sparkles className="w-5 h-5 text-amber-500" />,
              subText: 'Bank & TRC20 direct',
            },
          ].map((stat, idx) => (
            <div
              key={idx}
              className="p-5 rounded-2xl bg-white/70 dark:bg-slate-900/70 border border-slate-200/80 dark:border-slate-800/80 shadow-md backdrop-blur-md hover:border-emerald-500/30 transition-all"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-medium text-slate-500 dark:text-slate-400">{stat.label}</span>
                <div className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800">{stat.icon}</div>
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                {stat.value}
              </div>
              <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium mt-1">
                {stat.subText}
              </p>
            </div>
          ))}
        </motion.div>

        {/* Category Pill Filters Bar */}
        <div className="mt-12 flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {categories.map((cat) => {
            const isSelected = selectedCategory === cat.value;
            return (
              <button
                key={cat.value}
                onClick={() => onSelectCategory(cat.value)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-md scale-105'
                    : 'bg-white/80 dark:bg-slate-900/80 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

      </div>
    </section>
  );
};

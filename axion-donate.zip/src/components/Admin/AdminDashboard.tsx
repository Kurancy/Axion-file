import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  LayoutDashboard,
  FolderPlus,
  FileCheck2,
  Image as ImageIcon,
  History,
  Settings,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  XCircle,
  Eye,
  TrendingUp,
  Building2,
  QrCode,
  DollarSign,
  Users,
  Shield,
  Upload,
  Search,
  ExternalLink,
  MessageCircle,
  Sparkles,
  X
} from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar } from 'recharts';
import { Campaign, DonorSubmission, CampaignUpdate, MediaFile, ActivityLog, PlatformAnalytics, AdminUser, Language } from '../../types';
import {
  getCampaigns,
  createCampaign,
  updateCampaign,
  deleteCampaign,
  getSubmissions,
  approveSubmission,
  rejectSubmission,
  postCampaignUpdate,
  getMediaFiles,
  uploadMediaFile,
  deleteMediaFile,
  getActivityLogs,
  getAnalytics,
} from '../../lib/api';

interface AdminDashboardProps {
  adminUser: AdminUser;
  language: Language;
  onLogout: () => void;
  onCloseDashboard: () => void;
  onToast: (title: string, desc?: string, type?: 'success' | 'error' | 'info') => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  adminUser,
  language,
  onLogout,
  onCloseDashboard,
  onToast,
}) => {
  const [activeTab, setActiveTab] = useState<'analytics' | 'campaigns' | 'submissions' | 'updates' | 'media' | 'logs'>('analytics');

  // Data States
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [submissions, setSubmissions] = useState<DonorSubmission[]>([]);
  const [mediaFiles, setMediaFiles] = useState<MediaFile[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [analytics, setAnalytics] = useState<PlatformAnalytics | null>(null);
  const [loading, setLoading] = useState(true);

  // Campaign Form Modal State
  const [showCampaignModal, setShowCampaignModal] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState<Campaign | null>(null);

  // Proof Image Preview Lightbox
  const [previewProofImage, setPreviewProofImage] = useState<string | null>(null);

  // New Campaign Form State
  const [formData, setFormData] = useState<Partial<Campaign>>({
    title: '',
    shortDescription: '',
    fullDescription: '',
    category: 'Medical',
    coverImage: 'https://images.unsplash.com/photo-1532629345422-7515f3d16bb0?auto=format&fit=crop&w=1200&q=80',
    galleryImages: [],
    targetAmount: 50000,
    currentAmount: 0,
    currency: 'USD',
    location: 'Nairobi, Kenya',
    beneficiaryName: 'St. Mary Foundation',
    beneficiaryType: 'NGO / Organization',
    bankAccount: {
      accountName: 'St Mary Foundation',
      accountNumber: '9082-1142-8809-3312',
      bankName: 'First International Bank',
      swiftCode: 'FIBANAKN'
    },
    cryptoWallet: {
      network: 'TRON (TRC20)',
      address: 'TYu8a9PzKm42x9LQp71VxN98kXmZp1Q3a7'
    },
    status: 'Active',
    featured: true,
  });

  // Post Update Form State
  const [updateTargetId, setUpdateTargetId] = useState<string>('');
  const [updateTitle, setUpdateTitle] = useState('');
  const [updateContent, setUpdateContent] = useState('');
  const [updateImage, setUpdateImage] = useState('');

  const loadData = async () => {
    setLoading(true);
    try {
      const [cRes, sRes, mRes, lRes, aRes] = await Promise.all([
        getCampaigns({ status: 'All' }),
        getSubmissions(),
        getMediaFiles(),
        getActivityLogs(),
        getAnalytics(),
      ]);
      setCampaigns(cRes);
      setSubmissions(sRes);
      setMediaFiles(mRes);
      setActivityLogs(lRes);
      setAnalytics(aRes);
      if (cRes.length > 0 && !updateTargetId) {
        setUpdateTargetId(cRes[0].id);
      }
    } catch (err) {
      console.error('Failed to load admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Save / Update Campaign Handler
  const handleSaveCampaign = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingCampaign) {
        await updateCampaign(editingCampaign.id, formData);
        onToast('Campaign Updated', `"${formData.title}" details updated successfully.`, 'success');
      } else {
        await createCampaign(formData);
        onToast('Campaign Published', `"${formData.title}" is now published and live!`, 'success');
      }
      setShowCampaignModal(false);
      setEditingCampaign(null);
      loadData();
    } catch (err: any) {
      onToast('Error Saving Campaign', err.message, 'error');
    }
  };

  const handleEditClick = (campaign: Campaign) => {
    setEditingCampaign(campaign);
    setFormData(campaign);
    setShowCampaignModal(true);
  };

  const handleDeleteClick = async (id: string, title: string) => {
    if (confirm(`Are you sure you want to delete "${title}"?`)) {
      try {
        await deleteCampaign(id);
        onToast('Campaign Deleted', `Deleted "${title}"`, 'info');
        loadData();
      } catch (err: any) {
        onToast('Error', err.message, 'error');
      }
    }
  };

  // Proof Approval Handler
  const handleApproveProof = async (id: string) => {
    try {
      await approveSubmission(id);
      onToast('Donation Approved!', 'Campaign target amount increased & supporter added to public feed.', 'success');
      loadData();
    } catch (err: any) {
      onToast('Error', err.message, 'error');
    }
  };

  const handleRejectProof = async (id: string) => {
    const notes = prompt('Enter rejection reason for donor notification:');
    if (notes !== null) {
      try {
        await rejectSubmission(id, notes);
        onToast('Proof Rejected', 'Submission marked as unverified.', 'info');
        loadData();
      } catch (err: any) {
        onToast('Error', err.message, 'error');
      }
    }
  };

  // Post Campaign Update Handler
  const handlePublishUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!updateTargetId || !updateTitle || !updateContent) return;

    try {
      await postCampaignUpdate(updateTargetId, updateTitle, updateContent, updateImage);
      onToast('Update Posted!', 'New progress report added to campaign.', 'success');
      setUpdateTitle('');
      setUpdateContent('');
      setUpdateImage('');
      loadData();
    } catch (err: any) {
      onToast('Error', err.message, 'error');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/90 backdrop-blur-md flex flex-col text-slate-100">
      
      {/* Top Admin Navigation Header */}
      <header className="sticky top-0 z-30 px-6 py-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-extrabold text-white">
                Axion Admin Control Center
              </h2>
              <span className="px-2 py-0.5 text-[10px] font-bold uppercase rounded bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                {adminUser.role}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Logged in as {adminUser.email}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onCloseDashboard}
            className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors"
          >
            Back to Public Site
          </button>
          <button
            onClick={onLogout}
            className="px-3.5 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-bold transition-colors"
          >
            Sign Out
          </button>
        </div>
      </header>

      {/* Main Admin Content Body */}
      <div className="flex-1 flex flex-col md:flex-row max-w-7xl w-full mx-auto p-4 md:p-6 gap-6">
        
        {/* Sidebar Nav Tabs */}
        <aside className="w-full md:w-64 space-y-1 shrink-0">
          {[
            { key: 'analytics', label: 'Dashboard & Analytics', icon: <LayoutDashboard className="w-4 h-4" /> },
            {
              key: 'campaigns',
              label: `Manage Campaigns (${campaigns.length})`,
              icon: <FolderPlus className="w-4 h-4" />
            },
            {
              key: 'submissions',
              label: `Proof Approvals (${submissions.filter(s => s.status === 'Pending').length})`,
              icon: <FileCheck2 className="w-4 h-4" />,
              badge: submissions.filter(s => s.status === 'Pending').length
            },
            { key: 'updates', label: 'Post Campaign Updates', icon: <Sparkles className="w-4 h-4" /> },
            { key: 'media', label: 'Media Manager', icon: <ImageIcon className="w-4 h-4" /> },
            { key: 'logs', label: 'Audit & Activity Logs', icon: <History className="w-4 h-4" /> },
          ].map((item) => (
            <button
              key={item.key}
              onClick={() => setActiveTab(item.key as any)}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-semibold transition-all ${
                activeTab === item.key
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20 font-bold'
                  : 'bg-slate-900/60 text-slate-400 hover:bg-slate-800 hover:text-white border border-slate-800/80'
              }`}
            >
              <div className="flex items-center gap-2.5">
                {item.icon}
                <span>{item.label}</span>
              </div>
              {item.badge ? (
                <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-bold">
                  {item.badge}
                </span>
              ) : null}
            </button>
          ))}
        </aside>

        {/* Tab Panel View */}
        <main className="flex-1 min-w-0 bg-slate-900/80 border border-slate-800 rounded-2xl p-6 overflow-y-auto">
          
          {/* TAB 1: ANALYTICS */}
          {activeTab === 'analytics' && (
            <div className="space-y-8">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold text-white">Platform Performance & Analytics</h3>
                  <p className="text-xs text-slate-400">Real-time donation flow and campaign reach</p>
                </div>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-800 space-y-1">
                  <span className="text-xs text-slate-400 font-semibold uppercase">Total Raised</span>
                  <div className="text-2xl font-extrabold text-emerald-400">
                    ${analytics?.totalDonationsAmount.toLocaleString()}
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-800 space-y-1">
                  <span className="text-xs text-slate-400 font-semibold uppercase">Active Campaigns</span>
                  <div className="text-2xl font-extrabold text-white">
                    {analytics?.activeCampaigns} / {analytics?.totalCampaigns}
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-800 space-y-1">
                  <span className="text-xs text-slate-400 font-semibold uppercase">Pending Approvals</span>
                  <div className="text-2xl font-extrabold text-amber-400">
                    {analytics?.pendingProofCount}
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-800 space-y-1">
                  <span className="text-xs text-slate-400 font-semibold uppercase">Platform Visitors</span>
                  <div className="text-2xl font-extrabold text-indigo-400">
                    {analytics?.totalVisitors.toLocaleString()}
                  </div>
                </div>
              </div>

              {/* Donation Growth Recharts Chart */}
              <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-800 space-y-4">
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                  <span>Donation Volume Growth Over Time ($)</span>
                </h4>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={analytics?.donationGrowth || []}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                      <XAxis dataKey="date" stroke="#94a3b8" fontSize={11} />
                      <YAxis stroke="#94a3b8" fontSize={11} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }} />
                      <Line type="monotone" dataKey="amount" stroke="#10b981" strokeWidth={3} dot={{ fill: '#10b981' }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: CAMPAIGN MANAGEMENT (CRUD) */}
          {activeTab === 'campaigns' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-xl font-bold text-white">Campaign Directory</h3>
                  <p className="text-xs text-slate-400">Publish, edit, and monitor active donation requests</p>
                </div>
                <button
                  onClick={() => {
                    setEditingCampaign(null);
                    setFormData({
                      title: '',
                      shortDescription: '',
                      fullDescription: '',
                      category: 'Medical',
                      coverImage: 'https://images.unsplash.com/photo-1532629345422-7515f3d16bb0?auto=format&fit=crop&w=1200&q=80',
                      targetAmount: 25000,
                      currentAmount: 0,
                      currency: 'USD',
                      location: 'Global',
                      beneficiaryName: 'Verified Trust',
                      beneficiaryType: 'NGO / Organization',
                      bankAccount: { accountName: 'Trust Account', accountNumber: '1100-2233-4455', bankName: 'Global Bank' },
                      cryptoWallet: { network: 'TRON (TRC20)', address: 'TYu8a9PzKm42x9LQp71VxN98kXmZp1Q3a7' },
                      status: 'Active',
                    });
                    setShowCampaignModal(true);
                  }}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/20 transition-all"
                >
                  <Plus className="w-4 h-4" />
                  <span>Create New Campaign</span>
                </button>
              </div>

              {/* Campaign Table */}
              <div className="overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-800/80 text-slate-400 uppercase font-semibold text-[10px] border-b border-slate-800">
                    <tr>
                      <th className="p-3.5">Campaign</th>
                      <th className="p-3.5">Category</th>
                      <th className="p-3.5">Raised / Target</th>
                      <th className="p-3.5">Status</th>
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {campaigns.map((c) => (
                      <tr key={c.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="p-3.5">
                          <div className="flex items-center gap-3">
                            <img src={c.coverImage} alt="" className="w-10 h-10 rounded-lg object-cover" />
                            <div>
                              <span className="font-bold text-white block truncate max-w-xs">{c.title}</span>
                              <span className="text-[11px] text-slate-400">{c.beneficiaryName}</span>
                            </div>
                          </div>
                        </td>
                        <td className="p-3.5">
                          <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-medium">
                            {c.category}
                          </span>
                        </td>
                        <td className="p-3.5 font-mono">
                          <span className="text-emerald-400 font-bold">${c.currentAmount.toLocaleString()}</span> / ${c.targetAmount.toLocaleString()}
                        </td>
                        <td className="p-3.5">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            c.status === 'Urgent' ? 'bg-rose-500/20 text-rose-400' :
                            c.status === 'Completed' ? 'bg-blue-500/20 text-blue-400' : 'bg-emerald-500/20 text-emerald-400'
                          }`}>
                            {c.status}
                          </span>
                        </td>
                        <td className="p-3.5 text-right space-x-2">
                          <button
                            onClick={() => handleEditClick(c)}
                            className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700"
                            title="Edit Campaign"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteClick(c.id, c.title)}
                            className="p-1.5 rounded-lg bg-rose-500/10 text-rose-400 hover:bg-rose-500/20"
                            title="Delete Campaign"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: PROOF APPROVALS QUEUE */}
          {activeTab === 'submissions' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold text-white">Donation Verification Queue</h3>
                <p className="text-xs text-slate-400">Review transfer screenshots & approve funds to update progress</p>
              </div>

              {submissions.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400 bg-slate-800/30 rounded-xl">
                  No proof submissions pending review.
                </div>
              ) : (
                <div className="space-y-4">
                  {submissions.map((sub) => (
                    <div
                      key={sub.id}
                      className="p-5 rounded-xl bg-slate-800/50 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
                    >
                      <div className="flex items-start gap-4">
                        {sub.proofScreenshotUrl && (
                          <img
                            src={sub.proofScreenshotUrl}
                            alt="Screenshot"
                            onClick={() => setPreviewProofImage(sub.proofScreenshotUrl!)}
                            className="w-16 h-16 rounded-lg object-cover cursor-pointer hover:opacity-80 border border-slate-700"
                          />
                        )}
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white text-sm">{sub.donorName}</span>
                            <span className="text-xs font-mono font-bold text-emerald-400">
                              +${sub.amount.toLocaleString()} {sub.currency}
                            </span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300">
                              {sub.paymentMethod}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 font-medium">
                            Campaign: <span className="text-slate-200">{sub.campaignTitle}</span>
                          </p>
                          {sub.transactionId && (
                            <p className="text-[11px] font-mono text-slate-400">
                              TxID: {sub.transactionId}
                            </p>
                          )}
                          {sub.message && (
                            <p className="text-xs italic text-slate-300">"{sub.message}"</p>
                          )}
                        </div>
                      </div>

                      {/* Action buttons */}
                      {sub.status === 'Pending' ? (
                        <div className="flex items-center gap-2 w-full md:w-auto">
                          <button
                            onClick={() => handleApproveProof(sub.id)}
                            className="flex-1 md:flex-initial px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            <span>Approve & Add Funds</span>
                          </button>
                          <button
                            onClick={() => handleRejectProof(sub.id)}
                            className="flex-1 md:flex-initial px-3 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 font-bold text-xs flex items-center justify-center gap-1.5"
                          >
                            <XCircle className="w-4 h-4" />
                            <span>Reject</span>
                          </button>
                        </div>
                      ) : (
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                          sub.status === 'Approved' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                        }`}>
                          {sub.status}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: CAMPAIGN UPDATES PUBLISHER */}
          {activeTab === 'updates' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold text-white">Publish Campaign Progress Update</h3>
                <p className="text-xs text-slate-400">Share milestones, photos, and news directly with public donors</p>
              </div>

              <form onSubmit={handlePublishUpdate} className="space-y-4 max-w-2xl text-xs">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Select Target Campaign</label>
                  <select
                    value={updateTargetId}
                    onChange={(e) => setUpdateTargetId(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white font-semibold"
                  >
                    {campaigns.map((c) => (
                      <option key={c.id} value={c.id}>{c.title}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Update Headline</label>
                  <input
                    type="text"
                    value={updateTitle}
                    onChange={(e) => setUpdateTitle(e.target.value)}
                    placeholder="e.g. First medical equipment delivered!"
                    required
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Update Content Story</label>
                  <textarea
                    value={updateContent}
                    onChange={(e) => setUpdateContent(e.target.value)}
                    rows={4}
                    placeholder="Describe progress made with donor funds..."
                    required
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white resize-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Photo URL (Optional)</label>
                  <input
                    type="text"
                    value={updateImage}
                    onChange={(e) => setUpdateImage(e.target.value)}
                    placeholder="https://images.unsplash.com/..."
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono"
                  />
                </div>

                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/20"
                >
                  Publish Progress Report
                </button>
              </form>
            </div>
          )}

          {/* TAB 5: MEDIA MANAGER */}
          {activeTab === 'media' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold text-white">Media Library</h3>
                <p className="text-xs text-slate-400">Uploaded campaign assets and receipt files</p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {mediaFiles.map((m) => (
                  <div key={m.id} className="group relative rounded-xl overflow-hidden bg-slate-800 border border-slate-700 p-2 space-y-2">
                    <img src={m.url} alt="" className="w-full h-28 object-cover rounded-lg" />
                    <div className="text-[11px]">
                      <span className="font-bold text-white block truncate">{m.filename}</span>
                      <span className="text-slate-400">{m.size}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: ACTIVITY LOGS */}
          {activeTab === 'logs' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold text-white">System Audit & Activity Logs</h3>
                <p className="text-xs text-slate-400">Complete immutable record of all admin changes</p>
              </div>

              <div className="space-y-2">
                {activityLogs.map((log) => (
                  <div key={log.id} className="p-3.5 rounded-xl bg-slate-800/50 border border-slate-800 text-xs flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-emerald-400">{log.action}</span>
                        <span className="text-slate-500">•</span>
                        <span className="text-slate-300">{log.details}</span>
                      </div>
                      <span className="text-[10px] text-slate-500">{log.adminEmail}</span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {new Date(log.timestamp).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

        </main>
      </div>

      {/* CREATE / EDIT CAMPAIGN MODAL */}
      {showCampaignModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative w-full max-w-2xl rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl my-auto space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-white">
                {editingCampaign ? 'Edit Campaign' : 'Create New Campaign'}
              </h3>
              <button onClick={() => setShowCampaignModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCampaign} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Campaign Title *</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white font-semibold"
                  >
                    <option value="Medical">Medical</option>
                    <option value="Emergency Relief">Emergency Relief</option>
                    <option value="Education">Education</option>
                    <option value="Environment">Environment</option>
                    <option value="Community">Community</option>
                    <option value="Disaster">Disaster</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Status</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white font-semibold"
                  >
                    <option value="Active">Active</option>
                    <option value="Urgent">Urgent</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Target Amount ($) *</label>
                  <input
                    type="number"
                    value={formData.targetAmount}
                    onChange={(e) => setFormData({ ...formData, targetAmount: Number(e.target.value) })}
                    required
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white font-bold"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Location</label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Cover Image URL</label>
                <input
                  type="text"
                  value={formData.coverImage}
                  onChange={(e) => setFormData({ ...formData, coverImage: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Short Description</label>
                <textarea
                  value={formData.shortDescription}
                  onChange={(e) => setFormData({ ...formData, shortDescription: e.target.value })}
                  rows={2}
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Full Story Description</label>
                <textarea
                  value={formData.fullDescription}
                  onChange={(e) => setFormData({ ...formData, fullDescription: e.target.value })}
                  rows={4}
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white"
                />
              </div>

              {/* Bank Details Sub-group */}
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 space-y-3">
                <span className="font-bold text-emerald-400 block">Beneficiary Bank Account Details</span>
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Account Name"
                    value={formData.bankAccount?.accountName}
                    onChange={(e) => setFormData({ ...formData, bankAccount: { ...formData.bankAccount!, accountName: e.target.value } })}
                    className="p-2 rounded-lg bg-slate-800 border border-slate-700 text-white"
                  />
                  <input
                    type="text"
                    placeholder="Account Number"
                    value={formData.bankAccount?.accountNumber}
                    onChange={(e) => setFormData({ ...formData, bankAccount: { ...formData.bankAccount!, accountNumber: e.target.value } })}
                    className="p-2 rounded-lg bg-slate-800 border border-slate-700 text-white"
                  />
                  <input
                    type="text"
                    placeholder="Bank Name"
                    value={formData.bankAccount?.bankName}
                    onChange={(e) => setFormData({ ...formData, bankAccount: { ...formData.bankAccount!, bankName: e.target.value } })}
                    className="p-2 rounded-lg bg-slate-800 border border-slate-700 text-white"
                  />
                  <input
                    type="text"
                    placeholder="SWIFT / BIC Code"
                    value={formData.bankAccount?.swiftCode}
                    onChange={(e) => setFormData({ ...formData, bankAccount: { ...formData.bankAccount!, swiftCode: e.target.value } })}
                    className="p-2 rounded-lg bg-slate-800 border border-slate-700 text-white"
                  />
                </div>
              </div>

              {/* Crypto Details Sub-group */}
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 space-y-3">
                <span className="font-bold text-amber-400 block">Crypto Wallet Address</span>
                <input
                  type="text"
                  placeholder="TRC20 Address"
                  value={formData.cryptoWallet?.address}
                  onChange={(e) => setFormData({ ...formData, cryptoWallet: { network: 'TRON (TRC20)', address: e.target.value } })}
                  className="w-full p-2 rounded-lg bg-slate-800 border border-slate-700 text-white font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/20"
              >
                {editingCampaign ? 'Save Changes' : 'Publish Campaign'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* PROOF IMAGE LIGHTBOX MODAL */}
      {previewProofImage && (
        <div
          onClick={() => setPreviewProofImage(null)}
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 cursor-pointer"
        >
          <img src={previewProofImage} alt="Receipt Proof" className="max-w-full max-h-[90vh] rounded-lg shadow-2xl" />
        </div>
      )}

    </div>
  );
};
